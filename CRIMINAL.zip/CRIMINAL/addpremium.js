const { MessageEmbed } = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'addpremium',
    aliases: ['addprem', 'premium+', 'prem'],
    category: 'Owner',
    run: async (client, message, args) => {
        if (!config.owner.includes(message.author.id) && !config.admin.includes(message.author.id)) {
            return message.reply({ content: `${client.emoji.cross} You don't have permission to use this command.` });
        }

        const userId = args[0];
        const days = parseInt(args[1]) || 1;
        const count = parseInt(args[2]) || 0;

        if (!userId) {
            return message.reply({ content: `${client.emoji.cross} Please provide a user ID.` });
        }

        try {
            await client.users.fetch(userId);
        } catch (err) {
            return message.reply({ content: `${client.emoji.cross} Invalid user ID.` });
        }

        const expireTimestamp = Date.now() + (days * 86400000);

        await client.db.set(`uprem_${userId}`, true);
        await client.db.set(`upremend_${userId}`, expireTimestamp);
        await client.db.set(`upremcount_${userId}`, count);
        await client.db.set(`upremserver_${userId}`, []);

        const embed = new MessageEmbed()
            .setColor("GREEN")
            .setDescription(`${client.emoji.tick} <@${userId}> has been granted Premium!\n➕ Count: \`${count}\`\n📅 Expires: <t:${Math.floor(expireTimestamp / 1000)}:F>`);

        return message.channel.send({ embeds: [embed] });
    }
};