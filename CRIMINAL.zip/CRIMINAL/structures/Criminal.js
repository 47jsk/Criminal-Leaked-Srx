const { Client, Collection, Intents, WebhookClient } = require('discord.js');
const { Player } = require('discord-player');
const fs = require('fs');
const mongoose = require('mongoose');
const Utils = require('./util');
const Sweepers = require('./Sweepers');
const { QuickDB } = require('quick.db');

module.exports = class Satxler extends Client {
  constructor() {
    const intents = [
      Intents.FLAGS.GUILDS,
      Intents.FLAGS.GUILD_MEMBERS,
      Intents.FLAGS.GUILD_MESSAGES,
      Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
      Intents.FLAGS.GUILD_VOICE_STATES,
      Intents.FLAGS.GUILD_PRESENCES,
      Intents.FLAGS.GUILD_BANS,
      Intents.FLAGS.GUILD_INTEGRATIONS,
    ];

    super({
      intents: intents.reduce((a, b) => a | b, 0),
      fetchAllMembers: false,
      shards: 'auto',
      disableEveryone: true,
    });

    this.config = require(`${process.cwd()}/config.json`);
    this.logger = require('./logger');
    this.commands = new Collection();
    this.categories = fs.readdirSync('./commands/');

    this.player = new Player(this);

    this.emoji = {
      tick: '<a:Yes:1385574498488811541>',
      cross: '<a:No:1385572287763320994>',
      dot: '<a:dots:1309928689244307476>',
      drax: '<:stolen_emoji:1290697912745066527>',
      dev: '<:active_developer:1286939745049641043>',
      qt: '<:Areez_qt:1315992274810834987>',
      dil: '<:stolen_emoji:1290697774891012228>',
      arrow: '<a:emoji_1725906343263:1282768920922558474>',
    };

    this.util = new Utils(this);
    this.Sweeper = new Sweepers(this);
    this.color = `0xff0000`;
    this.support = `https://discord.gg/SvYD5YpTSJ`;
    this.cooldowns = new Collection();

    // ✅ Replace with working webhooks
    this.ratelimit = new WebhookClient({
      url: 'https://canary.discord.com/api/webhooks/1399014481652355083/hkAjxU0ALRCJkksxbgcfOgtxG59D_e8XtDgztamSROHnhQYe8ehDzaRT4xDY0c10StSz', // Replace with valid URL
    });

    this.error = new WebhookClient({
      url: 'https://canary.discord.com/api/webhooks/1399014481652355083/hkAjxU0ALRCJkksxbgcfOgtxG59D_e8XtDgztamSROHnhQYe8ehDzaRT4xDY0c10StSz', // Replace with valid URL
    });

    // Global error handlers
    this.on('error', (error) => {
      this.error.send(`\`\`\`js\n${error.stack}\`\`\``).catch(console.error);
    });
    process.on('unhandledRejection', (error) => {
      this.error.send(`\`\`\`js\n${error.stack}\`\`\``).catch(console.error);
    });
    process.on('uncaughtException', (error) => {
      this.error.send(`\`\`\`js\n${error.stack}\`\`\``).catch(console.error);
    });
    process.on('warning', (warn) => {
      this.error.send(`\`\`\`js\n${warn}\`\`\``).catch(console.error);
    });
    process.on('uncaughtExceptionMonitor', (err, origin) => {
      this.error.send(`\`\`\`js\n${err},${origin}\`\`\``).catch(console.error);
    });
    this.on('rateLimit', (info) => {
      this.ratelimit.send({
        content: `\`\`\`js\nTimeout: ${info.timeout},\nLimit: ${info.limit},\nMethod: ${info.method},\nPath: ${info.path},\nRoute: ${info.route},\nGlobal: ${info.global}\`\`\``,
      }).catch(console.error);
    });
  }

  async initializedata() {
    this.data = new QuickDB();
    this.logger.log('Connecting to Sql...');
    this.logger.log('Sql Database Connected', 'ready');
  }

  async initializeMongoose() {
    const { Database } = require('quickmongo');
    this.db = new Database(this.config.MONGO_DB);
    await this.db.connect();

    this.logger.log('Connecting to MongoDb...');
    mongoose.connect(this.config.MONGO_DB, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    this.logger.log('Mongoose Database Connected', 'ready');
  }

  async loadEvents() {
    fs.readdirSync('./events/').forEach((file) => {
      let eventName = file.split('.')[0];
      require(`${process.cwd()}/events/${file}`)(this);
      this.logger.log(`Loaded Event ${eventName}.`, 'event');
    });
  }

  async loadLogs() { // Renamed to loadLogs() to match convention
    fs.readdirSync('./logs/').forEach((file) => {
      let logevent = file.split('.')[0];
      try {
        require(`${process.cwd()}/logs/${file}`)(this);
        this.logger.log(`Loaded Log Handler ${logevent}.`, 'event');
      } catch (error) {
        this.logger.error(`Failed to load log handler ${logevent}: ${error.stack}`);
      }
    });
  }

  async loadMain() {
    const commandFiles = [];
    const commandPath = `${process.cwd()}/commands`;

    const items = fs.readdirSync(commandPath);
    for (const item of items) {
      const itemPath = `${commandPath}/${item}`;
      const stat = fs.statSync(itemPath);

      if (stat.isDirectory()) {
        const files = fs.readdirSync(itemPath).filter((file) => file.endsWith('.js'));
        for (const file of files) {
          commandFiles.push(`${itemPath}/${file}`);
        }
      } else if (stat.isFile() && item.endsWith('.js')) {
        commandFiles.push(itemPath);
      }
    }

    commandFiles.forEach((value) => {
      const file = require(value);
      const splitted = value.split('/');
      const directory = splitted[splitted.length - 2] || 'default';

      if (file.name) {
        const properties = { directory, ...file };
        this.commands.set(file.name, properties);
        this.logger.log(`Loaded Command ${file.name}.`, 'cmd');
      }
    });

    this.logger.log('Initialized discord-player events.', 'ready');
  }
};