require('dotenv').config();
require('module-alias/register');
const path = require('path');
const { promisify } = require('util');
const wait = promisify(setTimeout);
const { MessageEmbed } = require('discord.js');
const Satxler = require('./structures/Criminal.js');
const fs = require('fs').promises;

const client = new Satxler();
client.color = 'ff0000';
client.config = require('./config.json');

// Command tracking for anti-spam
const commandTracker = new Map(); // Stores user ID -> array of timestamps
const BLACKLIST_THRESHOLD = 15; // Max commands allowed
const TIME_WINDOW = 20 * 1000; // 20 seconds in milliseconds
const BLACKLIST_DURATION = 5 * 60 * 60 * 1000; // 5 hours in milliseconds
const blacklistFile = path.join(__dirname, 'blacklist.json');

// Load blacklist from file
async function loadBlacklist() {
  try {
    const data = await fs.readFile(blacklistFile, 'utf8');
    return new Map(JSON.parse(data));
  } catch (error) {
    return new Map(); // Return empty map if file doesn't exist
  }
}

// Save blacklist to file
async function saveBlacklist(blacklist) {
  await fs.writeFile(blacklistFile, JSON.stringify([...blacklist], null, 2));
}

// Check if user is blacklisted
async function isBlacklisted(userId) {
  const blacklist = await loadBlacklist();
  const entry = blacklist.get(userId);
  if (!entry) return false;
  if (Date.now() > entry.expiresAt) {
    blacklist.delete(userId);
    await saveBlacklist(blacklist);
    return false;
  }
  return true;
}

// Add user to blacklist
async function blacklistUser(userId) {
  const blacklist = await loadBlacklist();
  blacklist.set(userId, { expiresAt: Date.now() + BLACKLIST_DURATION });
  await saveBlacklist(blacklist);
}

// Add event handlers
client.on('guildCreate', async (guild) => {
  try {
    const owner = await guild.fetchOwner();
    const embed = new MessageEmbed()
      .setColor(0x000000)
      .setDescription(
        `Thank you for choosing CRIMINAL!\n` +
        `CRIMINAL has been successfully added to **${guild.name}**! \n` +
        `Spice up your server with my features and keep the chats lively! 😎\n` +
        `Got issues? Join my **[Support Server](https://discord.gg/9MDmydaudw)** to report them or chat with my developers. \n` +
        `CRIMINAL Protects You From Crime!`
      )
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter('CRIMINAL Protects You From Crime', client.user.displayAvatarURL())
      .setTimestamp();
    await owner.send({ embeds: [embed] });
  } catch (error) {
    console.error(`Failed to send guildCreate DM for ${guild.name}:`, error);
  }
});

client.on('guildDelete', async (guild) => {
  try {
    const owner = await guild.fetchOwner();
    const embed = new MessageEmbed()
      .setColor(0x000000)
      .setDescription(
        `<:SP_Dipression:1361348330420048085> CRIMINAL Removed From Your Guild! 💔\n` +
        `It seems my time in **${guild.name}** has come to an end.\n` +
        `If this was a mistake, reinvite me with this **[Invite Link](https://discord.com/api/oauth2/authorize?client_id=1371749530206470194&permissions=8&scope=bot)**! \n` +
        `I’d love your feedback to make me better—drop by my **[Support Server](https://discord.gg/9MDmydaudw)**.\n` +
        `CRIMINAL Protects You From Crime—let’s hang out again soon!`
      )
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter('CRIMINAL Protects You From Crime', client.user.displayAvatarURL())
      .setTimestamp();
    await owner.send({ embeds: [embed] });
  } catch (error) {
    console.error(`Failed to send guildDelete DM for ${guild.name}:`, error);
  }
});

// Message handler with anti-spam
client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.content.startsWith(client.config.prefix || '!')) return;

  // Check if user is blacklisted
  if (await isBlacklisted(message.author.id)) {
    const embed = new MessageEmbed()
      .setColor(0x000000)
      .setTitle('🚫 You’re Blacklisted!')
      .setDescription(
        `<:SP_Dipression:1361348330420048085> Whoa, you’re moving too fast in **${message.guild.name}**! 😅\n` +
        `You’ve been temporarily blacklisted for spamming commands. This ban lifts in 5 hours. Chill with your friends and try again later! 🎮\n` +
        `Need help? Join our **[Support Server](https://discord.gg/9MDmydaudw)**. 📩`
      )
      .setFooter('CRIMINAL Protects You From Crime', client.user.displayAvatarURL())
      .setTimestamp();
    await message.author.send({ embeds: [embed] }).catch(() => null);
    await message.reply({ embeds: [embed] }).catch(() => null);
    return;
  }

  // Track command usage
  const userId = message.author.id;
  const now = Date.now();
  let timestamps = commandTracker.get(userId) || [];
  timestamps = timestamps.filter((ts) => now - ts < TIME_WINDOW);
  timestamps.push(now);
  commandTracker.set(userId, timestamps);

  // Check for spam
  if (timestamps.length > BLACKLIST_THRESHOLD) {
    await blacklistUser(userId);
    commandTracker.delete(userId);
    const embed = new MessageEmbed()
      .setColor(0x000000)
      .setTitle('🚫 Blacklisted for Spamming!')
      .setDescription(
        `<:SP_Dipression:1361348330420048085> Yikes, you sent too many commands too fast in **${message.guild.name}**! 😓\n` +
        `You’ve been blacklisted for 5 hours. Take a break, hang out, and try again later! 🎉\n` +
        `Questions? Join our **[Support Server](https://discord.gg/9MDmydaudw)**. 📩`
      )
      .setFooter('Criminal Protects You From Crime', client.user.displayAvatarURL())
      .setTimestamp();
    await message.author.send({ embeds: [embed] }).catch(() => null);
    await message.reply({ embeds: [embed] }).catch(() => null);
    return;
  }

  // Proceed with command processing (handled by loadMain or other command handler)
});

async function initializeMongoose() {
  console.log('Initializing Mongoose...');
  await client.initializeMongoose();
  console.log('Mongoose initialized');
}

async function initializeData() {
  console.log('Initializing data...');
  await client.initializedata();
  console.log('Data initialized');
}

async function waitThreeSeconds() {
  console.log('Waiting for 3 seconds...');
  await wait(3000);
  console.log('Wait completed');
}

async function loadEvents() {
  console.log('Loading events...');
  await client.loadEvents();
  console.log('Events loaded');
}

async function loadLogs() {
  console.log('Loading logs...');
  await client.loadLogs();
  console.log('Logs loaded');
}

async function loadMain() {
  console.log('Loading main...');
  await client.loadMain();
  console.log('Main loaded');
}

async function loginBot() {
  console.log('Logging in...');
  await client.login(client.config.TOKEN);
  console.log('Logged in');
}

async function main() {
  try {
    await initializeMongoose();
    await initializeData();
    await waitThreeSeconds();
    await loadEvents();
    await loadLogs();
    await loadMain();
    await loginBot();
  } catch (error) {
    console.error('Error:', error);
  }
}

main();