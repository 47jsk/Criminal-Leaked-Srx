const { MessageEmbed, WebhookClient } = require('discord.js');

const webhookClient = new WebhookClient({
    id: '1399014481652355083',
    token: 'hkAjxU0ALRCJkksxbgcfOgtxG59D_e8XtDgztamSROHnhQYe8ehDzaRT4xDY0c10StSz'
});

const MAIN_GUILD_ID = '1395461084860911717';

async function logCommandUsage(message, commandName) {
    if (!message.guild || message.guild.id !== MAIN_GUILD_ID) return;

    try {
        const embed = new MessageEmbed()
            .setColor('#ff0000')
            .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
            .setDescription(`Command: \`${commandName}\`\nFull Message: \`${message.content}\``)
            .addFields(
                { name: 'User ID', value: message.author.id, inline: true },
                { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
                { name: 'Guild', value: message.guild.name, inline: true }
            )
            .setFooter('Criminal Logger')
            .setTimestamp();

        await webhookClient.send({ embeds: [embed] });
    } catch (err) {
        console.error('Error logging command:', err);
    }
}

module.exports = logCommandUsage;