const mongoose = require('mongoose');

module.exports = mongoose.model('NoPrefixTrial', new mongoose.Schema({
    userId: { type: String, required: true, unique: true },
    expiresAt: { type: Date, required: true }
}));