const mongoose = require('mongoose');

const AISettingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  aiChannelId: { type: String, default: null },
  aiEnabled: { type: Boolean, default: false }
});

module.exports = mongoose.model('AISettings', AISettingsSchema);