const mongoose = require('mongoose');

// Define the schema for the AFK status
const afkSchema = new mongoose.Schema({
    Guild: { type: String, required: true },
    Member: { type: String, required: true },
    Reason: { type: String, default: 'No reason provided' },
    Time: { type: Date, default: Date.now }
});

// Create the model based on the schema
const Afk = mongoose.model('Afk', afkSchema);

module.exports = Afk;
