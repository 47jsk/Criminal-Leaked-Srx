const { MessageEmbed, Permissions } = require("discord.js");
const wait = require('wait');

module.exports = async (client) => {
    client.on("roleCreate", async (role) => {
        let check = await client.util.BlacklistCheck(role.guild);
        if (check) return;
        let data = await client.db.get(`logs_${role.guild.id}`);
        if (!data || !data.rolelog) return;

        const rolelog = role.guild.channels.cache.get(data.rolelog);
        if (!rolelog) {
            await client.db.set(`logs_${role.guild.id}`, {
                ...data,
                rolelog: null
            });
            return;
        }

        const auditLogs = await role.guild.fetchAuditLogs({ limit: 1, type: 'ROLE_CREATE' });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (data) {
            const roleCreateEmbed = new MessageEmbed()
                .setAuthor(`${executor.tag}`, executor.displayAvatarURL({ dynamic: true }))
                .setTitle(`Role Created: ${role.name}`)
                .setDescription(
                    `**Role Information:**\n\n` +
                    `- Role Name: ${role.name}\n` +
                    `- Role ID: ${role.id}\n` +
                    `- Displayed separately: ${role.hoist ? 'Yes' : 'No'}\n` +
                    `- Mentionable: ${role.mentionable ? 'Yes' : 'No'}\n` +
                    `- Role Position: ${role.position}\n` +
                    `- Created By: ${executor.tag} (${executor.id})\n\n` +
                    `**Role Permissions:**\n\n` +
                    `${role.permissions.toArray().map(perm => `- ${perm}`).join('\n') || 'No Permissions'}`
                )
                .setColor(role.hexColor)
                .setThumbnail(executor.displayAvatarURL({ dynamic: true }))
                .setFooter(`${role.guild.name}`, role.guild.iconURL({ dynamic: true }))
                .setTimestamp();

            await wait(2000);
            await rolelog.send({ embeds: [roleCreateEmbed] }).catch(err => console.error('Role Create Log Error:', err));
        }
    });

    client.on("roleDelete", async (role) => {
        let check = await client.util.BlacklistCheck(role.guild);
        if (check) return;
        let data = await client.db.get(`logs_${role.guild.id}`);
        if (!data || !data.rolelog) return;

        const rolelog = role.guild.channels.cache.get(data.rolelog);
        if (!rolelog) {
            await client.db.set(`logs_${role.guild.id}`, {
                ...data,
                rolelog: null
            });
            return;
        }

        const auditLogs = await role.guild.fetchAuditLogs({ limit: 1, type: 'ROLE_DELETE' });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (data) {
            const roleDeleteEmbed = new MessageEmbed()
                .setAuthor(`Role Deleted`, executor.displayAvatarURL({ dynamic: true }))
                .setTitle(`Role: ${role.name}`)
                .setDescription(
                    `**Role Information:**\n\n` +
                    `- Role Name: ${role.name}\n` +
                    `- Role ID: ${role.id}\n` +
                    `- Displayed separately: ${role.hoist ? 'Yes' : 'No'}\n` +
                    `- Mentionable: ${role.mentionable ? 'Yes' : 'No'}\n` +
                    `- Deleted By: ${executor.tag} (${executor.id})\n\n` +
                    `**Role Permissions:**\n\n` +
                    `${role.permissions.toArray().map(perm => `- ${perm}`).join('\n') || 'No Permissions'}`
                )
                .setColor("#ff0000")
                .setThumbnail(executor.displayAvatarURL({ dynamic: true }))
                .setFooter(`${role.guild.name}`, role.guild.iconURL({ dynamic: true }))
                .setTimestamp();

            await wait(2000);
            await rolelog.send({ embeds: [roleDeleteEmbed] }).catch(err => console.error('Role Delete Log Error:', err));
        }
    });

    client.on("roleUpdate", async (o, n) => {
        let check = await client.util.BlacklistCheck(o.guild);
        if (check) return;
        let data = await client.db.get(`logs_${o.guild.id}`);
        if (!data || !data.rolelog) return;

        const rolelog = o.guild.channels.cache.get(data.rolelog);
        if (!rolelog) {
            await client.db.set(`logs_${o.guild.id}`, {
                ...data,
                rolelog: null
            });
            return;
        }

        const auditLogs = await n.guild.fetchAuditLogs({ limit: 1, type: "ROLE_UPDATE" });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (data) {
            const rolename = new MessageEmbed()
                .setColor(client.color)
                .setAuthor(`Role Update`, executor.displayAvatarURL({ dynamic: true }))
                .setThumbnail(executor.displayAvatarURL({ dynamic: true }))
                .setDescription(`Role: ${o.name}\nRole Id: ${o.id}\nExecutor: ${executor.tag}\nExecutor Id: ${executor.id}\n`);
            if (o.name !== n.name) rolename.addField('Name', `Old Name: \`${o.name}\` New Name: \`${n.name}\``, false);
            if (o.color !== n.color) rolename.addField('Color', `Old Color: \`${o.color}\` New Color: \`${n.color}\``, false);
            if (o.hoist !== n.hoist) rolename.addField('Display', `Old Display: \`${o.hoist}\` New Display: \`${n.hoist}\``, false);
            if (o.mentionable !== n.mentionable) rolename.addField('Mentionable', `Old Mentionable: \`${o.mentionable}\` New Mentionable: \`${n.mentionable}\``, false);
            if (o.permissions.bitfield !== n.permissions.bitfield) {
                const oldPermissions = o.permissions.toArray().map(perm => `\`${perm}\``).join(', ') || 'No Permissions';
                const newPermissions = n.permissions.toArray().map(perm => `\`${perm}\``).join(', ') || 'No Permissions';
                rolename.addField('Permissions', `Old Permissions: ${oldPermissions}\nNew Permissions: ${newPermissions}`, false);
            }

            rolename.setFooter(n.guild.name, n.guild.iconURL({ dynamic: true }))
                .setTimestamp();
            await wait(2000);
            await rolelog.send({ embeds: [rolename] }).catch(err => console.error('Role Update Log Error:', err));
        }
    });
};