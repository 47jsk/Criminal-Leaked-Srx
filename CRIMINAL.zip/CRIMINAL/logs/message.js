const { MessageEmbed } = require("discord.js");
const wait = require('wait');

module.exports = async (client) => {
    client.on('messageDelete', async (message) => {
        let check = await client.data.get(`blacklistserver_${client.user.id}`) || [];
        if (check.includes(message?.guild?.id)) return;
        let data = await client.db.get(`logs_${message.guild.id}`);
        if (!data || !data.message) return;

        const msglogs = message.guild.channels.cache.get(data.message);
        if (!msglogs) {
            await client.db.set(`logs_${message.guild.id}`, {
                ...data,
                message: null
            });
            return;
        }

        if (message.author.bot || !message.guild || message.system) return;

        if (data) {
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setAuthor('Message Delete', message.author.displayAvatarURL({ dynamic: true }))
                .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                .setDescription(
                    `**Message Content**: ${message.content || 'None (possibly an embed or attachment)'}\n` +
                    `**Author**: ${message.author.tag}\n` +
                    `**Deleted In**: ${message.channel}\n` +
                    `**Channel ID**: ${message.channel.id}`
                );
            if (message.attachments.size > 0) embed.setImage(message.attachments.first().url);

            await wait(2000);
            await msglogs.send({ embeds: [embed] }).catch(err => console.error('Message Delete Log Error:', err));
        }
    });

    client.on('messageUpdate', async (oldMessage, newMessage) => {
        let check = await client.data.get(`blacklistserver_${client.user.id}`) || [];
        if (check.includes(oldMessage?.guild?.id)) return;
        let data = await client.db.get(`logs_${oldMessage.guild.id}`);
        if (!data || !data.message) return;

        const msglogs = oldMessage.guild.channels.cache.get(data.message);
        if (!msglogs) {
            await client.db.set(`logs_${oldMessage.guild.id}`, {
                ...data,
                message: null
            });
            return;
        }

        if (!oldMessage.author || newMessage.author.bot || oldMessage.author.id === client.user.id || oldMessage.content === newMessage.content) return;

        if (data) {
            const edit = new MessageEmbed()
                .setTimestamp()
                .setAuthor('Message Edit', newMessage.author.displayAvatarURL({ dynamic: true }))
                .setThumbnail(newMessage.author.displayAvatarURL({ dynamic: true }))
                .setColor(client.color)
                .setDescription(
                    `**Original**: ${oldMessage.content || 'None'}\n` +
                    `**Edited**: ${newMessage.content || 'None'}\n` +
                    `**Author**: ${newMessage.author.tag} (${newMessage.author.id})\n` +
                    `**Channel**: ${newMessage.channel}\n` +
                    `**Channel ID**: ${newMessage.channel.id}`
                )
                .setTimestamp();

            await wait(2000);
            await msglogs.send({ embeds: [edit] }).catch(err => console.error('Message Edit Log Error:', err));
        }
    });
};