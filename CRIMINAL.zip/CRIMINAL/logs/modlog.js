const { MessageEmbed } = require("discord.js");
const wait = require('wait');

module.exports = async (client) => {
    client.on("guildBanAdd", async (guild, user) => {
        let check = await client.util.BlacklistCheck(guild);
        if (check) return;
        let data = await client.db.get(`logs_${guild.id}`);
        if (!data || !data.modlog) return;

        const modlog1 = guild.channels.cache.get(data.modlog);
        if (!modlog1) {
            await client.db.set(`logs_${guild.id}`, {
                ...data,
                modlog: null
            });
            return;
        }

        const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_BAN_ADD' });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (executor.id === client.user.id) return;

        if (data) {
            const banEmbed = new MessageEmbed()
                .setColor(client.color)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setAuthor(`${user.username} was banned`, user.displayAvatarURL({ dynamic: true }))
                .addField('Banned By', `${executor.tag} (${executor.id})`)
                .addField('Reason', logs.reason || 'No reason provided')
                .setTimestamp();

            await wait(2000);
            await modlog1.send({ embeds: [banEmbed] }).catch(err => console.error('Ban Log Error:', err));
        }
    });

    client.on("guildBanRemove", async (guild, user) => {
        let check = await client.util.BlacklistCheck(guild);
        if (check) return;
        let data = await client.db.get(`logs_${guild.id}`);
        if (!data || !data.modlog) return;

        const modlog1 = guild.channels.cache.get(data.modlog);
        if (!modlog1) {
            await client.db.set(`logs_${guild.id}`, {
                ...data,
                modlog: null
            });
            return;
        }

        const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_BAN_REMOVE' });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (executor.id === client.user.id) return;

        if (data) {
            const unbanEmbed = new MessageEmbed()
                .setColor(client.color)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setAuthor(`${user.username} was unbanned`, user.displayAvatarURL({ dynamic: true }))
                .addField('Unbanned By', `${executor.tag} (${executor.id})`)
                .setTimestamp();

            await wait(2000);
            await modlog1.send({ embeds: [unbanEmbed] }).catch(err => console.error('Unban Log Error:', err));
        }
    });

    client.on("guildMemberRemove", async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;
        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.modlog) return;

        const modlog1 = member.guild.channels.cache.get(data.modlog);
        if (!modlog1) {
            await client.db.set(`logs_${member.guild.id}`, {
                ...data,
                modlog: null
            });
            return;
        }

        const auditLogs = await member.guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_KICK' });
        const logs = auditLogs.entries.first();
        if (!logs || Date.now() - logs.createdTimestamp > 5000) return;

        const { executor, createdTimestamp } = logs;
        if (executor.id === client.user.id) return;

        if (data && logs.target.id === member.id) {
            const kickEmbed = new MessageEmbed()
                .setColor(client.color)
                .setAuthor(`${member.user.username} was kicked`, member.user.displayAvatarURL({ dynamic: true }))
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                .addField('Kicked By', `${executor.tag} (${executor.id})`)
                .addField('Reason', logs.reason || 'No reason provided')
                .setTimestamp();

            await wait(2000);
            await modlog1.send({ embeds: [kickEmbed] }).catch(err => console.error('Kick Log Error:', err));
        }
    });
};