const { MessageEmbed } = require("discord.js");
const wait = require('wait');

module.exports = async (client) => {
    client.on('guildMemberAdd', async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;
        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.memberlog) return;

        const memberlogs = member.guild.channels.cache.get(data.memberlog);
        if (!memberlogs) {
            await client.db.set(`logs_${member.guild.id}`, {
                ...data,
                memberlog: null
            });
            return;
        }

        if (data) {
            const memberAddEmbed = new MessageEmbed()
                .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                .setColor(client.color)
                .setDescription(`A new member has joined the server.\nAccount created at <t:${Math.round(member.user.createdTimestamp / 1000)}:R>\nMember joined at <t:${Math.round(member.joinedTimestamp / 1000)}:R>`)
                .addFields({ name: 'Member ID', value: member.id });
            if (member.roles.cache.size > 1) {
                const addedRoles = member.roles.cache.filter(r => r.id !== member.guild.id).map(role => `<@&${role.id}>`).join(', ');
                memberAddEmbed.addFields({ name: 'Added Roles', value: `${addedRoles || 'None'}` });
            }
            memberAddEmbed.setTimestamp();
            await wait(2000);
            await memberlogs.send({ embeds: [memberAddEmbed] }).catch(err => console.error('Member Add Log Error:', err));
        }
    });

    client.on("guildMemberUpdate", async (oldMember, newMember) => {
        let check = await client.util.BlacklistCheck(oldMember.guild);
        if (check) return;
        let data = await client.db.get(`logs_${oldMember.guild.id}`);
        if (!data || !data.memberlog) return;

        const memberlogs = oldMember.guild.channels.cache.get(data.memberlog);
        if (!memberlogs) {
            await client.db.set(`logs_${oldMember.guild.id}`, {
                ...data,
                memberlog: null
            });
            return;
        }

        if (data) {
            const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
            const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
            const oldTopRole = oldMember.roles.highest;
            const newTopRole = newMember.roles.highest;

            if (addedRoles.size > 0 || removedRoles.size > 0 || oldTopRole.id !== newTopRole.id) {
                const roleUpdateEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setAuthor(newMember.user.tag, newMember.user.displayAvatarURL({ dynamic: true }))
                    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                    .setDescription('**Member Role Update**');

                if (addedRoles.size > 0) roleUpdateEmbed.addFields({ name: 'Added Roles', value: addedRoles.map(role => `<@&${role.id}>`).join(', ') || 'None' });
                if (removedRoles.size > 0) roleUpdateEmbed.addFields({ name: 'Removed Roles', value: removedRoles.map(role => `<@&${role.id}>`).join(', ') || 'None' });
                if (oldTopRole.id !== newTopRole.id) roleUpdateEmbed.addFields({ name: 'Top Role Update', value: `Old Top Role: <@&${oldTopRole.id}>\nNew Top Role: <@&${newTopRole.id}>` });

                roleUpdateEmbed.addFields({ name: 'Member', value: `<@${newMember.id}>`, inline: true })
                    .addFields({ name: 'Member ID', value: newMember.id, inline: true })
                    .setTimestamp();
                await wait(2000);
                await memberlogs.send({ embeds: [roleUpdateEmbed] }).catch(err => console.error('Member Update Log Error:', err));
            }
        }
    });

    client.on("guildMemberRemove", async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;
        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.memberlog) return;

        const memberlogs = member.guild.channels.cache.get(data.memberlog);
        if (!memberlogs) {
            await client.db.set(`logs_${member.guild.id}`, {
                ...data,
                memberlog: null
            });
            return;
        }

        if (data) {
            const memberRemoveEmbed = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`${member.user.tag} left the server.\nAccount created at <t:${Math.round(member.user.createdTimestamp / 1000)}:R>`)
                .setTimestamp()
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .addFields({ name: 'Member ID', value: member.id });

            await wait(2000);
            await memberlogs.send({ embeds: [memberRemoveEmbed] }).catch(err => console.error('Member Remove Log Error:', err));
        }
    });
};