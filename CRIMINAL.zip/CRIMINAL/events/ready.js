const { Collection } = require('discord.js');

module.exports = async (client) => {
  client.on('ready', async () => {
    client.logger.log(`Logged in to ${client.user.tag}`, 'ready');

    // Rotating status every 5 seconds
    const statuses = [
      { name: `FasterThan-N4KERS.!!`, type: 'WATCHING' },
      { name: `MADE BY !   Ꮩᴀᴍᴘɪʀᴇ  < / >`, type: 'PLAYING' },
      { name: `Trusted By 50K+ Users`, type: 'COMPETING' }
    ];

    let index = 0;
    setInterval(() => {
      const current = statuses[index];
      client.user.setPresence({
        activities: [current],
        status: 'dnd'
      });
      index = (index + 1) % statuses.length;
    }, 5000);

    // Initialize invite cache
    client.guildInvites = new Collection();

    client.guilds.cache.forEach(async (guild) => {
      try {
        const invites = await guild.invites.fetch();
        const inviteData = new Collection();

        invites.forEach((invite) => {
          inviteData.set(invite.code, {
            uses: invite.uses,
            inviterId: invite.inviter?.id
          });
        });

        client.guildInvites.set(guild.id, inviteData);

        let dbInvites = await client.db.get(`invites_${guild.id}_${client.user.id}`) || {};

        invites.forEach((invite) => {
          if (invite.inviter?.id && invite.uses > 0) {
            dbInvites[invite.inviter.id] = (dbInvites[invite.inviter.id] || 0) + invite.uses;
          }
        });

        await client.db.set(`invites_${guild.id}_${client.user.id}`, dbInvites);
      } catch (err) {
        client.logger.error(`Failed to fetch invites for ${guild.name}: ${err}`, 'error');
      }
    });
  });
};