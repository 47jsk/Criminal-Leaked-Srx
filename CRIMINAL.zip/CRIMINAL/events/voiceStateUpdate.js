const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const db = require('quick.db');

module.exports = async (client, oldState, newState) => {
  if (!newState.guild || newState.member.user.bot) return;

  const data = db.get(`j2c_${newState.guild.id}`);
  if (!data || newState.channelId !== data.join) return;

  const category = data.category;
  const member = newState.member;

  const tempVC = await newState.guild.channels.create(`${member.user.username}'s VC`, {
    type: 'GUILD_VOICE',
    parent: category,
    permissionOverwrites: [
      { id: member.id, allow: ['CONNECT', 'VIEW_CHANNEL', 'MANAGE_CHANNELS', 'MUTE_MEMBERS', 'DEAFEN_MEMBERS'] },
      { id: newState.guild.id, allow: ['CONNECT', 'VIEW_CHANNEL'] },
    ],
  });

  db.set(`vc_owner_${tempVC.id}`, member.id);
  await member.voice.setChannel(tempVC);

  const vcId = tempVC.id;
  const row1 = new MessageActionRow().addComponents(
    new MessageButton().setCustomId(`lock_${vcId}`).setLabel('🔒 Lock').setStyle('PRIMARY'),
    new MessageButton().setCustomId(`unlock_${vcId}`).setLabel('🔓 Unlock').setStyle('PRIMARY'),
    new MessageButton().setCustomId(`rename_${vcId}`).setLabel('✏ Rename').setStyle('SECONDARY'),
    new MessageButton().setCustomId(`kick_${vcId}`).setLabel('👢 Kick All').setStyle('DANGER'),
    new MessageButton().setCustomId(`claim_${vcId}`).setLabel('👑 Claim').setStyle('SUCCESS')
  );
  const row2 = new MessageActionRow().addComponents(
    new MessageButton().setCustomId(`delete_${vcId}`).setLabel('🗑 Delete').setStyle('DANGER'),
    new MessageButton().setCustomId(`limit1_${vcId}`).setLabel('🛑 Limit 1').setStyle('SECONDARY'),
    new MessageButton().setCustomId(`limit2_${vcId}`).setLabel('🔼 Limit 2').setStyle('SECONDARY'),
    new MessageButton().setCustomId(`limit5_${vcId}`).setLabel('🔼 Limit 5').setStyle('SECONDARY'),
    new MessageButton().setCustomId(`limit10_${vcId}`).setLabel('🔼 Limit 10').setStyle('SECONDARY')
  );

  const embed = new MessageEmbed()
    .setColor(client.color)
    .setTitle('🎮 VC Control Panel')
    .setDescription(`You created <#${vcId}>! Use these buttons to control it.`);

  try {
    await member.send({ embeds: [embed], components: [row1, row2] });
  } catch {
    await member.send({
      embeds: [
        new MessageEmbed()
          .setColor(client.color)
          .setDescription(`${client.emoji.cross} Couldn't DM you the controller panel. Please enable DMs.`),
      ],
    }).catch(() => {});
  }

  const interval = setInterval(async () => {
    if (!tempVC || tempVC.deleted) return clearInterval(interval);
    if (tempVC.members.size === 0) {
      clearInterval(interval);
      await tempVC.delete().catch(() => {});
      db.delete(`vc_owner_${vcId}`);
    }
  }, 10000);
};