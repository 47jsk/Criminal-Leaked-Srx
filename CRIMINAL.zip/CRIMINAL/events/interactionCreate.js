const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const db = require('../models/afk.js');

module.exports = async (client) => {
    client.on('interactionCreate', async (interaction) => {
        console.log('Interaction received:', interaction.type, interaction.customId || interaction.commandName);

        // Handle Select Menus
        if (interaction.isSelectMenu()) {
            await client.util.selectMenuHandle(interaction);
            return;
        }

        // Handle Slash Commands
        if (interaction.isCommand()) {
            await interaction.deferReply({ ephemeral: true }).catch(() => {});
            const cmd = client?.slashCommands?.get(interaction.commandName);
            if (!cmd) {
                return interaction.followUp({
                    content: 'This command has been removed from our system.'
                });
            }

            const args = [];
            for (let option of interaction.options.data) {
                if (option.type === 'SUB_COMMAND') {
                    if (option.name) args.push(option.name);
                    option.options?.forEach((x) => {
                        if (x.value) args.push(x.value);
                    });
                } else if (option.value) args.push(option.value);
            }

            interaction.member = interaction.guild.members.cache.get(interaction.user.id);
            await cmd.run(client, interaction, args);
            return;
        }

        // Handle Context Menus
        if (interaction.isContextMenu()) {
            await interaction.deferReply({ ephemeral: false });
            const command = client.slashCommands.get(interaction.commandName);
            if (command) await command.run(client, interaction);
            return;
        }

        // Handle Buttons
        if (interaction.isButton()) {
            console.log('Button clicked:', interaction.customId);

            // Ticket Button
            const ticketData = await client.db.get(`ticket_${interaction.guild.id}`) || {
                channelId: null,
                embed: null,
                tickets: new Map()
            };

            if (interaction.customId === 'create_ticket') {
                await interaction.deferReply({ ephemeral: true });

                if (!ticketData.channelId || interaction.channel.id !== ticketData.channelId) {
                    await interaction.editReply({ content: 'This button is not valid here.', ephemeral: true });
                    return;
                }

                let ticketChannel;
                try {
                    const ticketCategory = interaction.guild.channels.cache.find(
                        c => c.name === 'Tickets' && c.type === 'GUILD_CATEGORY'
                    ) || await interaction.guild.channels.create('Tickets', { type: 'GUILD_CATEGORY' });

                    ticketChannel = await interaction.guild.channels.create(`ticket-${interaction.user.username}`, {
                        type: 'GUILD_TEXT',
                        parent: ticketCategory.id,
                        permissionOverwrites: [
                            {
                                id: interaction.guild.id,
                                deny: ['VIEW_CHANNEL']
                            },
                            {
                                id: interaction.user.id,
                                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                            },
                            {
                                id: client.user.id,
                                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                            }
                        ],
                        reason: `Ticket created by ${interaction.user.tag}`
                    });

                    ticketData.tickets.set(ticketChannel.id, {
                        owner: interaction.user.id,
                        createdAt: Date.now()
                    });

                    await client.db.set(`ticket_${interaction.guild.id}`, ticketData);
                } catch (error) {
                    console.error('Error during ticket creation:', error);
                    await interaction.editReply({ content: 'Successfully Created Your Ticket.', ephemeral: true });
                    return;
                }

                try {
                    const embed = new MessageEmbed()
                        .setColor(client.color)
                        .setTitle(`Ticket: ${ticketChannel.name}`)
                        .setDescription(`Hello ${interaction.user}, a support team member will assist you soon. Please describe your issue below.\n\n**Admin Commands:**\n- !ticket close ${ticketChannel.id}\n- !ticket add <user> ${ticketChannel.id}\n- !ticket remove <user> ${ticketChannel.id}`)
                        .setFooter('Ticket will be closed by an admin when resolved.');

                    await ticketChannel.send({ embeds: [embed] });
                    await interaction.editReply({ content: `Successfully created #${ticketChannel.name}`, ephemeral: true });
                } catch (error) {
                    console.error('Error sending embed or reply:', error);
                    await interaction.editReply({ content: 'Ticket created, but failed to send message.', ephemeral: true });
                }

                return;
            }

            // Team Info Button
            if (interaction.customId === 'team_info') {
                const teamEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setTitle('Team Information')
                    .addFields(
                        {
                            name: 'DeveloperZ',
                            value: `
<:Criminal_OP:1392784072924729424> [! Ꮩᴀᴍᴘɪʀᴇ..!!](https://discord.com/users/135434347418816667)\n
<:Criminal_OP:1392784072924729424> [! Star </>](https://discord.com/users/1312402378397674368)\n
<:Criminal_OP:1392784072924729424> [ifweditncode](https://discord.com/users/937380760875302974)`
                        },
                        {
                            name: 'OwnerZ',
                            value: `
<a:Ha:1385641359200882688> [! 9 1 1..?](https://discord.com/users/1285324073475375166)\n
<a:Ha:1385641359200882688> [! ϻᴀχ](https://discord.com/users/1009836827248709662)\n
<a:Ha:1385641359200882688> [A B H I S H E K](https://discord.com/users/1274388466498535449)`
                        }
                    );

                try {
                    await interaction.reply({ embeds: [teamEmbed], ephemeral: true });
                } catch (error) {
                    console.error('Error replying to team_info button:', error);
                }

                return;
            }

            // Fake Nitro Button
            if (interaction.customId === 'claim_fake_nitro') {
                await interaction.reply({
                    content: 'Nice try! This is a fake Nitro gift! 🤡',
                    ephemeral: true
                }).catch(error => console.error('Error replying to fake nitro:', error));
                return;
            }

            // AFK Buttons
            if (
                interaction.customId.startsWith('server_afk_') ||
                interaction.customId.startsWith('global_afk_')
            ) {
                const afkHandler = require('../interactions/afkButton');
                return afkHandler(client, interaction);
            }
        }
    });
    const db = require('quick.db');
const { MessageButton } = require('discord.js');
const cooldown = new Map();

module.exports = async (client, interaction) => {
  if (!interaction.isButton()) return;

  const [action, vcId] = interaction.customId.split('_');
  const vc = interaction.guild.channels.cache.get(vcId);
  const ownerId = db.get(`vc_owner_${vcId}`);

  if (!vc || interaction.user.id !== ownerId) {
    return interaction.reply({ content: `${client.emoji.cross} You are not the owner.`, ephemeral: true });
  }

  const key = `${interaction.user.id}_${interaction.customId}`;
  if (cooldown.has(key)) {
    return interaction.reply({ content: `⏳ Wait 20s before using this again.`, ephemeral: true });
  }

  cooldown.set(key, true);
  setTimeout(() => cooldown.delete(key), 20000);

  const safeEdit = async (perms, replyText) => {
    try {
      await vc.permissionOverwrites.edit(interaction.guild.id, perms);
      return interaction.reply({ content: replyText, ephemeral: true });
    } catch {
      return interaction.reply({ content: `${client.emoji.cross} Rate‑limited or missing permissions.`, ephemeral: true });
    }
  };

  if (action === 'lock') return safeEdit({ CONNECT: false }, `${client.emoji.tick} Channel locked.`);
  if (action === 'unlock') return safeEdit({ CONNECT: true }, `${client.emoji.tick} Channel unlocked.`);

  if (action === 'rename') {
    await interaction.reply({ content: `${client.emoji.tick} Enter new name (15s):`, ephemeral: true });
    const filter = m => m.author.id === interaction.user.id;
    const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 15000 });
    const newName = collected.first()?.content;
    if (newName) {
      await vc.setName(newName).catch(() => {});
      return interaction.followUp({ content: `${client.emoji.tick} Renamed to: **${newName}**`, ephemeral: true });
    } else {
      return interaction.followUp({ content: `${client.emoji.cross} Rename timeout.`, ephemeral: true });
    }
  }

  if (action === 'kick') {
    vc.members.forEach(m => { if (m.id !== ownerId) m.voice.disconnect().catch(() => {}); });
    return interaction.reply({ content: `${client.emoji.tick} Kicked everyone except you.`, ephemeral: true });
  }

  if (action === 'claim') {
    if (vc.members.size === 0) {
      db.set(`vc_owner_${vcId}`, interaction.user.id);
      return interaction.reply({ content: `${client.emoji.tick} You have claimed this VC.`, ephemeral: true });
    } else {
      return interaction.reply({ content: `${client.emoji.cross} VC must be empty to claim.`, ephemeral: true });
    }
  }

  if (action === 'delete') {
    await vc.delete().catch(() => {});
    db.delete(`vc_owner_${vcId}`);
    return interaction.reply({ content: `${client.emoji.tick} VC deleted.`, ephemeral: true });
  }

  if (action.startsWith('limit')) {
    const limit = parseInt(action.replace('limit', ''));
    if (!isNaN(limit)) {
      await vc.setUserLimit(limit).catch(() => {});
      return interaction.reply({ content: `${client.emoji.tick} User limit set to ${limit}.`, ephemeral: true });
    }
  }
};
};