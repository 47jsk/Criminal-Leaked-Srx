// interactions/afkButton.js
const { MessageEmbed } = require('discord.js');
const db = require('../models/afk.js');

module.exports = async (client, interaction) => {
    if (!interaction.isButton()) return;

    const [scope, , userId] = interaction.customId.split('_'); // e.g. server_afk_123456

    if (interaction.user.id !== userId) {
        return interaction.reply({
            content: 'These buttons are not for you.',
            ephemeral: true
        });
    }

    const reason = client.afkReason?.[userId] || "I'm AFK :)";
    const isGlobal = interaction.customId.startsWith('global');

    const data = new db({
        Guild: isGlobal ? 'global' : interaction.guildId,
        Member: interaction.user.id,
        Reason: reason,
        Time: Date.now()
    });

    await data.save();

    const embed = new MessageEmbed()
        .setColor(client.color || '#00FFFF')
        .setDescription(`<a:Tick:1322497754353762314> Your **${isGlobal ? 'Global' : 'Server'} AFK** has been set to: **${reason}**`);

    await interaction.update({ embeds: [embed], components: [] });

    // Cleanup reason from memory
    delete client.afkReason[userId];
};