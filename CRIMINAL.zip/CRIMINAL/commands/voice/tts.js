const {
    MessageEmbed
} = require('discord.js');
const {
    joinVoiceChannel,
    createAudioPlayer,
    createAudioResource,
    StreamType,
    VoiceConnectionStatus,
    entersState
} = require('@discordjs/voice');
const discordTTS = require('discord-tts');

module.exports = {
    name: 'tts',
    aliases: ['texttospeech', 'speak'],
    category: 'voice',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> Please provide text to convert to speech. Usage: \`${client.config.PREFIX}tts <message>\``)
                ]
            });
        }

        const text = args.join(' ');
        if (text.length > 200) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> Text must be 200 characters or less!`)
                ]
            });
        }

        const voiceChannel = message.member.voice.channel;
        if (!voiceChannel) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> You must be connected to a voice channel first.`)
                ]
            });
        }

        if (!voiceChannel.permissionsFor(message.guild.me).has(['CONNECT', 'SPEAK'])) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> I need \`CONNECT\` and \`SPEAK\` permissions in your voice channel.`)
                ]
            });
        }

        const userId = message.author.id;
        const now = Date.now();
        const cooldown = 10 * 1000;

        if (client.cooldowns.has(`tts-${userId}`)) {
            const expiration = client.cooldowns.get(`tts-${userId}`) + cooldown;
            if (now < expiration) {
                const timeLeft = ((expiration - now) / 1000).toFixed(1);
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<a:No:1385572287763320994> Please wait ${timeLeft}s before using this command again.`)
                    ]
                });
            }
        }

        client.cooldowns.set(`tts-${userId}`, now);

        try {
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: message.guild.id,
                adapterCreator: message.guild.voiceAdapterCreator
            });

            await entersState(connection, VoiceConnectionStatus.Ready, 5000);

            const player = createAudioPlayer();
            const stream = discordTTS.getVoiceStream(text);
            const resource = createAudioResource(stream, {
                inputType: StreamType.Arbitrary,
                inlineVolume: true
            });
            resource.volume.setVolume(0.5);

            connection.subscribe(player);
            player.play(resource);

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:Yes:1385574498488811541> Speaking in **${voiceChannel.name}**... Bot will leave in 2 minutes.`)
                ]
            });

            player.on('error', error => {
                console.error('Audio player error:', error);
                connection.destroy();
                client.cooldowns.delete(`tts-${userId}`);
                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<a:No:1385572287763320994> Error playing TTS.`)
                    ]
                });
            });

            // Wait 2 minutes after speaking to leave
            player.on('stateChange', (oldState, newState) => {
                if (oldState.status === 'playing' && newState.status === 'idle') {
                    setTimeout(() => {
                        connection.destroy();
                        client.cooldowns.delete(`tts-${userId}`);
                    }, 120000); // 2 minutes
                }
            });

        } catch (err) {
            console.error('TTS error:', err);
            client.cooldowns.delete(`tts-${userId}`);
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> I couldn't join the voice channel or play the TTS.`)
                ]
            });
        }
    }
};
