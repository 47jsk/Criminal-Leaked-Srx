const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'autologs',
    aliases: ['autolog'],
    cooldown: 4,
    category: 'logging',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | You must have `MANAGE SERVER` permissions to use this command.')
                ]
            });
        }

        if (!message.guild.me.permissions.has('ADMINISTRATOR')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | I don\'t have `Administrator` permissions to execute this command.')
                ]
            });
        }

        if (!client.util.hasHigher(message.member)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | You must have a higher role than me to use this command.')
                ]
            });
        }

        let data = await client.db.get(`logs_${message.guild.id}`);
        if (!data) {
            await client.db.set(`logs_${message.guild.id}`, {
                voice: null,
                channel: null,
                rolelog: null,
                modlog: null,
                message: null,
                memberlog: null
            });
            data = await client.db.get(`logs_${message.guild.id}`);
        }

        const isSetup = Object.values(data).some(id => id && message.guild.channels.cache.has(id));
        if (isSetup) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('Logging System is Already Set Up')
                        .setDescription('Your server already has a configured logging system.')
                        .addField('How to Reset Logging?', `Use \`${message.guild.prefix}resetlogs\` to reset and delete all existing log channels of Criminal-Advance.`)
                        .setFooter(`Note: Run ${message.guild.prefix}resetlogs to reconfigure logging.`, client.user.displayAvatarURL())
                ]
            });
        }

        try {
            let category = message.guild.channels.cache.find(c => c.type === 'GUILD_CATEGORY' && c.name === 'Criminal-Advance-LOGS');

            if (!category) {
                category = await message.guild.channels.create('Criminal-Advance-LOGS', {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.id,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: message.guild.me.id,
                            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'EMBED_LINKS']
                        }
                    ],
                    reason: 'Creating logging category for autologs setup.'
                });
            }

            const channels = [
                { name: 'voicelogs', topic: 'This channel logs voice-related events.' },
                { name: 'channellogs', topic: 'This channel logs channel-related events.' },
                { name: 'rolelogs', topic: 'This channel logs role-related events.' },
                { name: 'modlogs', topic: 'This channel logs moderation events.' },
                { name: 'msglogs', topic: 'This channel logs message events.' },
                { name: 'memberlogs', topic: 'This channel logs member-related events.' },
            ];

            for (const channelData of channels) {
                let check = message.guild.channels.cache.find(ch => ch.name === channelData.name && ch.parentId === category.id);
                if (check) {
                    return message.channel.send({
                        embeds: [
                            new MessageEmbed()
                                .setColor('#ff0000')
                                .setTitle('Logging System is Already Set Up')
                                .setDescription('Your server already has a configured logging system under the Criminal-Advance-LOGS category.')
                                .addField('How to Reset Logging?', `Use \`${message.guild.prefix}resetlogs\` to reset and delete all existing log channels.`)
                                .setFooter(`Note: Run ${message.guild.prefix}resetlogs to reconfigure logging.`, client.user.displayAvatarURL())
                        ]
                    });
                }

                await new Promise(resolve => setTimeout(resolve, 2000)); // Rate limit delay
                const newChannel = await message.guild.channels.create(channelData.name, {
                    type: 'GUILD_TEXT',
                    topic: channelData.topic,
                    parent: category.id,
                    permissionOverwrites: [
                        {
                            id: message.guild.id,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: message.guild.me.id,
                            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'EMBED_LINKS']
                        }
                    ],
                    reason: 'Creating logging channel as part of autologs setup.'
                });

                // Map channel name to database key
                const dbKey = channelData.name === 'channellogs' ? 'channel' :
                             channelData.name === 'rolelogs' ? 'rolelog' :
                             channelData.name === 'modlogs' ? 'modlog' :
                             channelData.name === 'msglogs' ? 'message' :
                             channelData.name === 'memberlogs' ? 'memberlog' :
                             'voice';
                data[dbKey] = newChannel.id;
                await client.db.set(`logs_${message.guild.id}`, data);
            }

            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('<a:Yes:1385574498488811541> Logging Channels Setup Complete')
                        .setDescription('<a:Yes:1385574498488811541> All necessary logging channels have been successfully created under the "Criminal-Advance LOGS" category.')
                        .addField('Channels Created', 
                            '- **voicelogs:** Logs voice-related events.\n' +
                            '- **channellogs:** Logs channel-related events.\n' +
                            '- **rolelogs:** Logs role-related events.\n' +
                            '- **modlogs:** Logs moderation events.\n' +
                            '- **msglogs:** Logs message events.\n' +
                            '- **memberlogs:** Logs member-related events.'
                        )
                        .addField('Next Steps', 'Logging will now automatically record events. Use `resetlogs` to reconfigure if needed.')
                        .setFooter('Developed by Criminal-Advance Team', client.user.displayAvatarURL())
                ]
            });

        } catch (error) {
            console.error('Error in autologs:', error);
            if (error.code === 429) {
                await new Promise(resolve => setTimeout(resolve, 5000)); // Handle rate limit
            }
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> An error occurred while creating logging channels. Check console for details.')
                ]
            });
        }
    }
};