const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'resetlogs',
    aliases: ['logsreset'],
    cooldown: 4,
    category: 'logging',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<:No:1387336444447686697> | You must have \`MANAGE SERVER\` permissions to use this command.`
                        )
                ]
            });
        }
        if (!message.guild.me.permissions.has('ADMINISTRATOR')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<:No:1387336444447686697> | I don't have \`Administrator\` permissions to execute this command.`
                        )
                ]
            });
        }

        if (!client.util.hasHigher(message.member)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<:No:1387336444447686697> | You must have a higher role than me to use this command.`
                        )
                ]
            });
        }

        let data = await client.db.get(`logs_${message.guild.id}`);
        if (!data || !Object.values(data).some(id => id && message.guild.channels.cache.has(id))) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('Logging System Not Set Up')
                        .setDescription('Your server does not have a configured logging system to reset.')
                        .addField('How to Set Up?', `Use \`${message.guild.prefix}autologs\` to set up logging channels.`)
                        .setFooter('Note: No logging configuration found.', client.user.displayAvatarURL())
                ]
            });
        }

        const category = message.guild.channels.cache.find(c => c.type === 'GUILD_CATEGORY' && c.name === 'Criminal-Advance-LOGS');
        if (category) {
            const logChannels = message.guild.channels.cache.filter(ch => ch.parentId === category.id);
            for (const channel of logChannels.values()) {
                await channel.delete('Resetting logging system by user request.');
            }
            await category.delete('Resetting logging category by user request.');
        }

        await client.db.set(`logs_${message.guild.id}`, {
            voice: null,
            channel: null,
            rolelogs: null,
            modlogs: null,
            message: null,
            memberlogs: null
        });

        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setTitle('<a:Yes:1385574498488811541> Logging System Reset Complete')
                    .setDescription('<a:Yes:1385574498488811541> All logging channels and configuration have been successfully reset.')
                    .addField('Next Steps', `Use \`${message.guild.prefix}autologs\` to set up a new logging system.`)
                    .setFooter('Logging reset successful.') // Fixed syntax error here
            ]
        });
    }
};