const { MessageEmbed } = require('discord.js');

let enable = `<:No:1387336444447686697><a:Yes:1385574498488811541>`;
let disable = `<a:Yes:1385574498488811541><:No:1387336444447686697>`;
let protect = `<:Danger:1388776040108658730>`;

module.exports = {
    name: 'gwreroll',
    aliases: ['rerollgw', 'grr'],
    category: 'fun',
    premium: false,
    run: async (client, message, args) => {
        if (message.guild.memberCount < 3) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Your Server Doesn't Meet My 3 Member Criteria`)
                ]
            });
        }

        let own = message.author.id === message.guild.ownerId;
        const check = await client.util.isExtraOwner(message.author, message.guild);
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Only Server Owner or Extra Owner Can Run This Command!`)
                ]
            });
        }

        let prefix = '&' || message.guild.prefix;
        const messageId = args[0];

        if (!messageId) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle(`__**Giveaway Reroll**__`)
                        .setDescription(`Reroll winners for a completed giveaway!\nUsage: \`${prefix}gwreroll <message-id>\`\nExample: \`${prefix}gwreroll 123456789012345678\``)
                ]
            });
        }

        const giveawayData = await client.db.get(`${message.guild.id}_giveaway_${messageId}`);
        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | No giveaway found with message ID ${messageId}!`)
                ]
            });
        }

        const channel = message.guild.channels.cache.get(giveawayData.channelId);
        const messageToReroll = await channel.messages.fetch(messageId);
        const reaction = messageToReroll.reactions.cache.get('<a:Criminal_OP:1390275839651745882>');
        const users = await reaction.users.fetch();
        const participants = users.filter(user => !user.bot).random(giveawayData.winnerCount);

        if (!participants || participants.length === 0) {
            return channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`**Giveaway Reroll Failed!** <a:Criminal_OP:1390275839651745882>\nPrize: ${giveawayData.prize}\nNo valid participants left to reroll.`)
                ]
            });
        }

        const newWinners = participants.slice(0, giveawayData.winnerCount);
        const newWinnerMentions = newWinners.map(w => `<@${w.id}>`).join(', ');

        const rerollEmbed = new MessageEmbed()
            .setTitle('<a:Criminal_OP:1390275839651745882> **Giveaway Reroll!** <a:Criminal_OP:1390275839651745882>')
            .setDescription(`**Prize:** ${giveawayData.prize}\n**New Winner(s):** ${newWinnerMentions}\n**Hosted by:** <@${giveawayData.host}>\n**Rerolled by:** ${message.author}`)
            .setColor(client.color);

        await channel.send({ embeds: [rerollEmbed] });

        // Notify new winners (optional DM)
        newWinners.forEach(winner => {
            winner.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:Criminal_OP:1390275839651745882> Congratulations! You are the new winner of **${giveawayData.prize}** in ${message.guild.name}! Rerolled by ${message.author}.`)
                ]
            }).catch(err => console.error(`Failed to DM winner ${winner.tag}:`, err));
        });
    }
};