const { MessageEmbed } = require('discord.js');

let enable = `<:No:1387336444447686697><a:Yes:1385574498488811541>`;
let disable = `<a:Yes:1385574498488811541><:No:1387336444447686697>`;
let protect = `<:Danger:1388776040108658730>`;

module.exports = {
    name: 'gwpause',
    aliases: ['pausegw', 'gwp'],
    category: 'fun',
    premium: false,
    run: async (client, message, args) => {
        if (message.guild.memberCount < 3) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Your Server Doesn't Meet My 3 Member Criteria`)
                ]
            });
        }

        let own = message.author.id === message.guild.ownerId;
        const check = await client.util.isExtraOwner(message.author, message.guild);
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Only Server Owner or Extra Owner Can Run This Command!`)
                ]
            });
        }

        let prefix = '&' || message.guild.prefix;
        const messageId = args[0];
        const action = args[1]?.toLowerCase();

        if (!messageId) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle(`__**Giveaway Pause/Resume**__`)
                        .setDescription(`Pause or resume an active giveaway!\nUsage: \`${prefix}gwpause <message-id> <pause|resume>\`\nExample: \`${prefix}gwpause 123456789012345678 pause\``)
                ]
            });
        }

        const giveawayData = await client.db.get(`${message.guild.id}_giveaway_${messageId}`);
        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | No active giveaway found with message ID ${messageId}!`)
                ]
            });
        }

        if (Date.now() > giveawayData.endTime) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | This giveaway has already ended!`)
                ]
            });
        }

        if (!action || !['pause', 'resume'].includes(action)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Please specify 'pause' or 'resume' as the action!`)
                ]
            });
        }

        const channel = message.guild.channels.cache.get(giveawayData.channelId);
        const messageToPause = await channel.messages.fetch(messageId);

        if (action === 'pause') {
            await client.db.set(`${message.guild.id}_giveaway_${messageId}_paused`, true);
            const pauseEmbed = new MessageEmbed()
                .setTitle('<a:Criminal_OP:1390275839651745882> **Giveaway Paused!** <a:Criminal_OP:1390275839651745882>')
                .setDescription(`**Prize:** ${giveawayData.prize}\n**Hosted by:** <@${giveawayData.host}>\nThis giveaway has been paused by ${message.author}. No new participants can join until resumed.`)
                .setColor(client.color);
            await channel.send({ embeds: [pauseEmbed] });

            // Stop the timeout if it exists (simplified; requires tracking timeout ID)
            // Note: This requires storing the timeout ID in the database, see notes below.
        } else if (action === 'resume') {
            const isPaused = await client.db.get(`${message.guild.id}_giveaway_${messageId}_paused`);
            if (!isPaused) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:No:1387336444447686697> | This giveaway is not paused!`)
                    ]
                });
            }

            await client.db.delete(`${message.guild.id}_giveaway_${messageId}_paused`);
            const resumeEmbed = new MessageEmbed()
                .setTitle('<a:Criminal_OP:1390275839651745882> **Giveaway Resumed!** <a:Criminal_OP:1390275839651745882>')
                .setDescription(`**Prize:** ${giveawayData.prize}\n**Hosted by:** <@${giveawayData.host}>\nThis giveaway has been resumed by ${message.author}. Participants can join again.`)
                .setColor(client.color);
            await channel.send({ embeds: [resumeEmbed] });

            // Restart the timeout (requires original duration adjustment)
            // Note: This requires recalculating remaining time, see notes below.
        }
    }
};