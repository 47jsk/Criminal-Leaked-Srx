const { MessageEmbed } = require('discord.js');
const ms = require('ms'); // For parsing time strings (e.g., '1h', '30m')

let enable = `<:No:1387336444447686697><a:Yes:1385574498488811541>`;
let disable = `<a:Yes:1385574498488811541><:No:1387336444447686697>`;
let protect = `<:Danger:1388776040108658730>`;

module.exports = {
    name: 'giveaway',
    aliases: ['gw', 'gaw'],
    category: 'fun',
    premium: false,
    run: async (client, message, args) => {
        if (message.guild.memberCount < 3) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Your Server Doesn't Meet My 3 Member Criteria`)
                ]
            });
        }

        let own = message.author.id === message.guild.ownerId;
        const check = await client.util.isExtraOwner(message.author, message.guild);
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Only Server Owner or Extra Owner Can Run This Command!`)
                ]
            });
        }

        let prefix = '&' || message.guild.prefix;
        const option = args[0];
        const giveawayEmbed = new MessageEmbed()
            .setThumbnail(client.user.avatarURL({ dynamic: true }))
            .setColor(client.color)
            .setTitle(`__**Giveaway**__`)
            .setDescription(`Start or manage giveaways with prizes and winners!`)
            .addFields([
                {
                    name: `__**Start Giveaway**__`,
                    value: `To Start a Giveaway, Use - \`${prefix}giveaway start <prize> <duration> <winners>\`\nExample: \`${prefix}giveaway start 500k UwU 1h 1\``
                },
                {
                    name: `__**End Giveaway**__`,
                    value: `To End a Giveaway, Use - \`${prefix}giveaway end <message-id>\`\nExample: \`${prefix}giveaway end 123456789012345678\``
                }
            ]);

        if (!option) {
            return message.channel.send({ embeds: [giveawayEmbed] });
        } else if (option === 'start') {
            const prize = args[1];
            const duration = args[2];
            const winnerCount = parseInt(args[3]);

            if (!prize || !duration || !winnerCount) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:No:1387336444447686697> | Please provide a prize, duration (e.g., 1h, 30m), and number of winners!`)
                    ]
                });
            }

            if (isNaN(winnerCount) || winnerCount <= 0) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:No:1387336444447686697> | Please provide a valid number of winners (greater than 0)!`)
                    ]
                });
            }

            const msDuration = ms(duration);
            if (!msDuration || msDuration < 60000) { // Minimum 1 minute
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:No:1387336444447686697> | Please provide a valid duration (minimum 1 minute, e.g., 1m, 1h, 24h)!`)
                    ]
                });
            }

            const embed = new MessageEmbed()
                .setTitle('<a:Criminal_OP:1390275839651745882> **Giveaway Time!** <a:Criminal_OP:1390275839651745882>')
                .setDescription(`**Prize:** ${prize}\n**Hosted by:** ${message.author}\n**Ends at:** <t:${Math.floor((Date.now() + msDuration) / 1000)}:R>\n**Winners:** ${winnerCount}`)
                .setColor(client.color)
                .setFooter('React with emoji to participate!');

            const msg = await message.channel.send({ embeds: [embed] });
            await msg.react('<a:Criminal_OP:1390275839651745882>');

            await client.db.set(`${message.guild.id}_giveaway_${msg.id}`, {
                prize,
                host: message.author.id,
                channelId: message.channel.id,
                endTime: Date.now() + msDuration,
                winnerCount,
                messageId: msg.id
            });

            // Schedule giveaway end
            setTimeout(() => endGiveaway(client, msg.id, message.guild), msDuration);
        } else if (option === 'end') {
            const messageId = args[1];
            if (!messageId) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:No:1387336444447686697> | Please provide a message ID to end the giveaway!`)
                    ]
                });
            }

            await endGiveaway(client, messageId, message.guild);
        } else {
            return message.channel.send({ embeds: [giveawayEmbed] });
        }
    }
};

async function endGiveaway(client, messageId, guild) {
    const giveawayData = await client.db.get(`${guild.id}_giveaway_${messageId}`);
    if (!giveawayData) {
        return guild.channels.cache.get(giveawayData.channelId)?.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`<:No:1387336444447686697> | No giveaway found with message ID ${messageId}!`)
            ]
        });
    }

    const channel = guild.channels.cache.get(giveawayData.channelId);
    const message = await channel.messages.fetch(messageId);
    const reaction = message.reactions.cache.get('<a:Criminal_OP:1390275839651745882>');
    const users = await reaction.users.fetch();
    const participants = users.filter(user => !user.bot).random(giveawayData.winnerCount);

    if (!participants || participants.length === 0) {
        return channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`**Giveaway Ended!** <a:Criminal_OP:1390275839651745882> \nPrize: ${giveawayData.prize}\nNo valid participants. Giveaway hosted by <@${giveawayData.host}> ended.`)
            ]
        });
    }

    const winners = participants.slice(0, giveawayData.winnerCount);
    const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');

    const endEmbed = new MessageEmbed()
        .setTitle('<a:Criminal_OP:1390275839651745882> **Giveaway Ended!** <a:Criminal_OP:1390275839651745882>')
        .setDescription(`**Prize:** ${giveawayData.prize}\n**Winner(s):** ${winnerMentions}\n**Hosted by:** <@${giveawayData.host}>\n**Ended at:** <t:${Math.floor(Date.now() / 1000)}:R>`)
        .setColor(client.color);

    await channel.send({ embeds: [endEmbed] });
    await client.db.delete(`${guild.id}_giveaway_${messageId}`);

    // Notify winners (optional DM)
    winners.forEach(winner => {
        winner.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`<a:Criminal_OP:1390275839651745882> Congratulations! You won **${giveawayData.prize}** in ${guild.name}! Hosted by <@${giveawayData.host}>.`)
            ]
        }).catch(err => console.error(`Failed to DM winner ${winner.tag}:`, err));
    });
}