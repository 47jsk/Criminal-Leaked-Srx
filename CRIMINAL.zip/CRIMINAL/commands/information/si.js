const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const moment = require('moment'); // Kept in case used elsewhere

module.exports = {
  name: 'serverinfo',
  aliases: ['si'],
  category: 'Extra',
  description: 'Get information about the server',
  args: false,
  usage: 'serverinfo',
  botPerms: [],
  userPerms: [],
  owner: false,

  run: async (client, message, args, prefix) => {
    const guild = message.guild;

    const filter = {
      0: 'None',
      1: 'Members without a role',
      2: 'All Members',
    };

    const verificationLevels = {
      0: 'None',
      1: 'Low',
      2: 'Medium',
      3: 'High',
      4: 'Very High',
    };

    const booster = {
      0: '**Level**: 0',
      1: '**Level**: 1',
      2: '**Level**: 2',
      3: '**Level**: 3',
    };

    const upload = {
      0: '8 MB',
      1: '8 MB',
      2: '50 MB',
      3: '100 MB',
    };

    const nsfw = {
      0: 'Default',
      1: 'Safe',
      2: 'Explicit',
      3: 'Age Restricted',
    };

    const notilevel = {
      0: 'All Messages',
      1: 'Only @mentions',
    };

    const disabled = client.emoji.cross;
    const enabled = client.emoji.tick;

    // Button creation (fallback to MessageButton if client.button() is undefined)
    const createButton = (customId, label, emoji, isDisabled = false) => {
      if (typeof client.button === 'function') {
        return client.button().secondary(customId, label, emoji, isDisabled);
      }
      return new MessageButton()
        .setCustomId(customId)
        .setLabel(label)
        .setStyle('SECONDARY')
        .setEmoji(emoji)
        .setDisabled(isDisabled);
    };

    const buttons = {
      home: createButton('home', 'General Info', client.emoji.home || '🏠'),
      homeDis: createButton('home', 'General Info', client.emoji.home || '🏠', true),
      features: createButton('features', 'Guild Features', client.emoji.utility || '⚙️'),
      featuresDis: createButton('features', 'Guild Features', client.emoji.utility || '⚙️', true),
      roles: createButton('roles', 'Roles Info', client.emoji.reason || '📜'),
      rolesDis: createButton('roles', 'Roles Info', client.emoji.reason || '📜', true),
      others: createButton('others', 'Other Info', '<a:link:1281620132875210863>'),
      othersDis: createButton('others', 'Other Info', '<a:link:1281620132875210863>', true),
    };

    const mainRow = new MessageActionRow().addComponents(buttons.homeDis, buttons.features, buttons.roles, buttons.others);
    const feaDis = new MessageActionRow().addComponents(buttons.home, buttons.featuresDis, buttons.roles, buttons.others);
    const roleDis = new MessageActionRow().addComponents(buttons.home, buttons.features, buttons.rolesDis, buttons.others);
    const othDis = new MessageActionRow().addComponents(buttons.home, buttons.features, buttons.roles, buttons.othersDis);
    const allDis = new MessageActionRow().addComponents(buttons.homeDis, buttons.featuresDis, buttons.rolesDis, buttons.othersDis);

    // Guild features
    let features = '';
    const featureList = [
      { key: 'ANIMATED_BANNER', text: 'Animated Banner' },
      { key: 'ANIMATED_ICON', text: 'Animated Icon' },
      { key: 'APPLICATION_COMMAND_PERMISSIONS_V2', text: 'Application Commands Permissions V2' },
      { key: 'BANNER', text: 'Banner' },
      { key: 'AUTO_MODERATION', text: 'Auto Moderation' },
      { key: 'COMMUNITY', text: 'Community' },
      { key: 'DEVELOPER_SUPPORT_SERVER', text: 'Developer Support Server' },
      { key: 'DISCOVERABLE', text: 'Discoverable' },
      { key: 'FEATURABLE', text: 'Featurable' },
      { key: 'INVITES_DISABLED', text: 'Invites Disabled' },
      { key: 'INVITE_SPLASH', text: 'Invite Splash' },
      { key: 'MEMBER_VERIFICATION_GATE_ENABLED', text: 'Member Verification Gate Enabled' },
      { key: 'MONETIZATION_ENABLED', text: 'Monetization Enabled' },
      { key: 'MORE_STICKERS', text: 'More Stickers' },
      { key: 'NEWS', text: 'News' },
      { key: 'PARTNERED', text: 'Partnered' },
      { key: 'PREVIEW_ENABLED', text: 'Preview Enabled' },
      { key: 'ROLE_ICONS', text: 'Role Icons' },
      { key: 'TICKETED_EVENTS_ENABLED', text: 'Ticketed Events Enabled' },
      { key: 'VANITY_URL', text: 'Vanity URL' },
      { key: 'VERIFIED', text: 'Verified' },
      { key: 'VIP_REGIONS', text: 'Vip Regions' },
      { key: 'WELCOME_SCREEN_ENABLED', text: 'Welcome Screen Enabled' },
    ];

    featureList.forEach(({ key, text }) => {
      if (guild.features.includes(key)) features += `\n${client.emoji.tick || '✅'} : ${text}`;
    });
    if (!features) features = 'No features';

    const featureEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(guild.name, guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter(`Requested By ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addField('__Guild Features__', features);

    // Roles info
    const roles = guild.roles.cache
      .filter((x) => !x.managed)
      .sort((a, b) => b.position - a.position)
      .map((role) => role.toString())
      .slice(0, -1);
    let rolesDisplay = roles.length < 24 ? roles.join(' ') || 'None' : '`Too many roles to show...`';
    if (rolesDisplay.length > 1024) rolesDisplay = `${roles.slice(0, 4).join(' ')} \`more...\``;

    const roleEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(guild.name, guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter(`Requested By ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addField(`__Roles Info__ [${roles.length}]`, rolesDisplay);

    // Other info
    const members = guild.members.cache;
    const channels = guild.channels.cache;
    const emojis = guild.emojis.cache;
    const rules = guild.rulesChannelId ? `<#${guild.rulesChannelId}>` : 'None';

    const otherEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(guild.name, guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter(`Requested By ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addField('__Other Info__', 'Extra Information About the Guild')
      .addField(
        '__Channels__',
        `**Total**: ${channels.size}\n` +
          `**Category**: ${channels.filter((x) => x.type === 'GUILD_CATEGORY').size}\n` +
          `**Text**: ${channels.filter((x) => x.type === 'GUILD_TEXT').size}\n` +
          `**Voice**: ${channels.filter((x) => x.type === 'GUILD_VOICE').size}\n` +
          `**Announcement**: ${channels.filter((x) => x.type === 'GUILD_NEWS').size}\n` +
          `**Stage**: ${channels.filter((x) => x.type === 'GUILD_STAGE_VOICE').size}\n` +
          `**Forum**: ${channels.filter((x) => x.type === 'GUILD_FORUM').size}\n` +
          `**Rules Channel**: ${rules}`
      )
      .addField(
        '__Boosts__',
        `${booster[guild.premiumTier]} [${guild.premiumSubscriptionCount} Boosts]\n` +
          `**Vanity?**: ${guild.vanityURLCode ? `.gg/${guild.vanityURLCode}` : client.emoji.cross || '❌'}\n` +
          `**Vanity Uses**: ${guild.vanityURLUses || client.emoji.cross || '❌'}`
      )
      .addField(
        '__Emojis__',
        `**Total**: ${emojis.size}\n` +
          `**Regular**: ${emojis.filter((x) => !x.animated).size}\n` +
          `**Animated**: ${emojis.filter((x) => x.animated).size}`
      );

    // Main server info embed
    await guild.bans.fetch();
    const { createdTimestamp, ownerId, description } = guild;

    const mainEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(guild.name, guild.iconURL({ dynamic: true }))
      .setDescription(description || 'No Description Set')
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setImage(guild.bannerURL ? guild.bannerURL({ size: 4096 }) : null)
      .addField(
        '__About Server__',
        `**Name**: ${guild.name}\n` +
          `**Id**: ${guild.id}\n` +
          `**Owner** <a:Ha:1385641359200882688>: <@!${ownerId}>\n` +
          `**Created**: <t:${parseInt(createdTimestamp / 1000)}:R>\n` +
          `**Members**: ${guild.memberCount}\n` +
          `**Banned**: ${guild.bans.cache.size}`
      )
      .addField(
        '__Extras__',
        `**Verification Level**: ${verificationLevels[guild.verificationLevel]}\n` +
          `**Upload Limit**: ${upload[guild.premiumTier]}\n` +
          `**Inactive Channel**: ${guild.afkChannelId ? `<#${guild.afkChannelId}>` : 'None'}\n` +
          `**Inactive Timeout**: ${guild.afkTimeout / 60} mins\n` +
          `**System Messages Channel**: ${guild.systemChannelId ? `<#${guild.systemChannelId}>` : 'None'}\n` +
          `**Default Notifications**: ${notilevel[guild.defaultMessageNotifications]}\n` +
          `**Explicit Media Content Filter**: ${filter[guild.explicitContentFilter]}\n` +
          `**NSFW Level**: ${nsfw[guild.nsfwLevel]}\n` +
          `**2FA Requirement**: ${guild.mfaLevel ? enabled : disabled}\n` +
          `**Boost Bar Enabled**: ${guild.premiumProgressBarEnabled ? enabled : disabled}`
      )
      .setTimestamp()
      .setFooter(`Requested By ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }));

    // Send initial message
    const serverInfoMessage = await message.channel.send({ embeds: [mainEmbed], components: [mainRow] });

    // Create collector
    const collector = serverInfoMessage.createMessageComponentCollector({
      filter: (interaction) => {
        if (message.author.id === interaction.user.id) return true;
        interaction.reply({
          content: `${client.emoji.cross || '❌'} Only **${message.author.tag}** can interact`,
          ephemeral: true,
        });
        return false;
      },
      time: 100000,
      idle: 50000,
    });

    // Handle button interactions
    collector.on('collect', async (interaction) => {
      if (interaction.isButton()) {
        const embedsAndRows = {
          home: { embed: mainEmbed, row: mainRow },
          features: { embed: featureEmbed, row: feaDis },
          roles: { embed: roleEmbed, row: roleDis },
          others: { embed: otherEmbed, row: othDis },
        };

        const { embed, row } = embedsAndRows[interaction.customId] || { embed: mainEmbed, row: mainRow };
        await interaction.update({ embeds: [embed], components: [row] });
      }
    });

    // Handle collector end
    collector.on('end', async () => {
      if (serverInfoMessage) {
        await serverInfoMessage.edit({ embeds: [mainEmbed], components: [allDis] }).catch(() => {});
      }
    });
  },
};