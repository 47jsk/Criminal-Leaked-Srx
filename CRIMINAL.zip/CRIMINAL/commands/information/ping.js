const { MessageEmbed } = require('discord.js')

module.exports = {
    name: 'ping',
    aleases: ['pong'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        let ping = client.ws.ping
        let text = ''
        if (ping >= 0 && ping <= 20) {
            text = 'RATATAA!'
        } else if (ping >= 21 && ping <= 30) {
            text = 'FAST!'
        } else if (ping >= 31 && ping <= 50) {
            text = 'MEDIUM!'
        } else if (ping >= 51 && ping <= 70) {
            text = 'SLOW!'
        } else if (ping >= 71 && ping <= 100) {
            text = 'VERY SLOW'
        } else {
            text = 'MRGYA BOT!'
        }
        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setAuthor({
                        name: `${client.ws.ping}ms Pong!`,
                        iconURL: `${message.member.user.displayAvatarURL({
                            dynamic: true
                        })}`
                    })
                    .setColor(client.color)
                    .setFooter({
                        text: `Respond Speed: ${text}`,
                        iconURL: client.user.displayAvatarURL()
                    })
            ]
        })
    }
}
