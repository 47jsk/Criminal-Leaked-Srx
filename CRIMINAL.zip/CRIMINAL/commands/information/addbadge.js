const { MessageEmbed } = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'addbadge',
    aliases: ['ab'],
    category: 'admin',
    premium: false,
    run: async (client, message, args) => {
        try {
            // Check if the user is the owner
            const ownerId = '1354343474186686607'; // Replace with your Discord ID
            if (message.author.id !== ownerId) {
                return message.channel.send({
                    content: 'Only the bot owner can use this command!',
                });
            }

            // Check if enough arguments are provided
            if (args.length < 2) {
                return message.channel.send({
                    content: 'Usage: &addbadge <user> <badge>',
                });
            }

            // Get the target user
            const user =
                message.mentions.users.first() ||
                client.users.cache.get(args[0]);
            if (!user) {
                return message.channel.send({
                    content: 'Please mention a valid user or provide their ID.',
                });
            }

            // Get the badge name
            const badgeName = args.slice(1).join(' ').trim();

            // Read existing badges from badges.json
            let data;
            try {
                data = JSON.parse(fs.readFileSync('badges.json', 'utf8'));
            } catch (error) {
                console.error('Error reading badges.json:', error);
                data = { users: {} };
            }

            // Initialize user array if it doesn't exist
            if (!data.users[user.id]) {
                data.users[user.id] = [];
            }

            // Add the badge if it doesn't already exist
            if (!data.users[user.id].includes(badgeName)) {
                data.users[user.id].push(badgeName);
                fs.writeFileSync('badges.json', JSON.stringify(data, null, 2));
            }

            // Create confirmation embed
            const embed = new MessageEmbed()
                .setColor(client.color || '#FF0000')
                .setTimestamp()
                .setDescription(
                    `Successfully added **${badgeName}** badge to ${user.tag}!`
                );

            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Addbadge command error:', error);
            await message.channel.send({
                content: 'An error occurred while adding the badge. Please try again later.',
            });
        }
    },
};