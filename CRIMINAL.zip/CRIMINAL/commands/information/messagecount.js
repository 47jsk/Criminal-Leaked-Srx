const {
    Message,
    Client,
    MessageEmbed,
    MessageActionRow,
    MessageButton
} = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'messagecount',
    aliases: ['msgcount', 'messages','message'],
    category: 'utility',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '&';

        // No arguments: show user's own message counts
        if (!args[0]) {
            const user = message.author;
            const counts = await getUserMessageCounts(client, message.guild.id, user.id);
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:Yes:1385574498488811541> | **${user.tag}**'s message counts:\n` +
                            `**Daily**: ${counts.daily} message${counts.daily === 1 ? '' : 's'}\n` +
                            `**Weekly**: ${counts.weekly} message${counts.weekly === 1 ? '' : 's'}\n` +
                            `**Monthly**: ${counts.monthly} message${counts.monthly === 1 ? '' : 's'}\n` +
                            `**Total**: ${counts.total} message${counts.total === 1 ? '' : 's'}`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // List option: show leaderboard for a specific period
        if (args[0].toLowerCase() === 'list') {
            const period = args[1] ? args[1].toLowerCase() : 'total';
            if (!['daily', 'weekly', 'monthly', 'total'].includes(period)) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Invalid period. Use \`${prefix}messagecount list [daily/weekly/monthly/total]\`.`
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            const messageData = await client.db.get(`messages_${message.guild.id}_${period}`) || {};
            const leaderboard = Object.entries(messageData)
                .map(([userId, count]) => ({ userId, count }))
                .sort((a, b) => b.count - a.count);

            if (leaderboard.length < 1) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<a:No:1385572287763320994> No ${period} messages recorded yet. 😔`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            const info = [];
            for (let i = 0; i < leaderboard.length; i++) {
                const { userId, count } = leaderboard[i];
                const user = await client.users.fetch(userId).catch(() => null);
                if (user) {
                    info.push(`${i + 1}) ${user.tag} (${user.id}) - ${count} message${count === 1 ? '' : 's'}`);
                }
            }

            return await client.util.pagination(
                message,
                info,
                `**${period.charAt(0).toUpperCase() + period.slice(1)} Message Leaderboard** 🏆`
            );
        }

        // Reset option: admin-only
        if (args[0].toLowerCase() === 'reset') {
            // Check if the user has Administrator permission
            if (!message.member.permissions.has('ADMINISTRATOR')) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription('<a:No:1385572287763320994> You need **Administrator** permission to reset message counts.')
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            if (!args[1]) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Please provide a user ID or mention a user.\n${prefix}messagecount reset \`<user id/@user>\``
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            let user;
            let userId = args[1].replace(/[<@!>]*/g, ''); // Extract user ID from mention or raw ID
            try {
                user = await client.users.fetch(userId);
            } catch {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Invalid user ID or mention.\n${prefix}messagecount reset \`<user id/@user>\``
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            // Check if the user is a member of the server
            const member = await message.guild.members.fetch(userId).catch(() => null);
            if (!member) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> **${user.tag}** is not a member of this server.`
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }

            // Reset all message counts for the user
            const periods = ['daily', 'weekly', 'monthly', 'total'];
            let resetDone = false;
            for (const period of periods) {
                const messageData = await client.db.get(`messages_${message.guild.id}_${period}`) || {};
                if (messageData[user.id]) {
                    delete messageData[user.id];
                    await client.db.set(`messages_${message.guild.id}_${period}`, messageData);
                    resetDone = true;
                }
            }

            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            resetDone
                                ? `<a:Yes:1385574498488811541> | **${user.tag}** (${user.id}) message counts have been reset.`
                                : `<a:No:1385572287763320994> **${user.tag}** has no recorded messages to reset.`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Check message counts for a specific user
        let user;
        let userId = args[0].replace(/[<@!>]*/g, ''); // Extract user ID from mention or raw ID
        try {
            user = await client.users.fetch(userId);
        } catch {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> Invalid user ID or mention.\n${prefix}messagecount \`<user id/@user/list/reset>\` \`<user id/@user>\``
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const counts = await getUserMessageCounts(client, message.guild.id, user.id);
        return message.channel.send({
            embeds: [
                embed
                    .setDescription(
                        `<a:Yes:1385574498488811541> | **${user.tag}**'s message counts:\n` +
                        `**Daily**: ${counts.daily} message${counts.daily === 1 ? '' : 's'}\n` +
                        `**Weekly**: ${counts.weekly} message${counts.weekly === 1 ? '' : 's'}\n` +
                        `**Monthly**: ${counts.monthly} message${counts.monthly === 1 ? '' : 's'}\n` +
                        `**Total**: ${counts.total} message${counts.total === 1 ? '' : 's'}`
                    )
                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};

// Helper function to get a user's message counts from database
async function getUserMessageCounts(client, guildId, userId) {
    const periods = ['daily', 'weekly', 'monthly', 'total'];
    const counts = { daily: 0, weekly: 0, monthly: 0, total: 0 };
    for (const period of periods) {
        const messageData = await client.db.get(`messages_${guildId}_${period}`) || {};
        counts[period] = messageData[userId] || 0;
    }
    return counts;
}