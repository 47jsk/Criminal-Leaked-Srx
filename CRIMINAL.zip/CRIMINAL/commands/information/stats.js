const { Client, Message, MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    name: 'stats',
    aliases: ['botstats', 'botinfo', 'bi'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        // Send initial loading message
        const loadingEmbed = new MessageEmbed()
            .setColor(client.color)
            .setDescription('<a:Load:1392425321285816320> Gathering stats from Vampire, please wait...');

        const loadingMessage = await message.channel.send({ embeds: [loadingEmbed] });

        // Simulate loading steps with a delay (you can adjust the delay as needed)
        await new Promise(resolve => setTimeout(resolve, 1500)); // 1.5 seconds delay

        const totalGuilds = client.guilds.cache.size;
        const totalUsers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
        const uptime = Math.floor(client.uptime / 1000);
        const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const crimeModeStatus = client.crimeModeData?.get(message.guild.id)?.enabled ? '<a:Yes:1385574498488811541> Enabled' : '<a:No:1385572287763320994> Disabled';

        const row = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel('Invite Bot')
                .setStyle('LINK')
                .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
            new MessageButton()
                .setLabel('Support Server')
                .setStyle('LINK')
                .setURL('https://discord.gg/vZKwA5gQ5K'),
            new MessageButton()
                .setLabel('Team')
                .setStyle('SECONDARY')
                .setCustomId('team_info')
        );

        const embed = new MessageEmbed()
            .setColor(client.color)
            .setAuthor({
                name: '!        Ꮩᴀᴍᴘɪʀᴇ  ..!!',
                iconURL: 'https://cdn.discordapp.com/attachments/1364901008450261084/1387507341817282601/996a553075dfa89f035882bcad825874.webp'
            })
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '<:Hehe:1385570711229173872> Memory Usage', value: `${memoryUsage} MB`, inline: true },
                { name: '<:Game:1392425821603369072> Total Commands', value: `${client.commands.size}`, inline: true },
                { name: '<:Heh:1385571321089491004> Prefix', value: `&`, inline: true },
                { name: '<:Stats:1388210995335270454> Uptime', value: `<t:${Math.floor(Date.now() / 1000 - uptime)}:R>`, inline: true },
                { name: '<:Hh:1388211267264581703> Users', value: `${totalUsers}`, inline: true },
                { name: '<:Hh:1388211483338342542> Servers', value: `${totalGuilds}`, inline: true },
                { name: '<:Hh:1388211780953702561> Node.js', value: `${process.version}`, inline: true },
                { name: '<:Hehe:1385570918658605056> Ping', value: `${client.ws.ping}ms`, inline: true },
            )
            .setFooter({ text: `Developed With ❤️ By Ꮩᴀᴍᴘɪʀᴇ X MaX`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

        // Edit the loading message to show the final embed
        await loadingMessage.edit({
            embeds: [embed],
            components: [row]
        });
    }
};

// Interaction handler for the Team Info button (remains unchanged)
module.exports.setupStatsInteractions = (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isButton()) return;
        
        if (interaction.customId === 'team_info') {
            const teamEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle('Team Information')
                .addFields(
                    {
                        name: 'Developer',
                        value: `
<:Dev:1385682163676090470> [! Ꮩᴀᴍᴘɪʀᴇ </>](https://discord.com/user/1354343474186686607)
                        `
                    },
                    {
                        name: 'OwnerZ',
                        value: `
<a:Ha:1385641359200882688> [! ϻᴀχ </>](https://discord.com/user/1009836827248709662)
<a:Ha:1385641359200882688> [! Star </>](https://discord.com/user/1312402378397450358)
                        `
                    },
                    {
                        name: 'DebuggerZ',
                        value: `
<:Criminal_OP:1392784072924729424> [! Star </>](https://discord.com/user/1312402378397450358)
                        `
                    }
                );

            await interaction.reply({ embeds: [teamEmbed], ephemeral: true });
        }
    });
};