const { MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        try {
            let prefix = message.guild?.prefix || '!';
            const supportServerId = '1395461084860911717'; // Replace with actual guild ID
            const supportInviteLink = 'https://discord.gg/9pYEg6n5qV';

            // Simplified membership check (debug mode)
            const isInSupportServer = await client.guilds.cache
                .get(supportServerId)?.members.fetch(message.author.id)
                .then(() => true)
                .catch(() => false);

            if (!isInSupportServer) {
                const joinEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setAuthor('CRIMINAL')
                    .setDescription(`<a:Load:1392425321285816320> To Discover All Commands, Join Our Support Server! Or Get Premium &premium\n\n[Click Here to Join](${supportInviteLink})\n\nPrefix for this server: \`${prefix}\``)
                    .setFooter('Developed With ❤ By TEAM CRIMINAL');

                const joinRow = new MessageActionRow().addComponents(
                    new MessageButton()
                        .setLabel('Join Support Server')
                        .setStyle('LINK')
                        .setURL(supportInviteLink)
                );

                return message.channel.send({ embeds: [joinEmbed], components: [joinRow] });
            }

            const selectMenu = new MessageSelectMenu()
                .setCustomId('categorySelect')
                .setPlaceholder('Select a category')
                .addOptions([
                    { label: 'All', value: 'all', description: 'Show all commands' },
                    { label: 'AntiNuke', value: 'antinuke', description: 'Commands related to AntiNuke' },
                    { label: 'Moderation', value: 'mod', description: 'Commands related to Moderation' },
                    { label: 'Utility', value: 'info', description: 'Utility commands' },
                    { label: 'Welcomer', value: 'welcomer', description: 'Commands for Welcomer' },
                    { label: 'Voice', value: 'voice', description: 'Commands related to Voice' },
                    { label: 'Automod', value: 'automod', description: 'Commands for Automod' },
                    { label: 'Custom Role', value: 'customrole', description: 'Commands for Custom Roles' },
                    { label: 'Logging', value: 'logging', description: 'Commands for Logging' },
                    { label: 'Owner', value: 'owner', description: 'Owner-only Commands' },
                    { label: 'Fun', value: 'fun', description: 'Commands for Fun' },
                    { label: 'Music', value: 'music', description: 'Commands for Music' },
                    { label: 'Giveaway', value: 'giveaway', description: 'Commands for Giveaways' },
                    { label: 'Extra', value: 'extra', description: 'Extra commands' },
                ]);

            const row1 = new MessageActionRow().addComponents(
                new MessageButton().setCustomId('antinuke').setLabel('Antinuke').setStyle('SECONDARY').setEmoji('1282767910955257868'),
                new MessageButton().setCustomId('mod').setLabel('Moderation').setStyle('SECONDARY').setEmoji('1282768959682252923'),
                new MessageButton().setCustomId('info').setLabel('Utility').setStyle('SECONDARY').setEmoji('1282911182100893779'),
                new MessageButton().setCustomId('welcomer').setLabel('Welcomer').setStyle('SECONDARY').setEmoji('1282912853996863550')
            );

            const row2 = new MessageActionRow().addComponents(
                new MessageButton().setCustomId('voice').setLabel('Voice').setStyle('SECONDARY').setEmoji('1282911155932758056'),
                new MessageButton().setCustomId('customrole').setLabel('Custom Role').setStyle('SECONDARY').setEmoji('1282912819863359529'),
                new MessageButton().setCustomId('automod').setLabel('Automod').setStyle('SECONDARY').setEmoji('1282911182100893779'),
                new MessageButton().setCustomId('logging').setLabel('Logging').setStyle('SECONDARY').setEmoji('1282773321716338813')
            );

            const row3 = new MessageActionRow().addComponents(
                new MessageButton().setCustomId('owner').setLabel('Owner').setStyle('SECONDARY').setEmoji('1282912819863359529'),
                new MessageButton().setCustomId('fun').setLabel('Fun').setStyle('SECONDARY').setEmoji('1382311266747678810'),
                new MessageButton().setCustomId('music').setLabel('Music').setStyle('SECONDARY').setEmoji('1382310654786011207'),
                new MessageButton().setCustomId('giveaway').setLabel('Giveaway').setStyle('SECONDARY').setEmoji('1390275839651745882'),
                new MessageButton().setCustomId('extra').setLabel('Extra').setStyle('SECONDARY').setEmoji('1385569964047597589')
            );

            const embed = new MessageEmbed()
                .setColor(client.color)
                .setAuthor('CRIMINAL')
                .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
                .setImage('https://cdn.discordapp.com/attachments/1396113625390911570/1399319145497235548/49F42C7B-D688-4453-A930-9837C68A49F1.jpg?ex=68889102&is=68873f82&hm=0343f37ee59807420c48d65ae385e868cd3658044b85d9a2daeb6bf89f9108f9&')
                .setDescription(
                    `<a:Criminal_OP:1393509649545957416> **CRIMINAL**\nThe Best <a:Ind:1392424610233843722> Multipurpose Bot **CRIMINAL**\n\<a:Criminal_OP:1392930234507984946> Prefix for this server: \`${prefix}\`\n<a:Criminal_OP:1392930234507984946> Total Commands: \`${client.commands.size}\`\n\n[Add Me](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot) | [Support](https://discord.gg/vZKwA5gQ5K)\n\nType \`${prefix}bloodymode enable\` to improve security!`
                )
                .addField(
                    '__Modules__',
                    `<a:emoji_3:1396594967866114169> \`:\` **Security**\n<:crime:1397323821517766799> \`:\` **Moderation**\n<:emoji_18:1396600095658737684> \`:\` **Extra**\n<:crime:1397325916430143518> \`:\` **Welcomer**\n<:emoji_32:1397329372662464512> \`:\`**Voice**\n<:emoji_33:1397332297547513876> \`:\`**Customrole**\n<:emoji_31:1397328443187789864> \`:\` **Logs**\n<:emoji_18:1396600095658737684> \`:\` **Automod**\n<:crime:1397324509689679945> \`:\` **Music**\n<:emoji_21:1396600628809306183>  **: Owner**\n<:crime:1397324662198763641>** :  Fun**\n<a:Criminal_OP:1390275839651745882> **: Giveaway**`,
                    true
                )
                .setFooter('Developed With ❤ By TEAM CRIMINAL');

            const helpMessage = await message.channel.send({ embeds: [embed], components: [new MessageActionRow().addComponents(selectMenu), row1, row2, row3] });

            const collector = helpMessage.createMessageComponentCollector({
                filter: (i) => i.user.id === message.author.id,
                time: 60000
            });
            collector.on('collect', async (i) => {
                let category = i.customId || i.values?.[0];
                let commands = [];

                const categoryMap = {
                    antinuke: 'security',
                    mod: 'mod',
                    info: 'info',
                    welcomer: 'welcomer',
                    voice: 'voice',
                    automod: 'automod',
                    customrole: 'customrole',
                    logging: 'logging',
                    owner: 'owner',
                    fun: 'fun',
                    music: 'music',
                    giveaway: 'giveaway',
                    extra: 'extra'
                };

                if (category === 'all') {
                    commands = client.commands.map((x) => `\`${x.name}\``);
                } else if (categoryMap[category]) {
                    commands = client.commands
                        .filter((x) => x.category && x.category.toLowerCase() === categoryMap[category].toLowerCase())
                        .map((x) => `\`${x.name}\``);
                }

                if (commands.length === 0 && category !== 'all') {
                    commands = client.commands.map((x) => `\`${x.name}\``);
                }

                const categoryEmbed = new MessageEmbed()
                    .setColor(client.color || '#00ffff')
                    .setAuthor(client.user.username, client.user.displayAvatarURL())
                    .setThumbnail(i.guild?.iconURL({ dynamic: true }) || client.user.displayAvatarURL({ dynamic: true }))
                    .setDescription(
                        `**${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n${
                            commands.length > 0
                                ? commands.join(', ')
                                : `No commands found in this category. Showing all commands:\n${client.commands.map((x) => `\`${x.name}\``).join(', ') || 'No commands loaded.'}`
                        }`
                    );

                await i.reply({ embeds: [categoryEmbed], ephemeral: true });
            });

            collector.on('end', () => {
                helpMessage.edit({ components: [] });
            });
        } catch (error) {
            console.error('Error in help command:', error);
            message.reply('Something went wrong while loading the help menu. Check the console for details.');
        }
    }
};