const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'gettemplate',
    aliases: ['gtemplate'],
    category: 'admin',
    premium: true,

    run: async (client, message, args) => {
        try {
            if (!message.member.permissions.has('ADMINISTRATOR')) {
                return message.channel.send({
                    content: `<a:No:1385572287763320994> You need \`ADMINISTRATOR\` permission to use this command.`,
                });
            }

            const filePath = path.join(process.cwd(), 'templates.json');

            if (!fs.existsSync(filePath)) {
                return message.channel.send({
                    content: `<a:No:1385572287763320994> No templates found. Use \`&savetemplate\` first.`,
                });
            }

            const storedTemplates = JSON.parse(fs.readFileSync(filePath));
            const guildTemplates = storedTemplates[message.guild.id];

            if (!guildTemplates || guildTemplates.length === 0) {
                return message.channel.send({
                    content: `<a:No:1385572287763320994> No templates saved for this server. Use \`&savetemplate\` first.`,
                });
            }

            // Optional: &gtemplate 2
            const index = parseInt(args[0], 10);
            if (!isNaN(index) && guildTemplates[index - 1]) {
                const t = guildTemplates[index - 1];
                const embed = new MessageEmbed()
                    .setAuthor(`Template #${index} - ${t.name}`, client.user.displayAvatarURL({ dynamic: true }))
                    .setThumbnail(message.guild.iconURL({ dynamic: true }))
                    .setColor(client.color)
                    .setTimestamp()
                    .setDescription(
                        `<a:Yes:1385574498488811541> **Template Data**\n\n` +
                        `**Name**: ${t.name}\n` +
                        `**Code**: \`${t.code}\`\n` +
                        `**Created At**: ${t.createdAt}\n` +
                        `**Channels**: ${t.channels?.length || 0} saved\n` +
                        `**Roles**: ${t.roles?.length || 0} saved\n\n` +
                        `**Template Link**: [Apply Template](https://discord.new/${t.code})`
                    )
                    .setFooter({ text: `Template ${index} of ${guildTemplates.length}` });

                return message.channel.send({ embeds: [embed] });
            }

            // Default: List all
            const list = guildTemplates.map((t, i) =>
                `\`${i + 1}.\` [${t.name}](https://discord.new/${t.code}) - Saved: \`${t.createdAt}\``
            ).join('\n');

            const embed = new MessageEmbed()
                .setAuthor(`Saved Templates for ${message.guild.name}`, client.user.displayAvatarURL({ dynamic: true }))
                .setColor(client.color)
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setDescription(
                    `<a:Yes:1385574498488811541> **Total Templates**: ${guildTemplates.length}\n\n` +
                    `${list}\n\n` +
                    `Use \`&gettemplate <number>\` to view full info of a specific one.`
                )
                .setFooter({ text: 'Developed By Vampire </>' })
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Gettemplate Error:', error);
            return message.channel.send({
                content: `<a:No:1385572287763320994> An error occurred:\n\`\`\`${error.message}\`\`\``,
            });
        }
    },
};
