const { MessageEmbed } = require("discord.js");
const moment = require("moment");

let DISCORD_EMPLOYEE = `<:Stafd:1387128188962082941>`;
let DISCORD_PARTNER = `<:Hah:1387128351423987823>`;
let BUGHUNTER_LEVEL_1 = `<:Hh:1387128561688903812>`;
let BUGHUNTER_LEVEL_2 = `<:Sa:1387128829377777764>`;
let HYPESQUAD_EVENTS = `<:Ss:1387129038811959357>`;
let HOUSE_BRAVERY = `<:Ui:1387129293783699638>`;
let HOUSE_BRILLIANCE = `<:Ui:1387129440487604275>`;
let HOUSE_BALANCE = `<:Ui:1387129652866322544>`;
let EARLY_SUPPORTER = `<:Team:1387129802544250921>`;
let TEAM_USER = `<:Ui:1387129966399066163>`;
let SYSTEM = `<:Ui:1387130150055055384>`;
let VERIFIED_BOT = `<:Hu:1387130344544800899>`;
let VERIFIED_DEVELOPER = `<:Hu:1387130539999494215>`;
let ACTIVE_DEVELOPER = `<:Ah:1387130731519541332> `;

module.exports = {
    name: "userinfo",
    aliases: ['ui', 'whois'],
    category: 'info',
    description: "To Get Information About A User",
    run: async (client, message, args) => {
        
        let user;
        if(!args[0]) user = message.author;
        else{user = message.mentions.users.first() || client.users.cache.get(args[0])}
        let me = message.guild.members.cache.get(user.id);
        
        if(me)
        {
            let flags = '';
            let userFlags = me.user.flags.toArray();
            if(userFlags.includes('DISCORD_EMPLOYEE')) flags += ` ${DISCORD_EMPLOYEE}`;
            if(userFlags.includes('DISCORD_PARTNER')) flags += ` ${DISCORD_PARTNER}`;
            if(userFlags.includes('BUGHUNTER_LEVEL_1')) flags += ` ${BUGHUNTER_LEVEL_1}`;
            if(userFlags.includes('BUGHUNTER_LEVEL_2')) flags += ` ${BUGHUNTER_LEVEL_2}`;
            if(userFlags.includes('HYPESQUAD_EVENTS')) flags += ` ${HYPESQUAD_EVENTS}`;
            if(userFlags.includes('HOUSE_BRAVERY')) flags += ` ${HOUSE_BRAVERY}`;
            if(userFlags.includes('HOUSE_BRILLIANCE')) flags += ` ${HOUSE_BRILLIANCE}`;
            if(userFlags.includes('HOUSE_BALANCE')) flags += ` ${HOUSE_BALANCE}`;
            if(userFlags.includes('EARLY_SUPPORTER')) flags += ` ${EARLY_SUPPORTER}`;
            if(userFlags.includes('TEAM_USER')) flags += ` ${TEAM_USER}`;
            if(userFlags.includes('SYSTEM')) flags += ` ${SYSTEM}`;
            if(userFlags.includes('VERIFIED_BOT')) flags += ` ${VERIFIED_BOT}`;
            if(userFlags.includes('VERIFIED_DEVELOPER')) flags += ` ${VERIFIED_DEVELOPER}`;
            if(userFlags.includes('ACTIVE_DEVELOPER')) flags += ` ${ACTIVE_DEVELOPER}`;
            if(flags === '') flags = `${client.emoji.cross} Null User Badges`;

            let keys = '';
            let f = me.permissions.toArray();
            if(f.includes('ADMINISTRATOR')) keys = `Server Administrator`;
            if(f.includes(['MODERATE_MEMBERS','KICK_MEMBERS','BAN_MEMBERS'])) keys = 'Server Moderator';
            if(me.user.id === message.guild.ownerId) keys = 'Server Owner';
            else keys = 'Server Member';
            
            let emb = new MessageEmbed().setColor(`#ff0000`).setAuthor({name : `${me.user.tag}'s Information` , iconURL : me.user.displayAvatarURL({dynamic : true})}).setThumbnail(me.user.displayAvatarURL({dynamic : true})).addFields([
                {
                    name : `__General Information__`,
                    value : `**UserName** : ${me.user.username} \n **User Id** : ${me.user.id} \n **Nickname** : ${me.nickname ? me.nickname : 'None'} \n **Bot?** : ${me.user.bot ? `<a:Yes:1385574498488811541>` : `<a:No:1385572287763320994>`} \n **Discord Badges** : ${flags} \n **Account Created** : <t:${Math.round(me.user.createdTimestamp / 1000)}:R> \n **Server Joined** : <t:${Math.round(me.joinedTimestamp / 1000)}:R>`
                },
                {
                    name : `__Roles Info__`,
                    value : `**Highest Role** : ${me.roles.highest} \n **Roles [${me.roles.cache.size}]** : ${me.roles.cache.size < 0 ? [...me.roles.cache.values()].sort((a,b) => b.rawPosition - a.rawPosition).map(r => `<@&${r.id}>`).join(', ') : me.roles.cache.size > 30 ? trimArray(me.roles.cache) : 'NO ROLES'}`
                },
                {
                    name : `__Key Permissions__`,
                    value : `${me.permissions.toArray().sort((a,b) => a.localeCompare(b)).map(x => `\`${x}\``).join(', ')}`
                },
                {
                    name : `__Acknowledgement__`,
                    value : `${keys}`
                }
            ]).setFooter({text : `Requested By : ${message.author.tag}` , iconURL : message.author.displayAvatarURL({dynamic : true})});
            return message.channel.send({embeds : [emb]});
        }
        if(!me)
        {
            let flags = '';
            let userFlags = me.user.flags.toArray();
            if(userFlags.includes('DISCORD_EMPLOYEE')) flags += ` ${DISCORD_EMPLOYEE}`;
            if(userFlags.includes('DISCORD_PARTNER')) flags += ` ${DISCORD_PARTNER}`;
            if(userFlags.includes('BUGHUNTER_LEVEL_1')) flags += ` ${BUGHUNTER_LEVEL_1}`;
            if(userFlags.includes('BUGHUNTER_LEVEL_2')) flags += ` ${BUGHUNTER_LEVEL_2}`;
            if(userFlags.includes('HYPESQUAD_EVENTS')) flags += ` ${HYPESQUAD_EVENTS}`;
            if(userFlags.includes('HOUSE_BRAVERY')) flags += ` ${HOUSE_BRAVERY}`;
            if(userFlags.includes('HOUSE_BRILLIANCE')) flags += ` ${HOUSE_BRILLIANCE}`;
            if(userFlags.includes('HOUSE_BALANCE')) flags += ` ${HOUSE_BALANCE}`;
            if(userFlags.includes('EARLY_SUPPORTER')) flags += ` ${EARLY_SUPPORTER}`;
            if(userFlags.includes('TEAM_USER')) flags += ` ${TEAM_USER}`;
            if(userFlags.includes('SYSTEM')) flags += ` ${SYSTEM}`;
            if(userFlags.includes('VERIFIED_BOT')) flags += ` ${VERIFIED_BOT}`;
            if(userFlags.includes('VERIFIED_DEVELOPER')) flags += ` ${VERIFIED_DEVELOPER}`;
            if(userFlags.includes('ACTIVE_DEVELOPER')) flags += ` ${ACTIVE_DEVELOPER}`;
            if(flags === '') flags = `${client.emoji.cross} Null User Badges`;

            let em = new MessageEmbed().setColor(`#ff0000`).setAuthor({name : `${user.username}'s Information` , iconURL : user.displayAvatarURL({dynamic : true})}).addFields([
                {
                    name : `__General Information__`,
                    value : `**UserName** : ${user.username} \n **User ID** : ${user.id} \n **Bot?** : ${user.bot ? `${client.emoji.tick}` : `${client.emoji.cross}`} \n **Discord Badges** : ${flags} \n **Account Created** : <t:${Math.round(user.createdTimestamp / 1000)}:R>`
                }
            ]).setFooter({text : `Requested By : ${message.author.tag} | This User is not from this guild` , iconURL : message.author.displayAvatarURL({dynamic : true})}).setThumbnail(user.displayAvatarURL({dynamic : true}));

            return message.channel.send({embeds : [em]});
        }
        else{
            return message.channel.send({embeds : [new MessageEmbed().setColor(`#ff0000`).setDescription(`${client.emoji.cross} | I was unable to find the user.`)]})
        }
    }
}

function trimArray(arr, maxLen = 25) {
    if ([...arr.values()].length > maxLen) {
      const len = [...arr.values()].length - maxLen;
      arr = [...arr.values()].sort((a, b) => b?.rawPosition - a.rawPosition).slice(0, maxLen);
      arr.map(role => `<@&${role.id}>`)
      arr.push(`${len} more...`);
    }
    return arr.join(", ");
}