const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'savetemplate',
    aliases: ['stemplate'],
    category: 'admin',
    premium: true,

    run: async (client, message, args) => {
        try {
            if (!message.member.permissions.has('ADMINISTRATOR')) {
                return message.channel.send({
                    content: `<a:No:1385572287763320994> You need \`ADMINISTRATOR\` permission to use this command.`,
                });
            }

            const filePath = path.join(process.cwd(), 'templates.json');
            let storedTemplates = {};

            if (fs.existsSync(filePath)) {
                storedTemplates = JSON.parse(fs.readFileSync(filePath));
            }

            if (!storedTemplates[message.guild.id]) {
                storedTemplates[message.guild.id] = [];
            }

            // Fetch existing templates
            const existingTemplates = await message.guild.fetchTemplates();

            let template;
            if (existingTemplates.size > 0) {
                // Use existing one
                template = existingTemplates.first();
            } else {
                // Create new if none exists
                const name = `Backup of ${message.guild.name}`;
                const description = 'Auto-created server template';
                template = await message.guild.createTemplate(name, description);
            }

            // Add current backup info (multi-template support locally)
            storedTemplates[message.guild.id].push({
                code: template.code,
                name: template.name,
                createdAt: new Date().toISOString(),
                channels: message.guild.channels.cache.map(c => ({
                    id: c.id,
                    name: c.name,
                    type: c.type,
                    position: c.position,
                })),
                roles: message.guild.roles.cache.map(r => ({
                    id: r.id,
                    name: r.name,
                    color: r.color,
                    position: r.position,
                })),
            });

            fs.writeFileSync(filePath, JSON.stringify(storedTemplates, null, 2));

            const embed = new MessageEmbed()
                .setAuthor(`Template Saved`, client.user.displayAvatarURL({ dynamic: true }))
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setColor(client.color)
                .setTimestamp()
                .setDescription(
                    `<a:Yes:1385574498488811541> **Template Saved Successfully!**\n\n` +
                    `**Template Name**: ${template.name}\n` +
                    `**Code**: \`${template.code}\`\n` +
                    `Use \`&gettemplate\` to view saved templates.`
                )
                .setFooter({ text: 'Developed By Vampire </>' });

            return message.channel.send({ embeds: [embed] });

        } catch (err) {
            console.error('savetemplate error:', err);
            return message.channel.send({
                content: `<a:No:1385572287763320994> Failed to save template:\n\`\`\`${err.message}\`\`\``
            });
        }
    },
};
