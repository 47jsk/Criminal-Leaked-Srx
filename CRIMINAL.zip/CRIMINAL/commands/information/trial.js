const fs = require('fs');
const path = require('path');
const { MessageEmbed, WebhookClient } = require('discord.js');

module.exports = {
  name: 'trial',
  description: 'Claim a 7-day no-prefix trial.',
  aliases: ['claimtrial'],
  category: 'noprefix',
  cooldown: 10,
  run: async (client, message) => {
    const userId = message.author.id;
    const filePath = path.join(__dirname, '../../data/noprefix.json');
    const webhookURL = 'https://discord.com/api/webhooks/1397960531897221260/mDDm3JdfW9emNuIJ_Not3USfWEFDweIjpR8y3vs87CaW7pk3rwOI34pTRBN33iuKXu87'; // Replace with your actual webhook

    if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify({ users: [] }, null, 2));
    const data = JSON.parse(fs.readFileSync(filePath));

    const existing = data.users.find(u => u.id === userId);
    if (existing) {
      const embed = new MessageEmbed()
        .setColor('RED')
        .setTitle(`${client.emoji.tick} Trial Already Claimed`)
        .setDescription(`${client.emoji.cross} You've already claimed your 7-day trial.\n Expires <t:${Math.floor(existing.expiresAt / 1000)}:R>`);
      return message.channel.send({ embeds: [embed] });
    }

    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
    data.users.push({ id: userId, expiresAt });
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

    const embed = new MessageEmbed()
      .setColor(client.color)
      .setTitle(`${client.emoji.tick} Trial Claimed`)
      .setDescription(`You have claimed a **7-day no-prefix trial**!\n You will automatically receive no-prefix access within 1 hour.\n⏰ Expires: <t:${Math.floor(expiresAt / 1000)}:F>`)
      .setFooter({ text: 'Enjoy using the bot without any prefix!' });

    message.channel.send({ embeds: [embed] });

    try {
      await message.author.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setTitle(`${client.emoji.tick} Trial Claimed`)
            .setDescription(`You've successfully claimed a no-prefix trial.\nPlease wait up to **1 hour** for activation.\n Trial Expires: <t:${Math.floor(expiresAt / 1000)}:F>`)
        ]
      });
    } catch (err) {
      console.log(`[TRIAL] Failed to DM user: ${message.author.tag}`);
    }

    // Log via webhook
    const log = new WebhookClient({ url: webhookURL });
    log.send({
      embeds: [
        new MessageEmbed()
          .setTitle(`${client.emoji.tick} Trial Claimed`)
          .setColor('ff0000')
          .addFields(
            { name: 'User', value: `${message.author.tag} (${userId})`, inline: true },
            { name: 'Expires', value: `<t:${Math.floor(expiresAt / 1000)}:F>`, inline: true },
            { name: 'Server', value: `${message.guild.name} (${message.guildId})`, inline: false }
          )
          .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
          .setTimestamp()
      ]
    });
  }
};