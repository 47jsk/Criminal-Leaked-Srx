const { MessageEmbed } = require('discord.js');
const fs = require('fs');

// 🔧 Auto-save badge to badges.json
function addBadge(userId, badgeName) {
    const path = 'badges.json';

    let data = { users: {} };
    try {
        if (fs.existsSync(path)) {
            data = JSON.parse(fs.readFileSync(path, 'utf8'));
        }
    } catch (err) {
        console.error('Failed to read badges.json:', err);
    }

    if (!data.users[userId]) {
        data.users[userId] = [];
    }

    if (!data.users[userId].includes(badgeName)) {
        data.users[userId].push(badgeName);
        try {
            fs.writeFileSync(path, JSON.stringify(data, null, 2));
            console.log(`✅ Badge "${badgeName}" added for user ${userId}`);
        } catch (err) {
            console.error('Failed to write to badges.json:', err);
        }
    }
}

module.exports = {
    name: 'profile',
    aliases: ['badge', 'badges', 'achievement', 'pr'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        try {
            const user =
                message.mentions.users.first() ||
                client.users.cache.get(args[0]) ||
                message.author;

            const OWNER_ID = '1354343474186686607';
            const isOwner = user.id === OWNER_ID;
            let badges = '';

            const emojiMap = {
                "Ꮩᴀᴍᴘɪʀᴇ": "<:Dev:1385898713913888850>",
                "Developer": "<a:Hs:1385902399809523774>",
                "Owner": "<a:Ha:1385641359200882688>",
                "Admin": "<:Hehe:1385570711229173872>",
                "Mod": "<:CyberGuard_OP:1385582040539201636>",
                "Support Team": "<:Hehe:1385569557988511785>",
                "NoPrefix": "<:Share:1382246376250802318>",
                "Bug Hunter": "<:Hah:1385901918160945237>",
                "Premium User": "<:Hah:1385901735037370428>",
                "Friends": "<:Hah:1385901918160945237>",
                "Member": "<:Sha:1385902206326407240>",
                "VIP": "<:stolen_emoji:1370997905560702997>",
                "Legend": "<:SP_coolcat:1360982778044219686>",
                "Tester": "<:Crown:1361338488850616441>"
            };

            const allBadgeNames = Object.keys(emojiMap);

            // 👑 Owner gets all badges
            if (isOwner) {
                badges += `\n${emojiMap["Vampire"]}・**[Ꮩᴀᴍᴘɪʀᴇ..!!](https://discord.com/users/${OWNER_ID})**`;
                for (const badge of allBadgeNames) {
                    if (badge === 'Vampire') continue;
                    badges += `\n${emojiMap[badge]}・**${badge}**`;
                    addBadge(user.id, badge);
                }
            }

            // 📖 Load user badges from badges.json
            try {
                const data = JSON.parse(fs.readFileSync('badges.json', 'utf8'));
                if (data.users && data.users[user.id]) {
                    const customBadges = data.users[user.id];
                    customBadges.forEach(badge => {
                        const emoji = emojiMap[badge] || '<:tharki_baccha:1370999005483372585>';
                        if (!badges.includes(`**${badge}**`)) {
                            badges += `\n${emoji}・**${badge}**`;
                        }
                    });
                }
            } catch (error) {
                console.error('Error reading badges.json:', error);
            }

            if (!badges.trim()) badges = '`No Badge Available`';

            const embed = new MessageEmbed()
                .setAuthor(
                    `Profile For ${user.username}#${user.discriminator}`,
                    client.user.displayAvatarURL({ dynamic: true })
                )
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setColor('#FF0000') // 🔴 Red color
                .setTimestamp()
                .setDescription(`**BADGES** <a:Hs:1385902399809523774>\n${badges}`);

            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Command error:', error);
            await message.channel.send({
                content: 'An error occurred while executing the command. Please try again later.',
            });
        }
    },
};
