const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'info',
    aliases: ['privacy', 'policy'],
    description: 'Shows privacy policy of the bot',
    category: 'info',
    cooldown: 3,
    usage: '&info',

    run: async (client, message, args) => {
        const embed = new MessageEmbed()
            .setColor(client.color)
                    .setAuthor({
                name: '!        Ꮩᴀᴍᴘɪʀᴇ  ..!!',
                iconURL: 'https://cdn.discordapp.com/attachments/1364901008450261084/1387507341817282601/996a553075dfa89f035882bcad825874.webp'
            })
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setTitle('Privacy Policy')
            .setDescription(`**StarX respects your privacy. This Privacy Policy outlines what information we collect, how we use it, and your rights regarding your data. By using the Bot, you agree to the terms in this Privacy Policy.

⸻

2. Data We Collect

We may collect the following information:
	•	User Data: User ID, usernames, and message content (only when commands are used).
	•	Server Data: Server ID, channel/role IDs, and server-specific settings for configuration.
	•	Activity Logs: Command usage and moderation logs (if enabled).

⸻

3. How We Use Your Data

We use your data solely to:
	•	Deliver and improve bot features
	•	Maintain configuration settings per server
	•	Enforce moderation systems (e.g., anti-nuke, automod)
	•	Respond to support or abuse reports

We do not use your data for marketing or advertising purposes.

⸻

4. Data Storage and Security

All data is stored securely in [MongoDB / JSON files / encrypted databases — adjust this]. We take steps to protect your data from unauthorized access or loss. Access to bot data is restricted to the developers only.

⸻

5. Data Sharing

We do not share your data with any third-party services, advertisers, or external platforms. Data is only used internally for bot functionality.

⸻

6. Your Rights
	•	You may request a copy or deletion of your server or user data by contacting the bot developer.
	•	If you remove the bot from your server, its configuration and data will be automatically deleted within [2 days].

⸻

7. Discord’s DMCA Policy

We comply with Discord’s DMCA Policy and all applicable copyright laws. If your server, bot usage, or content violates any copyright, you may receive a warning, takedown, or report per Discord’s Terms of Service.

If you believe that content shared via the bot infringes your copyright, you can:
	•	Report it to the server owner directly
	•	Submit a takedown request through Discord’s DMCA form

⸻

8. Contact Us

For privacy concerns, data requests, or copyright questions, contact:
Developer: [1vfr.](https://discord.com/users/135434347418816667)
[Support Server](https://discord.gg/RwQ4vhNKxg)

⸻

By using StarX, you agree to this Privacy Policy and Discord’s Terms of Service.**`
                
            )
            .setFooter({
                text: `StarX • Your Security, Our Priority`,
                iconURL: client.user.displayAvatarURL(),
            })
            .setTimestamp();

        return message.reply({ embeds: [embed] });
    },
};