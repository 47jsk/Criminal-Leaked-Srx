const { Message, Client, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'addemoji',
    aliases: ['addemote', 'steal'],
    cooldown: 5,
    category: 'info',
    run: async (client, message, args) => {
        const prefix = message.guild.prefix || require(`${process.cwd()}/config.json`).prefix || '!';

        // Permission checks
        if (!message.member.permissions.has('MANAGE_EMOJIS')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | You must have \`Manage Emojis\` permission to use this command.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (!message.guild.me.permissions.has('MANAGE_EMOJIS')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | I must have \`Manage Emojis\` permission to use this command.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Show usage if no arguments provided
        if (!args.length) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('<:Isssianan:1388776216101785732> Add Emoji Command Info')
                        .setDescription(
                            `This command allows you to steal multiple emojis from other servers and add them to this server.\n\n` +
                            `**Usage:**\n` +
                            `\`${prefix}addemoji <emoji1> [name1] <emoji2> [name2] ...\` - Steal one or more emojis with optional custom names\n` +
                            `Example: \`${prefix}addemoji <:pepe:123456789012345678> pepe2 <a:catdance:987654321098765432>\``
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Process emojis
        let successCount = 0;
        let failureCount = 0;
        const errors = [];
        let i = 0;

        while (i < args.length) {
            const emoji = args[i];
            // Parse emoji (format: <:name:ID> or <a:name:ID>)
            const emojiMatch = emoji.match(/<a?:(\w+):(\d+)>/);
            if (!emojiMatch) {
                failureCount++;
                errors.push(`<a:No:1385572287763320994> Invalid emoji format: ${emoji}`);
                i++;
                continue;
            }

            const [, defaultName, emojiId] = emojiMatch;
            const isAnimated = emoji.startsWith('<a:');
            const emojiUrl = `https://cdn.discordapp.com/emojis/${emojiId}.${isAnimated ? 'gif' : 'png'}?size=256`;
            // Use provided name or fallback to default emoji name or 'Criminal_OP'
            const name = args[i + 1] && !args[i + 1].match(/<a?:.+:\d+>/) ? args[i + 1] : defaultName || 'Criminal_OP';

            try {
                await message.guild.emojis.create(emojiUrl, name, {
                    reason: `Stolen by ${message.author.tag} via addemoji command`
                }).then((newEmoji) => {
                    successCount++;
                    errors.push(`<a:Yes:1385574498488811541> Successfully added emoji ${newEmoji.toString()} as \`${name}\`.`);
                });
                i += args[i + 1] && !args[i + 1].match(/<a?:.+:\d+>/) ? 2 : 1; // Skip name if provided
            } catch (err) {
                failureCount++;
                let errorMsg = `<a:No:1385572287763320994> Failed to add emoji: ${emoji} as \`${name}\``;
                if (err.code === 50013) {
                    errorMsg += ' (Missing permissions)';
                } else if (err.code === 50035) {
                    errorMsg += ' (Server emoji limit reached or invalid name)';
                } else {
                    errorMsg += ` (Error: ${err.message})`;
                }
                errors.push(errorMsg);
                i += args[i + 1] && !args[i + 1].match(/<a?:.+:\d+>/) ? 2 : 1;
            }
        }

        // Send result embed
        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setTitle('<:Danger:1388776040108658730> Emoji Steal Results')
                    .setDescription(
                        successCount > 0
                            ? `<a:Yes:1385574498488811541> Successfully added ${successCount} emoji(s).\n`
                            : '' +
                              (failureCount > 0 ? `<a:No:1385572287763320994> Failed to add ${failureCount} emoji(s).\n` : '') +
                              (errors.length > 0 ? `\n**Details:**\n${errors.join('\n')}` : '')
                    )
                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};