const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'ginv',
    category: 'owner',
    description: 'Generate an invite link for a server based on its ID.',
    usage: 'ginv <serverid>',
    run: async (client, message, args) => {
        // Check if the message author is the owner (replace 'your_owner_id' with your actual Discord user ID)
        const ownerId = '1354343474186686607';
        if (message.author.id !== ownerId) {
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('This command is only for my owner you cannot use this command.');
            return message.channel.send({ embeds: [embed] });
        }

        // Check if a server ID is provided
        if (!args[0]) {
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Please provide a server ID.');
            return message.channel.send({ embeds: [embed] });
        }

        // Fetch the guild based on the provided server ID
        const guildId = args[0];
        const guild = client.guilds.cache.get(guildId);

        // Check if the guild exists
        if (!guild) {
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Invalid server ID. I could not find that server.');
            return message.channel.send({ embeds: [embed] });
        }

        // Create an invite for the guild
        try {
            const invite = await guild.invites.create(guild.channels.cache.filter(c => c.type === 'GUILD_TEXT').first(), {
                unique: true,
                maxAge: 86400, // 24 hours
                maxUses: 1 // Single use
            });

            // Send the invite link
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`Invite link for server **${guild.name}**: ${invite.url}`);
            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error creating invite:', error);
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Failed to create invite. Please try again later.');
            return message.channel.send({ embeds: [embed] });
        }
    }
};