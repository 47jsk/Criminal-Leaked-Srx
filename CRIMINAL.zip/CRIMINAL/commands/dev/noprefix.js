const { MessageEmbed, WebhookClient } = require('discord.js');

module.exports = {
    name: 'noprefix',
    aliases: ['np'],
    category: 'owner',
    run: async (client, message, args) => {
        // Define multiple owner IDs
        const ownerIDs = [
            '1354343474186686607', // Replace with first owner ID
            '1009836827248709662',     // Replace with second owner ID
            '1312402378397450358',    // Replace with third owner ID
            '1365897206535557121'    // Replace with third owner ID
            
        ];
        const config = require(`${process.cwd()}/config.json`);
        const { webhook_url } = config;

        // Check if the user is one of the bot owners
        if (!ownerIDs.includes(message.author.id)) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<a:No:1385572287763320994> This command is restricted to bot owners only.')
                ]
            });
        }

        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || '!'; // Default prefix fallback
        const action = args[0]?.toLowerCase();
        const userId = args[1];

        if (!['add', 'remove', 'list'].includes(action)) {
            return message.channel.send({
                embeds: [
                    embed.setDescription(
                        `<a:No:1385572287763320994> Please provide a valid action.\nUsage: \`${prefix}noprefix <add/remove/list> <user id>\``
                    )
                ]
            });
        }

        if (action === 'list') {
            const noprefixUsers = (await client.db.get(`noprefix_${client.user.id}`)) || [];
            const info = noprefixUsers.length
                ? noprefixUsers.map((id, idx) => `${idx + 1}. <@${id}> (${id})`).join('\n')
                : 'No users found.';

            return message.channel.send({
                embeds: [embed.setTitle('No Prefix Users').setDescription(info)]
            });
        }

        if (!userId || !/^\d{17,19}$/.test(userId)) {
            return message.channel.send({
                embeds: [
                    embed.setDescription(
                        `<a:No:1385572287763320994> Please provide a valid user ID.\nUsage: \`${prefix}noprefix ${action} <user id>\``
                    )
                ]
            });
        }

        const noprefixUsers = (await client.db.get(`noprefix_${client.user.id}`)) || [];
        const user = await client.users.fetch(userId).catch(() => null);

        if (!user) {
            return message.channel.send({
                embeds: [embed.setDescription('<a:No:1385572287763320994> Unable to find the specified user.')]
            });
        }

        const webhook = webhook_url ? new WebhookClient({ url: webhook_url }) : null;

        if (action === 'add') {
            if (noprefixUsers.includes(userId)) {
                return message.channel.send({
                    embeds: [
                        embed.setDescription(`<a:No:1385572287763320994> <@${userId}> is already in the No Prefix list.`)
                    ]
                });
            }

            noprefixUsers.push(userId);
            await client.db.set(`noprefix_${client.user.id}`, noprefixUsers);

            if (webhook) {
                webhook.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setTitle('No Prefix User Added')
                            .setDescription(`<a:Yes:1385574498488811541> <@${userId}> has been added to the No Prefix list.`)
                            .setTimestamp()
                            .setFooter(`Added by ${message.author.tag}`, message.author.displayAvatarURL())
                    ]
                });
            }

            return message.channel.send({
                embeds: [
                    embed.setDescription(`<a:Yes:1385574498488811541> <@${userId}> has been added to the No Prefix list.`)
                ]
            });
        }

        if (action === 'remove') {
            const updatedList = noprefixUsers.filter((id) => id !== userId);
            await client.db.set(`noprefix_${client.user.id}`, updatedList);

            if (webhook) {
                webhook.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setTitle('No Prefix User Removed')
                            .setDescription(`<a:No:1385572287763320994> <@${userId}> has been removed from the No Prefix list.`)
                            .setTimestamp()
                            .setFooter(`Removed by ${message.author.tag}`, message.author.displayAvatarURL())
                    ]
                });
            }

            return message.channel.send({
                embeds: [
                    embed.setDescription(`<a:Yes:1385574498488811541> <@${userId}> has been removed from the No Prefix list.`)
                ]
            });
        }
    }
};