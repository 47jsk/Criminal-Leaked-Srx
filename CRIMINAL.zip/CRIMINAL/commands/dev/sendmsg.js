const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'sendmsg',
    category: 'owner',
    description: 'Send a message to a specified channel by ID.',
    usage: 'sendmsg <channel.id> <message>',
    run: async (client, message, args) => {
        // Check if the message author is the owner (replace 'your_owner_id' with your actual Discord user ID)
        const ownerId = '1354343474186686607';
        if (message.author.id !== ownerId) {
            const embed = new MessageEmbed()
                .setColor('#ff0000')
                .setDescription('This command is only for my owner. You cannot use this command.');
            return message.channel.send({ embeds: [embed] });
        }

        // Check if both channel ID and message are provided
        if (args.length < 2) {
            const embed = new MessageEmbed()
                .setColor('#ff0000')
                .setDescription('Please provide both a channel ID and a message.');
            return message.channel.send({ embeds: [embed] });
        }

        const [channelId, ...messageContent] = args;
        const msg = messageContent.join(' ');

        // Fetch the channel based on the provided channel ID
        const channel = client.channels.cache.get(channelId);

        // Check if the channel exists and is a text channel
        if (!channel || channel.type !== 'GUILD_TEXT') {
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Invalid channel ID or the channel is not a text channel.');
            return message.channel.send({ embeds: [embed] });
        }

        // Send the message to the channel
        try {
            await channel.send(msg);
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Message sent successfully.');
            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error sending message:', error);
            const embed = new MessageEmbed()
                .setColor(client.color)
                .setDescription('Failed to send the message. Please try again later.');
            return message.channel.send({ embeds: [embed] });
        }
    } 
};