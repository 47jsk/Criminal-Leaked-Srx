const { MessageEmbed } = require('discord.js');

const owners = ['1354343474186686607', '1009836827248709662', 'OWNER_ID_3']; // Replace with your three owner IDs
module.exports = {
  name: 'globalban',
  aliases: ['gban'],
  category: 'owner',
  run: async (client, message, args) => {
    // Check if the user is one of the owners
    if (!owners.includes(message.author.id)) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000') // Use client.color or default to red
            .setDescription(`<a:No:1385572287763320994> | Only bot owners can use this command.`)
        ]
      });
    }

    // Check if a user ID or mention was provided
    let userId = args[0]?.replace(/[<@!>-]/g, ''); // Remove mention characters
    if (!userId) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | Please provide a valid user ID or mention a member.`)
        ]
      });
    }

    // Validate user ID
    let target;
    try {
      target = await client.users.fetch(userId);
    } catch (error) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | Invalid user ID or mention. Please try again.`)
        ]
      });
    }

    // Check if bot has BAN_MEMBERS permission in the current guild
    if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | I lack the \`Ban Members\` permission in this server.`)
        ]
      });
    }

    let successCount = 0;
    let failureCount = 0;
    const failures = [];

    // Hardcoded ban reason
    const banReason =
      'User has been globally banned due to repeated and severe violations of Discord\'s terms of service, including but not limited to harassment, nuking, spamming, distributing malicious content, and engaging in activities that undermine the safety and well-being of the Discord community. This global ban is a result of a pattern of behavior that is deemed unacceptable, and it is necessary to ensure the integrity and security of multiple servers on the platform.';

    // Iterate through all guilds
    for (const [_, guild] of client.guilds.cache) {
      try {
        // Check bot's permissions in this guild
        if (!guild.me.permissions.has('BAN_MEMBERS')) {
          failures.push(`${guild.name}: Missing Ban Members permission`);
          failureCount++;
          continue;
        }

        // Attempt to ban the user with a delay
        await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        await guild.members.ban(target.id, { reason: banReason });
        successCount++;
        await message.channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(client.color || '#00FF00') // Green for success
              .setDescription(`<a:Yes:1385574498488811541> | Banned ${target.tag} from ${guild.name}`)
          ]
        });
      } catch (error) {
        failures.push(`${guild.name}: ${error.message}`);
        failureCount++;
        await message.channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(client.color || '#FF0000')
              .setDescription(`<a:No:1385572287763320994> | Can't ban ${target.tag} from ${guild.name}`)
          ]
        });
      }
    }

    // Send summary
    const summaryEmbed = new MessageEmbed()
      .setColor(client.color || '#FFA500') // Orange for summary
      .setDescription(
        [
          `Global ban attempt for ${target.tag} (${target.id}):`,
          `<a:Yes:1385574498488811541> Successfully banned from ${successCount} server(s)`,
          `<a:No:1385572287763320994> Failed to ban from ${failureCount} server(s)`,
          failures.length > 0 ? '\n**Failures:**\n' + failures.map(f => `- ${f}`).join('\n') : ''
        ].join('\n')
      );

    await message.channel.send({ embeds: [summaryEmbed] });
  }
};