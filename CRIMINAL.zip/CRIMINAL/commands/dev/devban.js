const { MessageEmbed } = require('discord.js');

const botOwnerId = ['1312402378397450358', '1354343474186686607', '1365897206535557121'];

module.exports = {
  name: 'devban',
  aliases: ['db'],
  category: 'owner',
  run: async (client, message, args) => {
    // Check if the user is one of the owners
    if (!botOwnerId.includes(message.author.id)) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | Only the bot owner can use this command.`)
        ]
      });
    }

    // Check if a user ID or mention was provided
    let userId = args[0]?.replace(/[<@!>-]/g, ''); // Remove mention characters
    if (!userId) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | Please provide a valid user ID or mention a member.`)
        ]
      });
    }

    // Fetch user
    let user;
    try {
      user = await client.users.fetch(userId);
    } catch (error) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | Please provide a valid user ID or mention a member.`)
        ]
      });
    }

    // Check for self-ban
    if (user.id === message.author.id) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | You cannot ban yourself.`)
        ]
      });
    }

    // Check for bot ban
    if (user.id === client.user.id) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | You cannot ban the bot.`)
        ]
      });
    }

    // Check bot permissions
    if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | I don't have permission to ban members in this server.`)
        ]
      });
    }

    try {
      await message.guild.members.ban(user.id, {
        reason: 'User has been globally banned due to repeated and severe violations of Discord.'
      });

      await message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:Yes:1385574498488811541> | Successfully banned <@${user.id}> from the server.`)
        ]
      });
    } catch (error) {
      await message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color)
            .setDescription(`<a:No:1385572287763320994> | Failed to ban <@${user.id}>: ${error.message}`)
        ]
      });
    }
  }
};