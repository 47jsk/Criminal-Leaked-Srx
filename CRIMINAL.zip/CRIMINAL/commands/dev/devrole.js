const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'devrole',
  category: 'owner',
  description: 'Add a role to a user by finding the role ID.',
  usage: 'devrole <user_id> <role_id>',
  run: async (client, message, args) => {
    // Check if the message author is the owner (replace 'your_owner_id' with your actual Discord user ID)
    const ownerId = '1354343474186686607';
    if (message.author.id !== ownerId) {
      const embed = new MessageEmbed()
        .setColor(client.color)
        .setDescription('This command is only for my owner, you cannot use this command.');
      return message.channel.send({ embeds: [embed] });
    }

    // Check if user ID and role ID are provided
    if (!args[0] || !args[1]) {
      const embed = new MessageEmbed()
        .setColor(client.color)
        .setDescription('Please provide both user ID and role ID.');
      return message.channel.send({ embeds: [embed] });
    }

    // Find the user and role
    const userId = args[0];
    const roleId = args[1];
    const user = message.guild.members.cache.get(userId);
    const role = message.guild.roles.cache.get(roleId);

    // Check if user and role exist
    if (!user || !role) {
      const embed = new MessageEmbed()
        .setColor(client.color)
        .setDescription('Invalid user ID or role ID.');
      return message.channel.send({ embeds: [embed] });
    }

    // Add the role to the user
    try {
      await user.roles.add(role);
      const embed = new MessageEmbed()
        .setColor(client.color)
        .setDescription(`Added role ${role.name} to user ${user.user.tag}.`);
      return message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Error adding role:', error);
      const embed = new MessageEmbed()
        .setColor(client.color)
        .setDescription('Failed to add role. Please try again later.');
      return message.channel.send({ embeds: [embed] });
    }
  }
};