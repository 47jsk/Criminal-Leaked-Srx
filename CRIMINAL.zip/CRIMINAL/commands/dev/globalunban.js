const { MessageEmbed } = require('discord.js');

const owners = ['1354343474186686607', 'OWNER_ID_2', 'OWNER_ID_3']; // Replace with your three owner IDs
module.exports = {
  name: 'globalunban',
  aliases: ['gunban'],
  category: 'owner',
  run: async (client, message, args) => {
    // Check if the user is one of the owners
    if (!owners.includes(message.author.id)) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000') // Use client.color or default to red
            .setDescription(`<a:No:1385572287763320994> | Only bot owners can use this command.`)
        ]
      });
    }

    // Check if a user ID or mention was provided
    let userId = args[0]?.replace(/[<@!>-]/g, ''); // Remove mention characters
    if (!userId) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | Please provide a valid user ID or mention a member.`)
        ]
      });
    }

    // Validate user ID
    let target;
    try {
      target = await client.users.fetch(userId);
    } catch (error) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | Invalid user ID or mention. Please try again.`)
        ]
      });
    }

    // Check if bot has BAN_MEMBERS permission in the current guild
    if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || '#FF0000')
            .setDescription(`<a:No:1385572287763320994> | I lack the \`Ban Members\` permission in this server.`)
        ]
      });
    }

    let successCount = 0;
    let failureCount = 0;
    const failures = [];

    // Iterate through all guilds
    for (const [_, guild] of client.guilds.cache) {
      try {
        // Check bot's permissions in this guild
        if (!guild.me.permissions.has('BAN_MEMBERS')) {
          failures.push(`${guild.name}: Missing Ban Members permission`);
          failureCount++;
          continue;
        }

        // Check if the user is banned in this guild
        const banEntry = await guild.bans.fetch(target.id).catch(() => null);
        if (!banEntry) {
          failures.push(`${guild.name}: User is not banned`);
          failureCount++;
          continue;
        }

        // Attempt to unban the user with a delay
        await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        await guild.members.unban(target.id, 'Global unban executed by bot owner');
        successCount++;
        await message.channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(client.color || '#00FF00') // Green for success
              .setDescription(`<a:Yes:1385574498488811541> | Unbanned ${target.tag} from ${guild.name}`)
          ]
        });
      } catch (error) {
        failures.push(`${guild.name}: ${error.message}`);
        failureCount++;
        await message.channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(client.color || '#FF0000')
              .setDescription(`<a:No:1385572287763320994> | Can't unban ${target.tag} from ${guild.name}`)
          ]
        });
      }
    }

    // Send summary
    const summaryEmbed = new MessageEmbed()
      .setColor(client.color || '#FFA500') // Orange for summary
      .setDescription(
        [
          `Global unban attempt for ${target.tag} (${target.id}):`,
          `<a:Yes:1385574498488811541> Successfully unbanned from ${successCount} server(s)`,
          `<a:No:1385572287763320994> Failed to unban from ${failureCount} server(s)`,
          failures.length > 0 ? '\n**Failures:**\n' + failures.map(f => `- ${f}`).join('\n') : ''
        ].join('\n')
      );

    await message.channel.send({ embeds: [summaryEmbed] });
  }
};