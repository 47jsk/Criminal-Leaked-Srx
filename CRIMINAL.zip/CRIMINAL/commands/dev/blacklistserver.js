const { Message, MessageEmbed } = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'blacklistserver',
    aliases: ['bs'],
    category: 'owner',
    run: async (client, message, args) => {
        try {
            if (!config.admin.includes(message.author.id)) return;
            const embed = new MessageEmbed().setColor(client.color || '#FF0000');
            const prefix = config.prefix || '!';

            if (!args[0]) {
                return message.channel.send({
                    embeds: [embed.setDescription(`<a:No:1385572287763320994> Please provide the required arguments.\n${prefix}blacklistserver \`<add/remove/list>\` \`<server id>\``)]
                });
            }

            if (args[0].toLowerCase() === 'list') {
                let listing = (await client.data.get(`blacklistserver_${client.user.id}`)) || [];
                let info = [];
                if (listing.length < 1) info.push('No servers ;-;');
                else {
                    for (let i = 0; i < listing.length; i++) {
                        const ss = await client.guilds.fetch(listing[i]).catch(() => null);
                        if (ss) {
                            info.push(`${i + 1}) ${ss.name} (${ss.id})`);
                        } else {
                            listing = listing.filter(id => id !== listing[i]);
                            await client.data.set(`blacklistserver_${client.user.id}`, listing);
                        }
                    }
                }
                return await client.util.pagination(message, info, '**Blacklist Server List** :-');
            }

            if (!args[1] || !/^\d{17,19}$/.test(args[1])) {
                return message.channel.send({
                    embeds: [embed.setDescription('Please provide a valid server ID.')]
                });
            }

            const user = await client.guilds.fetch(args[1]).catch(() => null);
            if (!user) {
                return message.channel.send({
                    embeds: [embed.setDescription('<a:No:1385572287763320994> The bot is not in that server or the ID is invalid.')]
                });
            }

            let added = (await client.data.get(`blacklistserver_${client.user.id}`)) || [];
            const opt = args[0].toLowerCase();

            if (['add', 'a', '+'].includes(opt)) {
                added.push(user.id);
                added = client.util.removeDuplicates2(added);
                await client.data.set(`blacklistserver_${client.user.id}`, added);
                await client.util.blacklistserver();
                return message.channel.send({
                    embeds: [embed.setDescription(`<a:Yes:1385574498488811541> | **${user.name} (${user.id})** has been added as a **Blacklist** server.`)]
                });
            }

            if (['remove', 'r', '-'].includes(opt)) {
                added = added.filter(srv => srv !== user.id);
                added = client.util.removeDuplicates2(added);
                await client.data.set(`blacklistserver_${client.user.id}`, added);
                await client.util.blacklistserver();
                return message.channel.send({
                    embeds: [embed.setDescription(`<a:Yes:1385574498488811541> | **${user.name} (${user.id})** has been removed from a **Blacklist** server.`)]
                });
            }

            return message.channel.send({
                embeds: [embed.setDescription(`${prefix}blacklistserver \`<add/remove/list>\` \`<server id>\``)]
            });
        } catch (error) {
            console.error(error);
            return message.channel.send({
                embeds: [new MessageEmbed().setColor(client.color || '#ff0000').setDescription('<a:No:1385572287763320994> An error occurred while executing the command.')]
            });
        }
    }
};