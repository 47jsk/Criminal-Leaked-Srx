const { MessageEmbed } = require('discord.js');
const pm2 = require('pm2');

module.exports = {
    name: 'restart',
    aliases: ['rt'],
    category: 'owner',
    description: 'Restart the bot using PM2',
    ownerIDs: [
        '1354343474186686607',
        'ID_2',
        'ID_3',
        'ID_4'
    ], // Array of owner IDs

    run: async (client, message, args) => {
        // Check if the author is one of the bot owners
        if (!this.ownerIDs.includes(message.author.id)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color || '#FF0000')
                        .setDescription('You do not have permission to use this command.')
                ]
            });
        }

        // Confirm that the bot is running under PM2
        pm2.connect((err) => {
            if (err) {
                console.error('PM2 connection error:', err);
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color || '#FF0000')
                            .setDescription('Failed to connect to PM2.')
                    ]
                });
            }

            // Attempt to restart the bot using PM2
            pm2.restart('CyberGuard', (err, apps) => {
                pm2.disconnect(); // Disconnect from PM2 after operation

                if (err) {
                    console.error('PM2 restart error:', err);
                    return message.channel.send({
                        embeds: [
                            new MessageEmbed()
                                .setColor(client.color || '#FF0000')
                                .setDescription('**Failed to restart the bot.**')
                        ]
                    });
                }

                // If the restart was successful
                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color || '#00FF00')
                            .setDescription('Bot is restarting...')
                    ]
                });

                console.log('Bot restarted successfully');
            });
        });
    }
};