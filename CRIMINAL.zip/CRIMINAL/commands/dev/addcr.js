const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'devgive',
    aliases: ['devcr','addcr'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Define developer IDs (adjust as needed)
        const developers = ['Vampire', 'Star', 'Max', 'Prayag'].map(name => {
            // Simple mapping to IDs (replace with actual IDs)
            const idMap = {
                'Vampire': '1354343474186686607',
                'Star': 'USER_ID_2',
                'Max': 'USER_ID_3',
                'Prayag': 'USER_ID_4'
            };
            return idMap[name];
        });

        if (!developers.includes(message.author.id)) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Only developers can use this command!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (!args[0] || !args[1]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}devgive <user id/@user> <amount>\nGrants unlimited Cr to the specified user.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let targetId = args[0].replace(/[<@!>]*/g, '');
        let amount = parseInt(args[1]) || 0; // Allow 0 or negative for unlimited effect

        let target;
        try {
            target = await client.users.fetch(targetId);
        } catch {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Invalid user ID or mention.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let balance = await client.db.get(`currency_${target.id}`) || 0;
        balance += amount; // Add the specified amount (can be unlimited if set high)
        await client.db.set(`currency_${target.id}`, balance);

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Developer Cr Grant')
            .setDescription(`<:Yes:1385574498488811541> **${message.author.tag}** granted **${amount} Cr** to **${target.tag}**!\nNew balance: **${balance} Cr**.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};