const { MessageEmbed } = require('discord.js');

const botOwners = ['1365897206535557121','1354343474186686607','1009836827248709662']; // Add your owner IDs here

module.exports = {
    name: 'gwarn',
    aliases: ['gwarning'],
    category: 'Owner',
    run: async (client, message, args) => {
        // Check if the user is a bot owner
        if (!botOwners.includes(message.author.id)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> | You don't have permission to use this command.`)
                ]
            });
        }

        // Extract user mention or ID
        let userId = args[0];
        if (!userId) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> | Please provide a valid user ID or mention a user.`)
                ]
            });
        }

        // Fetch the user object
        let user;
        try {
            user = await client.users.fetch(userId.replace(/[<@!>]/g, ''));
        } catch (error) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:No:1385572287763320994> | Unable to fetch user. Please check the provided ID.`)
                ]
            });
        }

        // Send warning as a DM
        try {
            const embed = new MessageEmbed()
                .setTitle('Criminal Warning <a:Danger:1385575952066543687>')
                .setDescription(
                    `You have received a warning from the server: **${message.guild.name}**.\n\n` +
                    `**Reason:** ${args.slice(1).join(' ') || 'No specific reason provided.'}`
                )
                .setColor(client.color) // Black color
                .setFooter('Please ensure you follow the server rules to avoid further action.');

            await user.send({ embeds: [embed] });

            // Confirmation message
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<a:Danger:1385575952066543687> Successfully sent a warning to **${user.tag}**.`)
                ]
            });
        } catch (error) {
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('RED')
                        .setDescription(`<a:No:1385572287763320994> | Failed to send a warning. The user might have DMs disabled.`)
                ]
            });
        }
    }
};