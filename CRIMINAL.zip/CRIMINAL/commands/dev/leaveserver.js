const { MessageEmbed } = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = {
  name: `leaveserver`,
  category: `Owner,Admin`,
  aliases: ['leaveserver', `gl`, `gleave`],
  description: `Leaves a guild by server ID.`,
  run: async (client, message, args) => {
    // Check if user is admin
    if (!config.admin.includes(message.author.id)) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || 'RED')
            .setDescription(
              `<a:No:1385572287763320994> | You are not authorized to use this command.`
            )
        ]
      });
    }

    // Check if guild ID is provided
    const id = args[0];
    if (!id) {
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || 'RED')
            .setDescription(
              `<a:No:1385572287763320994> | You didn't provide a server ID.`
            )
        ]
      });
    }

    // Check cache first
    let guild = client.guilds.cache.get(id);
    if (!guild) {
      try {
        guild = await client.guilds.fetch(id);
      } catch (error) {
        console.error(`Error fetching guild ${id}:`, error);
        return message.channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(client.color || 'RED')
              .setDescription(
                `<a:No:1385572287763320994> | Invalid server ID or bot is not in the server.`
              )
          ]
        });
      }
    }

    // Get guild name
    const name = guild?.name || 'No Name Found';

    // Attempt to leave the guild
    try {
      await guild.leave();
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || 'GREEN')
            .setDescription(
              `<a:Yes:1385574498488811541> | Successfully left **${name} (${id})**.`
            )
        ]
      });
    } catch (error) {
      console.error(`Error leaving guild ${id}:`, error);
      return message.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor(client.color || 'RED')
            .setDescription(
              `<a:No:1385572287763320994> | Failed to leave **${name} (${id})**. Error: ${error.message}`
            )
        ]
      });
    }
  }
};