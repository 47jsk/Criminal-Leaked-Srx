const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'unmuteall',
    aliases: ['uma'],
    category: 'mod',
    premium: false,

    run: async (client, message, args) => {
        // Check if the user has the required permissions
        if (!message.member.permissions.has('MODERATE_MEMBERS')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<a:No:1385572287763320994> | You must have \`Timeout Members\` permissions to use this command.`
                        )
                ]
            });
        }

        // Check if the bot has the required permissions
        if (!message.guild.me.permissions.has('MODERATE_MEMBERS')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<a:No:1385572287763320994> | I must have \`Timeout Members\` permissions to run this command.`
                        )
                ]
            });
        }

        // Get all members who are currently timed out
        const timedOutMembers = message.guild.members.cache.filter(
            member => member.communicationDisabledUntilTimestamp > Date.now()
        );

        // If no members are timed out
        if (timedOutMembers.size === 0) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(
                            `<a:No:1385572287763320994> | No members are currently muted in this server.`
                        )
                ]
            });
        }

        // Reason for unmute
        let reason = args.join(' ').trim() || 'No Reason';
        reason = `${message.author.tag} (${message.author.id}) | ${reason}`;

        // Unmute all timed-out members
        let successCount = 0;
        let failCount = 0;

        for (const member of timedOutMembers.values()) {
            const response = await unTimeoutTarget(message.member, member, reason);
            if (response === true) {
                successCount++;
            } else {
                failCount++;
            }
        }

        // Send response
        const description = `<a:Yes:1385574498488811541> | Successfully unmuted ${successCount} member(s)!` +
            (failCount > 0 ? `\n<a:No:1385572287763320994> | Failed to unmute ${failCount} member(s) due to permission issues or errors.` : '');
        
        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(description)
            ]
        });
    }
};

// Reuse the unTimeoutTarget function from unmute.js
async function unTimeoutTarget(issuer, target, reason) {
    if (!memberInteract(issuer, target)) return 'MEMBER_PERM';
    if (!memberInteract(issuer.guild.me, target)) return 'BOT_PERM';
    if (target.communicationDisabledUntilTimestamp - Date.now() < 0) return 'NO_TIMEOUT';

    try {
        await target.timeout(0, reason);
        return true;
    } catch (ex) {
        return 'ERROR';
    }
}

// Reuse the memberInteract function from unmute.js
function memberInteract(issuer, target) {
    const { guild } = issuer;
    if (guild.ownerId === issuer.id) return true;
    if (guild.ownerId === target.id) return false;
    return issuer.roles.highest.position > target.roles.highest.position;
}

// Reuse the getEmbed function from unmute.js
function getEmbed(title, client) {
    let embed = new MessageEmbed().setColor(client.color).setDescription(title);
    return { embeds: [embed] };
}