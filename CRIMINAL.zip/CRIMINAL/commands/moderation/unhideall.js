const Discord = require('discord.js');
const cooldown = new Set();

module.exports = {
  name: "unhideall",
  premium: true,
  run: async(client, message, args) => {
    if (!message.member.permissions.has("MANAGE_CHANNELS")) return message.channel.send("You don't have permission to use this command.");
    
    if (cooldown.has(message.author.id)) {
      return message.reply("Please wait 10 seconds before using this command again.");
    }
    cooldown.add(message.author.id);
    setTimeout(() => cooldown.delete(message.author.id), 10000);

    message.guild.channels.cache.forEach(channel => {
      channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        VIEW_CHANNEL: true
      }).catch(err => {});
    });

    message.channel.send("👁️ | All channels have been unhidden.");
  }
}
