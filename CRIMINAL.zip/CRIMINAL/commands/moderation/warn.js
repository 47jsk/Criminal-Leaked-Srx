const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'warn',
    aliases: ['warning'],
    category: 'mod',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        if (!message.member.permissions.has('MODERATE_MEMBERS')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You need MODERATE_MEMBERS permission to warn users!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const target = message.mentions.members.first();
        if (!target) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}warn @user [reason]\nWarn a user with an optional reason!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (target.id === message.author.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You can’t warn yourself!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const reason = args.slice(1).join(' ') || 'No reason provided.';
        const warnKey = `warnings_${message.guild.id}_${target.id}`;
        const currentWarnings = await client.db.get(warnKey) || [];

        const newWarn = {
            id: Date.now(),
            moderator: message.author.id,
            reason: reason,
            timestamp: new Date().toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })
        };
        currentWarnings.push(newWarn);
        await client.db.set(warnKey, currentWarnings);

        const totalWarnings = currentWarnings.length;
        const warnEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('⚠️ Warning Issued')
            .setDescription(`👤 **${target.user.tag}** has been warned by ${message.author.tag}.\n**Reason:** ${reason}\n**Total Warnings:** ${totalWarnings}`)
            .setFooter({ text: `Guild: ${message.guild.name}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        // Send to channel
        await message.channel.send({ embeds: [warnEmbed] });

        // Send to DM
        try {
            await target.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('⚠️ You Have Been Warned')
                        .setDescription(`You have been warned in **${message.guild.name}** by ${message.author.tag}.\n**Reason:** ${reason}\n**Total Warnings:** ${totalWarnings}`)
                        .setFooter({ text: `Guild: ${message.guild.name}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        } catch (error) {
            await message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Could not send DM to ${target.user.tag} (DMs may be closed).`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }
    }
};