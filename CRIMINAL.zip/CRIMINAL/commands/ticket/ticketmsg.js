const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    name: 'ticketembed',
    run: async (client, message, args) => {
        const ticketData = await client.db.get(`ticket_${message.guild.id}`) || {
            channelId: null,
            embed: null,
            tickets: new Map()
        };

        const content = args.join(' ');
        if (!content) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Please provide a message for the embed.')
                ]
            });
        }

        const embed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Ticket System')
            .setDescription(content)
            .setFooter('Click the button below to create a ticket.');

        const button = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('create_ticket')
                    .setLabel('Create Ticket')
                    .setStyle('PRIMARY')
            );

        if (ticketData.channelId) {
            const channel = message.guild.channels.cache.get(ticketData.channelId);
            if (channel) {
                await channel.send({ embeds: [embed], components: [button] });
                ticketData.embed = content;
                await client.db.set(`ticket_${message.guild.id}`, ticketData);
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`<:Yes:1385574498488811541> | Ticket embed updated in ${channel}.`)
                    ]
                });
            }
        }
        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription('<:No:1387336444447686697> | Please set a ticket controller channel first using `!ticket set`.')
            ]
        });
    }
};