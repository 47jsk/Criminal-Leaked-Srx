const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'ticketclose',
    aleases: ['closeticket'],
    run: async (client, message, args) => {
        const ticketData = await client.db.get(`ticket_${message.guild.id}`) || {
            channelId: null,
            embed: null,
            tickets: new Map()
        };

        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        if (!channel || !ticketData.tickets.has(channel.id)) {
            console.log('Invalid channel or not a ticket:', channel?.id, Array.from(ticketData.tickets.keys()));
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Please mention a valid ticket channel.')
                ]
            });
        }

        try {
            await channel.delete(`Ticket closed by ${message.author.tag}`);
            ticketData.tickets.delete(channel.id);
            await client.db.set(`ticket_${message.guild.id}`, ticketData);
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:Yes:1385574498488811541> | Ticket ${channel.name} has been closed.`)
                ]
            });
        } catch (error) {
            console.error('Error closing channel:', error);
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Failed to close the ticket. Check bot permissions.')
                ]
            });
        }
    }
};