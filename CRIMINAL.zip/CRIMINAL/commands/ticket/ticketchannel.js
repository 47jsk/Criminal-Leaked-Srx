const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'ticketchannelset',
    run: async (client, message, args) => {
        const ticketData = await client.db.get(`ticket_${message.guild.id}`) || {
            channelId: null,
            embed: null,
            tickets: new Map()
        };

        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        if (!channel) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Please mention a channel or provide a valid channel ID.')
                ]
            });
        }

        ticketData.channelId = channel.id;
        await client.db.set(`ticket_${message.guild.id}`, ticketData);
        return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`<:Yes:1385574498488811541> | Ticket controller channel set to ${channel}.`)
            ]
        });
    }
};