const { MessageEmbed, Permissions } = require('discord.js');

module.exports = {
    name: 'ticket',
    aliases: ['tickets'],
    category: 'moderation',
    run: async (client, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | You must have `Administrator` permissions to use this command.')
                ]
            });
        }

        const subcommand = args[0]?.toLowerCase();
        if (!subcommand) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setTitle('Ticket System Help')
                        .setDescription('Use the following subcommands to manage the ticket system:')
                        .addFields(
                            { name: '!ticket set <channel>', value: 'Set the ticket controller channel.' },
                            { name: '!ticket embed <message>', value: 'Set the ticket controller embed message.' },
                            { name: '!ticket close <ticket-channel>', value: 'Close a ticket channel.' },
                            { name: '!ticket add <user> <ticket-channel>', value: 'Add a user to a ticket.' },
                            { name: '!ticket remove <user> <ticket-channel>', value: 'Remove a user from a ticket.' }
                        )
                        .setFooter('Only administrators can use these commands.')
                ]
            });
        }

        console.log(`Executing subcommand: ${subcommand}, Args: ${args.join(' ')}`);

        const subcommands = {
            set: './ticket/ticketchannel.js',
            embed: './ticket/ticketmsg.js',
            close: './ticket/ticketclose.js',
            add: './ticket/ticketuseradd.js',
            remove: './ticket/ticketuserremove.js'
        };

        const subcommandFile = subcommands[subcommand];
        if (!subcommandFile) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Invalid subcommand. Use `!ticket` for help.')
                ]
            });
        }

        const subcommandModule = require(subcommandFile);
        await subcommandModule.run(client, message, args.slice(1)); // Pass remaining args to subcommand
    }
};