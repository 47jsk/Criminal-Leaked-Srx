const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'ticketuserremove',
    run: async (client, message, args) => {
        const ticketData = await client.db.get(`ticket_${message.guild.id}`) || {
            channelId: null,
            embed: null,
            tickets: new Map()
        };

        const user = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user;
        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
        if (!user || !channel || !ticketData.tickets.has(channel.id)) {
            console.log('Invalid user or channel:', user?.id, channel?.id, Array.from(ticketData.tickets.keys()));
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Please mention a user and a valid ticket channel.')
                ]
            });
        }

        try {
            await channel.permissionOverwrites.delete(user.id);
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:Yes:1385574498488811541> | Removed ${user.tag} from ${channel}.`)
                ]
            });
        } catch (error) {
            console.error('Error removing user:', error);
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('<:No:1387336444447686697> | Failed to remove user. Check bot permissions.')
                ]
            });
        }
    }
};