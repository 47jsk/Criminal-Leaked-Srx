const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'inventory',
    aliases: ['inv', 'items'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        // Determine target user
        let target = message.author;
        if (args[0]) {
            const userId = args[0].replace(/[<@!>]*/g, '');
            try {
                target = await client.users.fetch(userId);
            } catch (error) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697>  Invalid user ID or mention.\n${prefix}inventory [user id/@user]`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        try {
            // Fetch user data
            const balance = await client.db.get(`currency_${target.id}`) || 0;

            // Fetch global purchase history
            const globalPurchases = await client.db.get(`global_purchases_${target.id}`) || [];
            const globalShop = await client.db.get('global_shop') || [];
            const purchasedItems = [];

            // Process global items with details
            if (globalPurchases.length > 0) {
                for (const purchase of globalPurchases) {
                    const item = globalShop.find(i => i.name === purchase.item);
                    if (item) {
                        const purchaseDate = new Date(purchase.timestamp).toLocaleString('en-US', {
                            dateStyle: 'medium',
                            timeStyle: 'short'
                        });
                        purchasedItems.push({
                            name: `**Global ${item.name.charAt(0).toUpperCase() + item.name.slice(1)}**`,
                            details: `Price: ${item.price} Cr\nDescription: ${item.description}\nPurchased: ${purchaseDate}`,
                            type: 'global'
                        });
                    }
                }
            }

            // Fetch server-specific purchased items
            const guildShop = await client.db.get(`shop_${message.guild.id}`) || [];
            const member = message.guild.members.cache.get(target.id);
            if (member) {
                for (const item of guildShop) {
                    if (item.description.includes('role')) {
                        const roleName = item.name.replace(/_/g, ' ');
                        const role = message.guild.roles.cache.find(r => r.name === roleName);
                        if (role && member.roles.cache.has(role.id)) {
                            purchasedItems.push({
                                name: `**Server Role: ${roleName}**`,
                                details: `Price: ${item.price} ₹\nDescription: ${item.description}`,
                                type: 'server'
                            });
                        }
                    } else if (item.description.includes('badge')) {
                        const serverBadge = await client.db.get(`badge_${target.id}_${message.guild.id}`);
                        if (serverBadge === item.name) {
                            purchasedItems.push({
                                name: `**Server Badge: ${serverBadge}**`,
                                details: `Price: ${item.price} ₹\nDescription: ${item.description}`,
                                type: 'server'
                            });
                        }
                    }
                }
            }

            // Prepare embed content
            const itemsList = purchasedItems.length
                ? purchasedItems.map(item => `${item.name}\n${item.details}`).join('\n\n')
                : 'No purchased items yet!';
            const embedContent = new MessageEmbed()
                .setColor(client.color)
                .setTitle(`${target.tag}'s Inventory`)
                .setDescription(
                    `**Balance**: ${balance} ₹\n` +
                    `**Total Items**: ${purchasedItems.length}\n\n` +
                    `**Purchased Items**:\n${itemsList}`
                )
                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            await message.channel.send({ embeds: [embedContent] });
        } catch (error) {
            console.error('Error in inventory command:', error);
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697>  An error occurred while fetching your inventory.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }
    }
};