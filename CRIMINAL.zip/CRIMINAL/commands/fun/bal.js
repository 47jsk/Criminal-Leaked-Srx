const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'balance',
    aliases: ['bal', 'coins'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        let target;
        if (!args[0]) {
            target = message.author;
        } else {
            let userId = args[0].replace(/[<@!>]*/g, '');
            try {
                target = await client.users.fetch(userId);
            } catch {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697> Invalid user ID or mention.\n${prefix}balance [user id/@user]`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        let balance = await client.db.get(`currency_${target.id}`) || 0;

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Balance')
            .setDescription(`**${target.tag}** has **${balance} ₹**! 💰`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};