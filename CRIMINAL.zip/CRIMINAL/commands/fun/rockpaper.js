const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'rockpaperscissors',
    aliases: ['rps'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}rockpaperscissors @player\nChallenge a player to a game of Rock, Paper, Scissors!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const targetId = args[0].replace(/[<@!>]*/g, '');
        const target = message.guild.members.cache.get(targetId);
        if (!target || target.user.bot || target.id === message.author.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Please mention a valid player (not a bot or yourself)!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Notify start of the game
        const startEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Rock, Paper, Scissors Challenge')
            .setDescription(`${message.author} has challenged ${target} to a game of Rock, Paper, Scissors!\nBoth players, type your choice (rock, paper, or scissors) within 15 seconds.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [startEmbed] });

        // Function to get player choice
        const choices = ['rock', 'paper', 'scissors'];
        const getChoice = async (user) => {
            const choiceEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle(`Rock, Paper, Scissors - ${user.tag}'s Turn`)
                .setDescription(`${user}, choose rock, paper, or scissors by typing your choice within 15 seconds!`)
                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            await message.channel.send({ embeds: [choiceEmbed] });
            const filter = m => m.author.id === user.id && choices.includes(m.content.toLowerCase());
            const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
                .catch(() => null);
            return collected ? collected.first().content.toLowerCase() : null;
        };

        const player1Choice = await getChoice(message.author);
        if (!player1Choice) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> ${message.author} didn’t choose in time. Game cancelled.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const player2Choice = await getChoice(target);
        if (!player2Choice) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> ${target} didn’t choose in time. Game cancelled.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Determine winner
        let result;
        if (player1Choice === player2Choice) {
            result = `It’s a tie! Both chose ${player1Choice}.`;
        } else if (
            (player1Choice === 'rock' && player2Choice === 'scissors') ||
            (player1Choice === 'paper' && player2Choice === 'rock') ||
            (player1Choice === 'scissors' && player2Choice === 'paper')
        ) {
            result = `${message.author} wins! ${player1Choice} beats ${player2Choice}.`;
        } else {
            result = `${target} wins! ${player2Choice} beats ${player1Choice}.`;
        }

        const resultEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Rock, Paper, Scissors Result')
            .setDescription(
                `${message.author.tag} chose ${player1Choice}\n` +
                `${target.tag} chose ${player2Choice}\n\n` +
                result
            )
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [resultEmbed] });
    }
};