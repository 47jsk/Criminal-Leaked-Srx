const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'guessnumber',
    aliases: ['guess'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        const targetNumber = Math.floor(Math.random() * 100) + 1; // Random number between 1 and 100
        let attempts = 0;
        let guessed = false;

        const startEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('🔢 Guess the Number')
            .setDescription(`${message.author}, I’ve picked a number between 1 and 100. Guess it by typing a number! You have 5 attempts.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [startEmbed] });

        const filter = m => !isNaN(m.content) && m.author.id === message.author.id;
        const collector = message.channel.createMessageCollector({ filter, max: 5, time: 60000 });

        collector.on('collect', m => {
            attempts++;
            const guess = parseInt(m.content);
            if (guess === targetNumber) {
                guessed = true;
                collector.stop();
            } else if (guess < targetNumber) {
                m.channel.send({
                    embeds: [
                        embed
                            .setDescription(`Too low! Try a higher number. Attempts left: ${5 - attempts}`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            } else {
                m.channel.send({
                    embeds: [
                        embed
                            .setDescription(`Too high! Try a lower number. Attempts left: ${5 - attempts}`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        });

        collector.on('end', (collected, reason) => {
            if (guessed) {
                const winEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setTitle('🔢 Guess the Number - Victory!')
                    .setDescription(`Congratulations ${message.author}! You guessed the number ${targetNumber} in ${attempts} attempts!`)
                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp();
                message.channel.send({ embeds: [winEmbed] });
            } else if (reason === 'time') {
                message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697> Time’s up! The number was ${targetNumber}. Better luck next time!`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            } else if (attempts >= 5) {
                message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697> Out of attempts! The number was ${targetNumber}.`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        });
    }
};