const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'dreamweaver',
    aliases: ['dream'],
    category: 'fun',
    run: async (client, message) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        const settings = ['forest', 'space', 'ocean', 'castle'];
        const characters = ['a talking fox', 'a floating astronaut', 'a singing mermaid', 'a ghostly knight'];
        const actions = ['flying on a magic carpet', 'battling a giant cupcake', 'dancing with stars', 'searching for a lost crown'];

        const setting = settings[Math.floor(Math.random() * settings.length)];
        const character = characters[Math.floor(Math.random() * characters.length)];
        const action = actions[Math.floor(Math.random() * actions.length)];

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('🌙 Dream Weaver')
            .setDescription(`**Your Dream:** You find yourself in a ${setting}, where ${character} joins you ${action}.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};