const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'buy',
    aliases: ['purchase'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}buy <item>\nView items with ${prefix}shop`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const shopItems = {
            'booster_role': { price: 500, action: async (member) => {
                const role = message.guild.roles.cache.find(r => r.name === 'Booster');
                if (!role) {
                    await message.guild.roles.create({ name: 'Booster', color: '#ff0000' });
                    return message.channel.send({ embeds: [embed.setDescription('Role created, try again!')] });
                }
                if (message.guild.me.roles.highest.position <= role.position) {
                    return { success: false, message: 'Bot lacks permission to assign this role!' };
                }
                await member.roles.add(role);
                return { success: true, message: `You now have the Booster role!` };
            }},
            'custom_message': { price: 200, action: async (member) => {
                await message.channel.send({ content: `${member} has bought a custom message! Type your message below (within 30s).` });
                const filter = m => m.author.id === member.id;
                const collector = message.channel.createMessageCollector({ filter, time: 30000 });
                collector.on('collect', m => {
                    message.channel.send(`📢 **Announcement from ${member.tag}:** ${m.content}`);
                    collector.stop();
                });
                collector.on('end', (collected, reason) => {
                    if (reason === 'time') message.channel.send('Time’s up! No message sent.');
                });
                return { success: true, message: 'Custom message purchased!' };
            }},
            'double_daily': { price: 300, action: async (member) => {
                const doubleKey = `double_daily_${member.id}`;
                await client.db.set(doubleKey, Date.now() + 24 * 60 * 60 * 1000);
                return { success: true, message: 'Your next daily reward will be doubled for 24 hours!' };
            }},
            'vip_role': { price: 500, action: async (member) => {
                const guildConfig = await client.db.get(`config_${message.guild.id}`) || {};
                const vipRoleId = guildConfig.vipRoleId;
                if (!vipRoleId) {
                    return { success: false, message: 'VIP Role not set up by an administrator!' };
                }
                const role = message.guild.roles.cache.get(vipRoleId);
                if (!role) {
                    return { success: false, message: 'VIP Role not found!' };
                }
                if (message.guild.me.roles.highest.position <= role.position) {
                    return { success: false, message: 'Bot lacks permission to assign this role!' };
                }
                await member.roles.add(role);
                return { success: true, message: `You now have the ${role.name} role!` };
            }}
        };

        // Add server-specific items including custom roles
        const guildShop = await client.db.get(`shop_${message.guild.id}`) || [];
        guildShop.forEach(item => {
            shopItems[item.name] = {
                price: item.price,
                action: async (member) => {
                    if (item.roleId) {
                        const role = message.guild.roles.cache.get(item.roleId);
                        if (!role) {
                            return { success: false, message: 'Role not found!' };
                        }
                        if (message.guild.me.roles.highest.position <= role.position) {
                            return { success: false, message: 'Bot lacks permission to assign this role!' };
                        }
                        await member.roles.add(role);
                        return { success: true, message: `You now have the ${role.name} role!` };
                    } else if (item.description.includes('badge')) {
                        await client.db.set(`badge_${member.id}_${message.guild.id}`, item.name);
                        return { success: true, message: `You earned the ${item.name} badge! (Display it with !profile)` };
                    } else {
                        return { success: true, message: `Purchased ${item.name}! (Custom effect not implemented)` };
                    }
                }
            };
        });

        const itemInput = args[0].toLowerCase();
        let matchedItem = null;
        for (let [name, details] of Object.entries(shopItems)) {
            const baseName = name.replace(/<[^>]+>/g, '').trim().toLowerCase(); // Remove emojis and match base name
            if (baseName === itemInput) {
                matchedItem = name;
                break;
            }
        }

        if (!matchedItem) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Item not found. Check ${prefix}shop for available items.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let balance = await client.db.get(`currency_${message.author.id}`) || 0;
        if (balance < shopItems[matchedItem].price) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You need ${shopItems[matchedItem].price} ₹ to buy ${matchedItem}!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const result = await shopItems[matchedItem].action(message.member);
        if (!result.success) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> ${result.message}`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        balance -= shopItems[matchedItem].price;
        await client.db.set(`currency_${message.author.id}`, balance);

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Purchase Successful')
            .setDescription(`<:Yes:1385574498488811541> ${result.message}\nNew balance: **${balance} ₹**.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};