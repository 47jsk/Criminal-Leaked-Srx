const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'gay',
    aliases: ['gaypercent', 'gayrate'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Determine the target user (self or mentioned/ID)
        let target;
        if (!args[0]) {
            target = message.author;
        } else {
            let userId = args[0].replace(/[<@!>]*/g, ''); // Extract user ID from mention or raw ID
            try {
                target = await client.users.fetch(userId);
            } catch {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Invalid user ID or mention.\n${prefix}gay [user id/@user]`
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        // Generate random percentage
        const percentage = Math.floor(Math.random() * 101); // 0-100%

        // Fun message based on percentage
        let description = `<a:Yes:1385574498488811541> **${target.tag}** is **${percentage}%** gay! 🌈`;
        if (percentage < 20) description += `\nNot much rainbow in this one! 😛`;
        else if (percentage < 50) description += `\nA little sparkle, but still exploring! ✨`;
        else if (percentage < 80) description += `\nRocking the rainbow vibes! 🏳️‍🌈`;
        else description += `\nAbsolute legend of fabulousness! 😍`;

        return message.channel.send({
            embeds: [
                embed
                    .setDescription(description)
                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};