const { Message, Client, MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'shop',
    aliases: ['store'],
    category: 'fun',
    run: async (client, message) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        const guildShop = await client.db.get(`shop_${message.guild.id}`) || [];
        const guildConfig = await client.db.get(`config_${message.guild.id}`) || {};
        const vipRoleId = guildConfig.vipRoleId;

        const defaultItems = {
            'booster_role': { price: 500, description: 'Get a shiny Booster role!', emoji: '<a:18:1391780526536265848>' },
            'custom_message': { price: 200, description: 'Send a custom server announcement!', emoji: '<:Criminal_OP:1391700572284915834>' },
            'double_daily': { price: 300, description: 'Double your next daily reward for 24 hours!', emoji: '<:02_pancake:1391795372816466041>' }
        };

        let shopItems = { ...defaultItems };
        if (vipRoleId) {
            const vipRole = message.guild.roles.cache.get(vipRoleId);
            shopItems['vip_role'] = { price: 500, description: `Become a VIP with the ${vipRole ? vipRole.name : 'VIP'} role!`, emoji: '<:Criminal_OP:1391705145649139732>' };
        }
        guildShop.forEach(item => {
            shopItems[item.name] = { price: item.price, description: item.description, roleId: item.roleId || null, emoji: item.emoji || '' };
        });

        const itemsList = Object.entries(shopItems).map(([name, { price, description, emoji }]) =>
            `${emoji} **${name}** - ${price} Cr\n${description}`
        ).join('\n');

        const embedContent = new MessageEmbed()
            .setColor('client.color')
            .setTitle('Criminal Shop')
            .setDescription(`Buy items with your Cr! Use ${prefix}buy <item> to purchase.\n\n${itemsList}`);

        if (message.member.permissions.has('ADMINISTRATOR')) {
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('add_item')
                        .setLabel('Add Custom Item')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId('setup_vip')
                        .setLabel('Setup VIP Role')
                        .setStyle('PRIMARY')
                );
            await message.channel.send({ embeds: [embedContent], components: [row] });
        } else {
            await message.channel.send({ embeds: [embedContent] });
        }

        if (!message.member.permissions.has('ADMINISTRATOR')) return;

        const filter = i => (i.customId === 'add_item' || i.customId === 'setup_vip') && i.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'add_item') {
                await interaction.update({
                    content: 'Enter the item name, price (in ₹), description, and role mention (e.g., "Custom_Role 1000 Exclusive role @Role"), or type "cancel" to abort.',
                    embeds: [],
                    components: []
                });

                const msgFilter = m => m.author.id === message.author.id;
                const msgCollector = message.channel.createMessageCollector({ filter: msgFilter, max: 1, time: 30000 });

                msgCollector.on('collect', async m => {
                    if (m.content.toLowerCase() === 'cancel') {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Item addition cancelled.`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    const [name, priceStr, ...rest] = m.content.split(' ');
                    const price = parseInt(priceStr);
                    const lastPart = rest.pop();
                    const description = rest.join(' ');
                    const roleMention = lastPart.match(/<@&(\d+)>/);

                    if (!name || isNaN(price) || price <= 0 || !description || !roleMention) {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Invalid format! Use: name price description @role\nExample: Custom_Role 1000 Exclusive role @VIP`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    const roleId = roleMention[1];
                    const role = message.guild.roles.cache.get(roleId);
                    if (!role) {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Role not found!`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    const existingShop = await client.db.get(`shop_${message.guild.id}`) || [];
                    if (existingShop.some(item => item.name === name)) {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> An item named "${name}" already exists!`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    existingShop.push({ name, price, description, roleId, id: `custom_${Date.now()}_${message.guild.id}` });
                    await client.db.set(`shop_${message.guild.id}`, existingShop);

                    await m.channel.send({
                        embeds: [
                            embed
                                .setDescription(`<:Yes:1385574498488811541> Added **${name}** to the shop!\nPrice: ${price} ₹\nDescription: ${description}\nRole: ${role.name}`)
                                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                .setTimestamp()
                        ]
                    });
                });

                msgCollector.on('end', (collected, reason) => {
                    if (reason === 'time') {
                        message.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Time’s up! Item addition cancelled.`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                    }
                });
            } else if (interaction.customId === 'setup_vip') {
                await interaction.update({
                    content: 'Mention the role to set as the VIP Role (e.g., @VIP), or type "cancel" to abort.',
                    embeds: [],
                    components: []
                });

                const msgFilter = m => m.author.id === message.author.id;
                const msgCollector = message.channel.createMessageCollector({ filter: msgFilter, max: 1, time: 30000 });

                msgCollector.on('collect', async m => {
                    if (m.content.toLowerCase() === 'cancel') {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> VIP Role setup cancelled.`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    const roleMention = m.content.match(/<@&(\d+)>/);
                    if (!roleMention) {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Please mention a valid role!`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    const roleId = roleMention[1];
                    const role = message.guild.roles.cache.get(roleId);
                    if (!role) {
                        await m.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Role not found!`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                        return;
                    }

                    let guildConfig = await client.db.get(`config_${message.guild.id}`) || {};
                    guildConfig.vipRoleId = roleId;
                    await client.db.set(`config_${message.guild.id}`, guildConfig);

                    await m.channel.send({
                        embeds: [
                            embed
                                .setDescription(`<:Yes:1385574498488811541> Set **${role.name}** as the VIP Role for 500 ₹!`)
                                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                .setTimestamp()
                        ]
                    });
                });

                msgCollector.on('end', (collected, reason) => {
                    if (reason === 'time') {
                        message.channel.send({
                            embeds: [
                                embed
                                    .setDescription(`<:No:1387336444447686697> Time’s up! VIP Role setup cancelled.`)
                                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                    }
                });
            }
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697> Item addition timed out!`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        });
    }
};