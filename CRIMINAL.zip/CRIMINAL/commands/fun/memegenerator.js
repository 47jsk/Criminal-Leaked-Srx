const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'memegenerator',
    aliases: ['meme'],
    category: 'fun',
    run: async (client, message) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        const topTexts = ['When you', 'Me trying to', 'POV:', 'When life'];
        const bottomTexts = ['realize it’s Monday', 'adult', 'you see the bill', 'gives you lemons'];
        const images = ['a confused cat', 'a dancing dog', 'a surprised baby', 'an angry potato'];

        const topText = topTexts[Math.floor(Math.random() * topTexts.length)];
        const bottomText = bottomTexts[Math.floor(Math.random() * bottomTexts.length)];
        const image = images[Math.floor(Math.random() * images.length)];

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('😂 Meme Generator')
            .setDescription(`**Meme Idea:**\nTop Text: ${topText}\nBottom Text: ${bottomText}\nImage: ${image}`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};