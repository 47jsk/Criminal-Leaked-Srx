const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'daily',
    aliases: ['daily'],
    category: 'fun',
    run: async (client, message) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        const reward = 50; // Fixed 50 Cr daily
        let lastClaim = await client.db.get(`daily_${message.author.id}`) || 0;
        const now = Date.now();
        const cooldown = 24 * 60 * 60 * 1000; // 24 hours

        if (lastClaim && now - lastClaim < cooldown) {
            const timeLeft = Math.ceil((cooldown - (now - lastClaim)) / (60 * 60 * 1000));
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You’ve already claimed your daily! Wait ${timeLeft} hour(s).`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let balance = await client.db.get(`currency_${message.author.id}`) || 0;
        balance += reward;
        await client.db.set(`currency_${message.author.id}`, balance);
        await client.db.set(`daily_${message.author.id}`, now);

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Daily Reward')
            .setDescription(`<:Yes:1385574498488811541> You claimed **${reward} ₹**! New balance: **${balance} ₹**! 💰`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};