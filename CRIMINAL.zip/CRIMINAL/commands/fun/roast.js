const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

const cooldowns = new Set(); // Store user IDs on cooldown
const COOLDOWN_TIME = 10 * 1000; // 10 seconds in milliseconds

// English roast lines
const englishRoastLines = [
    "Your face is so oily, it could solve the world's energy crisis! 😅",
    "If laziness was a sport, you'd be the world champion! 🛋️",
    "Your Wi-Fi must be jealous of how disconnected you are! 📡",
    "You move so slowly, snails send you motivational quotes! 🐌",
    "Your brain must be on vacation... permanently! 🏖️",
    "If I wanted a blank stare, I'd talk to a wall! 😐",
    "Your fashion sense is so last century, even time travelers laugh! ⏰",
    "You must be the reason dictionaries added 'clueless' to their pages! 📖",
    "Your jokes are so bad, they make dad jokes look like comedy gold! 😬",
    "If there was a contest for chaos, you'd take first, second, and third! 🌪️"
];

// Hindi roast lines
const hindiRoastLines = [
    "Teri shakal itni oily hai, petrol pump khol sakta hai! 😅",
    "Aalsi pan ka Olympic hota to tu gold medal jeet leta! 🛋️",
    "Tera dimaag toh Wi-Fi se bhi zyada disconnect hai! 📡",
    "Tu itna dheema chalta hai, kachhua bhi tujhe cheer karta hai! 🐢",
    "Tera brain toh permanent chhutti par chala gaya hai! 🏖️",
    "Tujhse baat karna diwar se sar takrana jaisa hai! 😐",
    "Tera fashion sense itna purana hai, dadi ke zamane ka hai! 👘",
    "Tune hi 'bewakoof' shabd ko dictionary mein famous kiya hoga! 📚",
    "Tere jokes itne bekaar hain, uncle bhi sharma jaayein! 😬",
    "Tu toh itna hungama karta hai, circus bhi fail ho jaye! 🎪"
];

module.exports = {
    name: 'roast',
    aliases: ['burn', 'insult'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor('#ff0000'); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Check if user is on cooldown
        if (cooldowns.has(message.author.id)) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> You're on cooldown! Please wait a few seconds and try again.`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Determine language (default to English)
        let language = 'english';
        let targetArgIndex = 0;
        if (args[0] && ['english', 'hindi'].includes(args[0].toLowerCase())) {
            language = args[0].toLowerCase();
            targetArgIndex = 1;
        }

        // Determine the target user (self or mentioned/ID)
        let target;
        if (!args[targetArgIndex]) {
            target = message.author;
        } else {
            let userId = args[targetArgIndex].replace(/[<@!>]*/g, ''); // Extract user ID from mention or raw ID
            try {
                target = await client.users.fetch(userId);
            } catch {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Invalid user ID or mention.\n${prefix}roast [english/hindi] [user id/@user]`
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        // Prevent roasting the bot itself
        if (target.id === client.user.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> Nice try, but I don't roast myself! Pick someone else. 😎`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Add user to cooldown
        cooldowns.add(message.author.id);
        setTimeout(() => cooldowns.delete(message.author.id), COOLDOWN_TIME);

        // Select a random roast based on language
        const roastLines = language === 'hindi' ? hindiRoastLines : englishRoastLines;
        const roast = roastLines[Math.floor(Math.random() * roastLines.length)];

        // Send the roast
        return message.channel.send({
            embeds: [
                embed
                    .setDescription(
                        `<a:Yes:1385574498488811541> **${target.tag}**, ${roast}`
                    )
                    .setFooter({ text: `Roasted by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};