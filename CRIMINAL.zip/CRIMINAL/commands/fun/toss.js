const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'coinflip',
    aliases: ['flip', 'coin'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '&';

        // Generate random result: Heads or Tails
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';

        // If no guess is provided, just show the result
        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<a:Yes:1385574498488811541> The coin landed on **${result}**!`)
                        .setFooter({ text: `Flipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // If a guess is provided, check if it's valid and compare
        const guess = args[0].toLowerCase();
        if (!['heads', 'tails'].includes(guess)) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> Invalid guess. Use \`${prefix}coinflip [heads/tails]\`.`
                        )
                        .setFooter({ text: `Flipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Compare guess with result
        const isWin = guess.toLowerCase() === result.toLowerCase();
        return message.channel.send({
            embeds: [
                embed
                    .setDescription(
                        `<a:Yes:1385574498488811541> The coin landed on **${result}**!\n` +
                        (isWin
                            ? `You guessed **${guess}** and **won**! 🎉`
                            : `You guessed **${guess}** and **lost**. 😔`)
                    )
                    .setFooter({ text: `Flipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};