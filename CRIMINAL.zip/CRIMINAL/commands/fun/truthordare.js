const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'truthordare',
    aliases: ['tod'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        let target = message.author;
        if (args[0] && args[0].startsWith('<@')) {
            const targetId = args[0].replace(/[<@!>]*/g, '');
            target = message.guild.members.cache.get(targetId);
            if (!target || target.user.bot) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:No:1387336444447686697> Please mention a valid player (not a bot)!`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
            args.shift(); // Remove target from args
        }

        if (!args[0] || !['truth', 'dare'].includes(args[0].toLowerCase())) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}truthordare [@user] <truth/dare>\nChoose truth or dare for a fun challenge!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const truths = [
            'What’s the most embarrassing thing you’ve ever done?',
            'Have you ever lied to get out of trouble? What was it?',
            'Who do you have a crush on right now?',
            'What’s your biggest fear?',
            'What’s the weirdest food you’ve ever eaten?',
            'Have you ever cheated on a test? If yes, how?',
            'What’s a secret you’ve never told anyone?',
            'What’s the silliest thing you’ve done to impress someone?',
            'Have you ever had a paranormal experience?',
            'What’s the most childish thing you still do?',
            'What’s the worst gift you’ve ever received?',
            'Have you ever pretended to like something you hated?',
            'What’s the most awkward date you’ve been on?',
            'Have you ever stolen anything? What was it?',
            'What’s a dream you’ve had that you can’t forget?',
            'Who do you trust the least in this server?',
            'What’s the strangest habit you have?',
            'Have you ever cried watching a movie? Which one?',
            'What’s the dumbest thing you believed as a kid?',
            'Have you ever had a crush on a teacher?'
        ];

        const dares = [
            'Sing the chorus of your favorite song loudly!',
            'Send a funny selfie to the chat right now.',
            'Do 10 push-ups and show us!',
            'Say something nice about the person above you.',
            'Speak in a funny accent for the next 3 messages!',
            'Dance like nobody’s watching for 15 seconds!',
            'Call out a random user and compliment them.',
            'Make up a short poem about the server.',
            'Imitate your favorite celebrity for a minute.',
            'Wear an imaginary hat and describe it to us!',
            'Do a cartwheel (or try your best) and record it!',
            'Say the alphabet backwards as fast as you can!',
            'Pretend you’re a superhero for the next message.',
            'Make a silly face and take a photo for us!',
            'Talk like a pirate for the next 2 minutes!',
            'Challenge someone to a thumb war (show proof)!',
            'Recite a tongue twister 3 times without messing up.',
            'Act like a chicken for 10 seconds!',
            'Create a nickname for everyone in the chat.',
            'Do your best impression of a baby crying!'
        ];

        const choice = args[0].toLowerCase();
        const response = choice === 'truth' 
            ? truths[Math.floor(Math.random() * truths.length)]
            : dares[Math.floor(Math.random() * dares.length)];

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle(`${choice.charAt(0).toUpperCase() + choice.slice(1)} Time!`)
            .setDescription(`${target}, your ${choice} is: **${response}**`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};