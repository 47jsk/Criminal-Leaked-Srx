const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'globalshop',
    aliases: ['gshop'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Define developer IDs (adjust with actual IDs)
        const developers = ['1354343474186686607', 'USER_ID_2', 'USER_ID_3', 'USER_ID_4', 'USER_ID_5']; // e.g., Tejas Shettigar, Rihan, etc.

        const globalShop = await client.db.get('global_shop') || [];

        if (args[0] && developers.includes(message.author.id)) {
            if (args[0] === 'add') {
                if (!args[1] || !args[2] || !args[3]) {
                    return message.channel.send({
                        embeds: [
                            embed
                                .setDescription(`<:No:1387336444447686697>  Usage: ${prefix}globalshop add <name> <price> <description>`)
                                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                .setTimestamp()
                        ]
                    });
                }

                const name = args[1].toLowerCase();
                const price = parseInt(args[2]);
                const description = args.slice(3).join(' ');

                if (isNaN(price) || price <= 0 || !description) {
                    return message.channel.send({
                        embeds: [
                            embed
                                .setDescription(`<:No:1387336444447686697>  Invalid price or description!`)
                                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                .setTimestamp()
                        ]
                    });
                }

                if (globalShop.some(item => item.name === name)) {
                    return message.channel.send({
                        embeds: [
                            embed
                                .setDescription(`<:No:1387336444447686697>  An item named "${name}" already exists!`)
                                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                                .setTimestamp()
                        ]
                    });
                }

                globalShop.push({ name, price, description, id: `global_${Date.now()}` });
                await client.db.set('global_shop', globalShop);

                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`<:Yes:1385574498488811541> Added **${name}** to the global shop!\nPrice: ${price} ₹\nDescription: ${description}`)
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        // Display global shop for all users
        const itemsList = globalShop.map(item =>
            `**${item.name}** - ${item.price} Cr\n${item.description}`
        ).join('\n') || 'No items available yet!';

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Criminal Shop')
            .setDescription(`Purchase global items with your Cr! Use ${prefix}buyglobal <item> to buy.\n\n${itemsList}`);

        await message.channel.send({ embeds: [embedContent] });
    }
};