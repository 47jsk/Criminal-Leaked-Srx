const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'buyglobal',
    aliases: ['gbuy'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697>  Usage: ${prefix}buyglobal <item>\nView items with ${prefix}globalshop`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const globalShop = await client.db.get('global_shop') || [];
        const item = args[0].toLowerCase();
        const shopItem = globalShop.find(i => i.name === item);

        if (!shopItem) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697>  Item "${item}" not found in the global shop.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let balance = await client.db.get(`currency_${message.author.id}`) || 0;
        if (balance < shopItem.price) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697>  You need ${shopItem.price} ₹ to buy ${item}!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Log the purchase in global purchase history
        let purchaseHistory = await client.db.get(`global_purchases_${message.author.id}`) || [];
        if (!purchaseHistory.some(p => p.item === item)) {
            purchaseHistory.push({ item, timestamp: Date.now() });
            await client.db.set(`global_purchases_${message.author.id}`, purchaseHistory);
        }

        // Handle item effects
        let result;
        switch (item) {
            case 'badge':
                await client.db.set(`global_badge_${message.author.id}`, item);
                result = { success: true, message: `You earned the ${item} badge! (Display it with !profile)` };
                break;
            case 'no_prefix_premium':
                await client.db.set(`no_prefix_${message.author.id}`, true);
                result = { success: true, message: 'You now have No-Prefix Premium! Commands work without prefixes for you.' };
                break;
            default:
                result = { success: true, message: `Purchased ${item}! (Custom effect not implemented)` };
        }

        if (!result.success) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697>  ${result.message}`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        balance -= shopItem.price;
        await client.db.set(`currency_${message.author.id}`, balance);

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Global Purchase Successful')
            .setDescription(`<:Yes:1385574498488811541> ${result.message}\nNew balance: **${balance} ₹**.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};