const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'vampirehunt',
    aliases: ['vampire', 'hunt'],
    category: 'fun',
    run: async (client, message) => {
        const embed = new MessageEmbed().setColor(client.color); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '!';

        const outcomes = [
            { text: 'You staked the vampire! Victory! <a:Yes:1385574498488811541>', success: true },
            { text: 'The vampire turned you! You’re one of them now. <:No:1387336444447686697> ', success: false },
            { text: 'You found garlic, but the vampire escaped! <:No:1387336444447686697> ', success: false },
            { text: 'Epic hunt! You slayed the vampire lord! <:Yes:1385574498488811541>', success: true }
        ];

        const outcome = outcomes[Math.floor(Math.random() * outcomes.length)];
        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Vampire Hunt')
            .setDescription(`**${message.author.username}** ventures into the night...\n${outcome.text}`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};