const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'transfer',
    aliases: ['send', 'give'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        if (!args[0] || !args[1]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}transfer <user id/@user> <amount>`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let targetId = args[0].replace(/[<@!>]*/g, '');
        let amount = parseInt(args[1]);
        if (isNaN(amount) || amount <= 0) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Invalid amount. Use a positive number.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let target;
        try {
            target = await client.users.fetch(targetId);
        } catch {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Invalid user ID or mention.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (target.id === message.author.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You can’t transfer to yourself!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let senderBalance = await client.db.get(`currency_${message.author.id}`) || 0;
        if (senderBalance < amount) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You don’t have ${amount} ₹!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        senderBalance -= amount;
        let targetBalance = await client.db.get(`currency_${target.id}`) || 0;
        targetBalance += amount;
        await client.db.set(`currency_${message.author.id}`, senderBalance);
        await client.db.set(`currency_${target.id}`, targetBalance);

        const embedContent = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Criminal Transfer')
            .setDescription(`<:Yes:1385574498488811541> **${message.author.tag}** sent **${amount} ₹** to **${target.tag}**!\nNew balance: **${senderBalance} ₹**.`)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embedContent] });
    }
};