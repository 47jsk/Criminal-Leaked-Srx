const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

const cooldowns = new Set(); // Store user IDs on cooldown
const COOLDOWN_TIME = 10 * 1000; // 10 seconds in milliseconds

module.exports = {
    name: 'ppsize',
    aliases: ['dicksize', 'pp'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Check if user is on cooldown
        if (cooldowns.has(message.author.id)) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> You're on cooldown! Please wait a few seconds and try again.`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Determine the target user (self or mentioned/ID)
        let target;
        if (!args[0]) {
            target = message.author;
        } else {
            let userId = args[0].replace(/[<@!>]*/g, ''); // Extract user ID from mention or raw ID
            try {
                target = await client.users.fetch(userId);
            } catch {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(
                                `<a:No:1385572287763320994> Invalid user ID or mention.\n${prefix}ppsize [user id/@user]`
                            )
                            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            }
        }

        // Prevent targeting the bot itself
        if (target.id === client.user.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `<a:No:1385572287763320994> Nice try, but I don't measure myself! Pick someone else. 😎`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Add user to cooldown
        cooldowns.add(message.author.id);
        setTimeout(() => cooldowns.delete(message.author.id), COOLDOWN_TIME);

        // Generate random size (in inches, for fun)
        const size = (Math.random() * 10).toFixed(1); // Random size between 0.0 and 10.0 inches
        let description = `<a:Yes:1385574498488811541> **${target.tag}**'s PP size is **${size} inches**! 🍆`;
        
        // Add playful commentary based on size
        if (size < 3) description += `\nOof, tiny but mighty! 😜`;
        else if (size < 5) description += `\nPretty average, nothing to brag about! 😏`;
        else if (size < 8) description += `\nNot bad, you're packing some heat! 🔥`;
        else description += `\nWhoa, a true legend in the game! 😲`;

        // Send the result
        return message.channel.send({
            embeds: [
                embed
                    .setDescription(description)
                    .setFooter({ text: `Measured by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};