const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'lovepercent',
    aliases: ['lovecalc', 'love'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        const user1 = message.author;
        let user2;

        if (!args[0] || !args[0].startsWith('<@')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}lovepercent @user\nCalculate your love compatibility with someone!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        const targetId = args[0].replace(/[<@!>]*/g, '');
        user2 = message.guild.members.cache.get(targetId);
        if (!user2 || user2.user.bot || user2.id === user1.id) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Please mention a valid player (not a bot or yourself)!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Generate random love percentage (0-100)
        const lovePercent = Math.floor(Math.random() * 101);
        let compatibilityMessage;

        if (lovePercent >= 90) {
            compatibilityMessage = 'A match made in heaven! 💕 Sparks are flying everywhere!';
        } else if (lovePercent >= 70) {
            compatibilityMessage = 'Strong chemistry! You two could be a great pair! 😍';
        } else if (lovePercent >= 50) {
            compatibilityMessage = 'Moderate compatibility! With effort, it could work! 🙂';
        } else if (lovePercent >= 30) {
            compatibilityMessage = 'A bit of a challenge ahead! Friendship might be better. 😕';
        } else {
            compatibilityMessage = 'Oh no! Better luck with someone else! 😅';
        }

        const loveEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('❤️ Love Calculator')
            .setDescription(
                `**${user1.tag}** and **${user2.user.tag}**'s love compatibility is **${lovePercent}%**!\n` +
                `${compatibilityMessage}`
            )
            .setThumbnail(user1.displayAvatarURL({ dynamic: true }))
            .setImage(user2.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [loveEmbed] });
    }
};