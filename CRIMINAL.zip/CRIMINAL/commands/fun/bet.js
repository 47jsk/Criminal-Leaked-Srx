const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'gamble',
    aliases: ['bet'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix || this.config.prefix || '!';

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Usage: ${prefix}gamble <amount>\nEnter the amount of ₹ to gamble!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let amount = parseInt(args[0]);
        if (isNaN(amount) || amount <= 0) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> Invalid amount. Use a positive number.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        let balance = await client.db.get(`currency_${message.author.id}`) || 0;
        if (balance < amount) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You don’t have ${amount} ₹ to gamble!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // 50/50 chance to win or lose
        const win = Math.random() < 0.5;
        if (win) {
            const winnings = amount * 2;
            balance += winnings - amount; // Net gain after wager
            await client.db.set(`currency_${message.author.id}`, balance);

            const embedContent = new MessageEmbed()
                .setColor(client.color)
                .setTitle('Gamble Result')
                .setDescription(`<:Yes:1385574498488811541> You won! **${winnings} ₹** added to your balance!\nNew balance: **${balance} Cr**.`)
                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            await message.channel.send({ embeds: [embedContent] });
        } else {
            balance -= amount;
            await client.db.set(`currency_${message.author.id}`, balance);

            const embedContent = new MessageEmbed()
                .setColor(client.color)
                .setTitle('Gamble Result')
                .setDescription(`<:No:1387336444447686697> You lost! **${amount} ₹** deducted from your balance!\nNew balance: **${balance} ₹**.`)
                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            await message.channel.send({ embeds: [embedContent] });
        }
    }
};