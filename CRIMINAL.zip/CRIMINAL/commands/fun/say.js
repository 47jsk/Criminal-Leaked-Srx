const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

const cooldowns = new Set(); // Store user IDs on cooldown
const COOLDOWN_TIME = 20 * 1000; // 20 seconds in milliseconds

module.exports = {
    name: 'say',
    aliases: ['echo', 'repeat'],
    category: 'fun',
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor('#ff0000'); // Red embed
        let prefix = message.guild.prefix || this.config.prefix || '!';

        // Check if user is on cooldown
        if (cooldowns.has(message.author.id)) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `You're on cooldown! Please wait a few seconds and try again.`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Check if a message was provided
        if (!args.length) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `Please provide a message to say.\n${prefix}say <message>`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Get the message content
        const userMessage = args.join(' ');

        // Check message length (Discord limit is 2000 characters)
        if (userMessage.length > 2000) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(
                            `The message is too long! Keep it under 2000 characters.`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Add user to cooldown
        cooldowns.add(message.author.id);
        setTimeout(() => cooldowns.delete(message.author.id), COOLDOWN_TIME);

        // Send the user's message
        await message.channel.send({
            embeds: [
                embed
                    .setDescription(
                        ` **${message.author.tag}** says:\n${userMessage}`
                    )
                    .setFooter({ text: `Sent by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });

        // Delete the original command message if possible
        if (message.deletable) {
            await message.delete().catch(() => {});
        }
    }
};