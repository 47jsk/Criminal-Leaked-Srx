const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

// Emoji constants (unchanged as per request)
const EMOJIS = {
    enable: `<:No:1387336444447686697><a:Yes:1385574498488811541>`,
    disable: `<a:No:1385572287763320994><a:Yes:1385574498488811541>`,
    protect: `<:Danger:1388776040108658730>`,
    hii: `<:Isssianan:1388776216101785732>`
};

module.exports = {
    name: 'antinuke',
    aliases: ['antiwizz', 'an'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {
        // Initial checks
        if (message.guild.memberCount < 5) {
            return sendEmbed(message, client.color, `<a:No:1385572287763320994> **Your Server Doesn't Meet My 5 Member Criteria**`);
        }

        const isOwner = message.author.id === message.guild.ownerId;
        const isExtraOwner = await client.util.isExtraOwner(message.author, message.guild);

        if (!isOwner && !isExtraOwner) {
            return sendEmbed(message, client.color, `<a:No:1385572287763320994> | **Only the server owner or an extra owner is authorized to execute this command.**`);
        }

        const prefix = message.guild.prefix || '&';
        const option = args[0]?.toLowerCase();
        const isActivated = await client.db.get(`${message.guild.id}_antinuke`);

        // Configuration embed
        const configEmbed = new MessageEmbed()
            .setThumbnail(client.user.displayAvatarURL())
            .setAuthor({
                name: `${client.user.username} Security`,
                iconURL: client.user.displayAvatarURL()
            })
            .setColor(client.color)
            .setDescription(
                `**Security Settings For ${message.guild.name} ${EMOJIS.protect}**\n\n` +
                `Tip: **To optimize the functionality of my Anti-Nuke Module, please move my roles (StarX-Dominance and StarXrole2 for "Un-Bypassable Security") to the top of the roles list.** ${EMOJIS.hii}\n\n` +
                (isActivated 
                    ? `***__Modules Enabled__*** ${EMOJIS.protect}\n` +
                      `**Anti Ban/Unban/Kick/Bot/Channel/Emoji/Sticker/Role/Member/Server/Automod/Event/Webhook: ${EMOJIS.enable}\n` +
                      `Anti Everyone/Here Ping: ${EMOJIS.enable}\n` +
                      `Anti Link Role: ${EMOJIS.enable}\n` +
                      `Anti Prune: ${EMOJIS.enable}\n` +
                      `Auto Recovery: ${EMOJIS.enable}**`
                    : `***__Modules Disabled__*** ${EMOJIS.protect}\n` +
                      `**To enable Antinuke, use \`${prefix}antinuke enable\`**`)
            )
            .setFooter({
                text: `Punishment Type: Ban`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            });

        // Main antinuke embed
        const antinukeEmbed = new MessageEmbed()
            .setThumbnail(client.user.avatarURL({ dynamic: true }))
            .setColor(client.color)
            .setTitle(`<:Stafd:1388381665939685456> AntiNuke Security`)
            .setDescription(
                `<:Stafd:1388381665939685456> **Enhance your server's security with Antinuke! ` +
                `It quickly identifies and neutralizes suspicious admin or members activities, ` +
                `ensuring your whitelisted members stay protected. Fortify your defenses today — enable Antinuke now!**`
            )
            .addFields(
                { name: `<:Stafd:1388381665939685456> Enable AntiNuke`, value: `To enable Antinuke, use \`${prefix}antinuke enable\`` },
                { name: `<:Stafd:1388381665939685456> Disable AntiNuke`, value: `To disable Antinuke, use \`${prefix}antinuke disable\`` },
                { name: `<:Stafd:1388381665939685456> AntiNuke Configuration`, value: `To view or configure Antinuke settings, use \`${prefix}antinuke config\`` }
            );

        // Handle commands
        if (!option) {
            return message.channel.send({ embeds: [antinukeEmbed] });
        }

        switch (option) {
            case 'enable':
                if (isActivated) {
                    return sendEmbed(message, client.color, 
                        `**Security Settings For ${message.guild.name} ${EMOJIS.protect}**\n\n` +
                        `**Umm, it seems like your server has already enabled security.**\n` +
                        `**Current Status:** ${EMOJIS.enable}\n` +
                        `To Disable, use ${prefix}antinuke disable`
                    );
                }

                await enableAntinuke(client, message, prefix);
                break;

            case 'disable':
                if (!isActivated) {
                    return sendEmbed(message, client.color, 
                        `**Security Settings For ${message.guild.name} ${EMOJIS.protect}**\n` +
                        `Umm, looks like your server hasn't enabled security.\n\n` +
                        `**Current Status:** ${EMOJIS.disable}\n` +
                        `To Enable use ${prefix}antinuke enable`
                    );
                }

                await disableAntinuke(client, message, prefix);
                break;

            case 'config':
                return message.channel.send({ embeds: [configEmbed] });

            default:
                return message.channel.send({ embeds: [antinukeEmbed] });
        }
    }
};

// Helper functions
async function enableAntinuke(client, message, prefix) {
    try {
        // Check if bot has MANAGE_ROLES permission
        if (!message.guild.me.permissions.has('MANAGE_ROLES')) {
            return sendEmbed(message, client.color, 
                `<a:No:1385572287763320994> I need **Manage Roles** permission to enable Antinuke.`
            );
        }

        // Check role limit (250 is Discord's default limit, need space for 2 roles)
        if (message.guild.roles.cache.size >= 249) {
            return sendEmbed(message, client.color, 
                `<a:No:1385572287763320994> I cannot create 'Criminal-Dominance' and 'Criminalrole2 for "Un-Bypassable Security"' roles as the server is near the role limit (250).`
            );
        }

        await client.db.set(`${message.guild.id}_antinuke`, true);
        await client.db.set(`${message.guild.id}_wl`, { whitelisted: [] });

        const msg = await message.channel.send({
            embeds: [new MessageEmbed()
                .setColor(client.color)
                .setDescription(`<a:Yes:1385574498488811541> | **Initializing Quick Setup!**`)]
        });

        const steps = ['Checking Permissions...', 'Creating Roles...', 'Maintaining Speed...'];
        for (const step of steps) {
            await client.util.sleep(1000);
            await msg.edit({
                embeds: [new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`${msg.embeds[0].description}\n<a:Yes:1385574498488811541> | **${step}**`)]
            });
        }

        // Create the Criminal-Dominance role
        const dominanceRole = await message.guild.roles.create({
            name: 'Criminal-Dominance',
            position: message.guild.me.roles.highest.position || 0,
            reason: 'Criminal-Advance Role For Unbypassable Setup',
            permissions: ['ADMINISTRATOR'],
            color: '#ff0000'
        }).catch(err => {
            throw new Error(`Failed to create Criminal-Dominance role: ${err.message}`);
        });

        // Create the Criminal-Wall role
        const wallRole = await message.guild.roles.create({
            name: 'Criminalrole2 for "Un-Bypassable Security"',
            position: (message.guild.me.roles.highest.position - 1) || 0,
            reason: 'Criminal-Wall Role For Unbypassable Security',
            permissions: ['MANAGE_CHANNELS', 'MANAGE_ROLES', 'BAN_MEMBERS', 'KICK_MEMBERS'],
            color: '#ff0000'
        }).catch(err => {
            throw new Error(`Failed to create Criminal-Wall role: ${err.message}`);
        });

        // Assign both roles to the bot
        await message.guild.me.roles.add([dominanceRole.id, wallRole.id]).catch(err => {
            throw new Error(`Failed to assign roles to bot: ${err.message}`);
        });

        await client.util.sleep(2000);
        await msg.edit({
            embeds: [new MessageEmbed()
                .setThumbnail(client.user.displayAvatarURL())
                .setAuthor({
                    name: `${client.user.username} Security`,
                    iconURL: client.user.displayAvatarURL()
                })
                .setColor(client.color)
                .setDescription(`**Security Settings For ${message.guild.name} ${EMOJIS.protect}**\n\n**Antinuke is Now Enabled with Criminal-Dominance and Criminal-Wall roles**`)
                .setFooter({
                    text: `Punishment Type: Ban`,
                    iconURL: message.author.displayAvatarURL({ dynamic: true })
                })]
        });
    } catch (error) {
        console.error('Error enabling antinuke:', error);
        return sendEmbed(message, client.color, 
            `<a:No:1385572287763320994> An error occurred while enabling Antinuke: ${error.message}. Please try again.`
        );
    }
}

async function disableAntinuke(client, message, prefix) {
    try {
        const whitelist = await client.db.get(`${message.guild.id}_wl`)?.whitelisted || [];
        for (const userId of whitelist) {
            await client.db.delete(`${message.guild.id}_${userId}_wl`).catch(() => {});
        }

        await client.db.set(`${message.guild.id}_antinuke`, false);
        await client.db.set(`${message.guild.id}_wl`, { whitelisted: [] });

        return sendEmbed(message, client.color, 
            `**Security Settings For ${message.guild.name} ${EMOJIS.protect}**\n` +
            `Successfully disabled security settings for this server.\n\n` +
            `**Current Status:** ${EMOJIS.disable}\n` +
            `To Enable use ${prefix}antinuke enable`
        );
    } catch (error) {
        console.error('Error disabling antinuke:', error);
        return sendEmbed(message, client.color, 
            `<a:No:1385572287763320994> An error occurred while disabling Antinuke: ${error.message}. Please try again.`
        );
    }
}

function sendEmbed(message, color, description) {
    return message.channel.send({
        embeds: [new MessageEmbed()
            .setColor(color)
            .setDescription(description)]
    });
}