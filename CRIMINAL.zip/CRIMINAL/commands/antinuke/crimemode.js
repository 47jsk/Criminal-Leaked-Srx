const { Client, Message, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'crimemode',
    aliases: ['cm', 'crime'],
    category: 'security',
    premium: true,

    run: async (client, message, args) => {
        const guild = message.guild;
        const prefix = message.guild.prefix || '&';

        if (message.author.id !== guild.ownerId) {
            return message.reply({ content: '<a:No:1385572287763320994> Only the server owner can manage Crime Mode!' });
        }

        if (!args[0]) {
            const isEnabled = await client.db.get(`crimemode_${guild.id}`);
            const status = isEnabled ? '<a:Yes:1385574498488811541> Enabled' : '<a:No:1385572287763320994> Disabled';
            const logChannelId = await client.db.get(`crimemode_log_${guild.id}`);
            const logChannel = logChannelId ? guild.channels.cache.get(logChannelId) : null;
            const descriptionEmbed = new MessageEmbed()
                .setColor('#ff0000')
                .setTitle('Crime Mode Information')
                .setDescription(
                    `**Status**: ${status}\n` +
                    `**Log Channel**: ${logChannel ? logChannel : 'Not set (uses channel with "log" in name)'}\n\n` +
                    'When Crime Mode is enabled:\n' +
                    '- No bots can be added to the server.\n' +
                    '- Any bot added will be automatically kicked.\n' +
                    '- This applies to everyone, including the server owner.\n\n' +
                    `**Usage**:\n` +
                    `\`${prefix}crimemode enable\` - Enable Crime Mode\n` +
                    `\`${prefix}crimemode disable\` - Disable Crime Mode\n` +
                    `\`${prefix}crimemode setlog <channel>\` - Set log channel`
                )
                .setFooter({ text: 'Use with caution!' });

            return message.reply({ embeds: [descriptionEmbed] });
        }

        const subCommand = args[0].toLowerCase();
        if (subCommand === 'enable') {
            if (await client.db.get(`crimemode_${guild.id}`)) {
                return message.reply({ content: '<a:No:1385572287763320994> Crime Mode is already enabled!' });
            }
            await client.db.set(`crimemode_${guild.id}`, true);
            return message.reply({ content: '<a:Yes:1385574498488811541> Crime Mode enabled! No bots can be added.' });
        } else if (subCommand === 'disable') {
            if (!await client.db.get(`crimemode_${guild.id}`)) {
                return message.reply({ content: '<a:No:1385572287763320994> Crime Mode is already disabled!' });
            }
            await client.db.set(`crimemode_${guild.id}`, false);
            return message.reply({ content: '<a:No:1385572287763320994> Crime Mode disabled!' });
        } else if (subCommand === 'setlog') {
            const channel = message.mentions.channels.first() || guild.channels.cache.get(args[1]);
            if (!channel || channel.type !== 'text') {
                return message.reply({ content: '<a:No:1385572287763320994> Please specify a valid text channel!' });
            }
            await client.db.set(`crimemode_log_${guild.id}`, channel.id);
            return message.reply({ content: `<a:Yes:1385574498488811541> Crime Mode log channel set to ${channel}!` });
        } else {
            return message.reply({ content: '<a:No:1385572287763320994> Invalid subcommand! Use `enable`, `disable`, or `setlog`.' });
        }
    }
};