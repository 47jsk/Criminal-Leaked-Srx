const { Message, Client, MessageEmbed } = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'antiapplication',
    aliases: ['appblock', 'antiappspam'],
    category: 'antinuke',
    premium: true,
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        const prefix = message.guild.prefix || this.config.prefix || '!';

        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setDescription(`<:No:1387336444447686697> You need ADMINISTRATOR permission to use this command!`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Store original permissions for potential restoration
        const originalPermissions = new Map();

        if (!args[0]) {
            // Show description when no arguments provided
            return message.channel.send({
                embeds: [
                    embed
                        .setTitle('<:Isssianan:1388776216101785732> Anti-Application Command Info')
                        .setDescription(
                            `This command manages application command permissions to prevent unauthorized bot commands.\n\n` +
                            `**Usage:**\n` +
                            `\`${prefix}antiappspam\` - Shows this description\n` +
                            `\`${prefix}antiappspam enable\` - Disables application commands for everyone\n` +
                            `\`${prefix}antiappspam disable\` - Restores original permissions`
                        )
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (args[0].toLowerCase() === 'enable') {
            let changesMade = 0;

            // Store original permissions and disable application commands
            message.guild.channels.cache.forEach(channel => {
                const permissions = channel.permissionsFor(message.guild.roles.everyone);
                if (permissions.has('USE_APPLICATION_COMMANDS')) {
                    originalPermissions.set(channel.id, permissions.serialize());
                    channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                        USE_APPLICATION_COMMANDS: false
                    }).then(() => changesMade++).catch(err => console.error(`Failed to update ${channel.name}:`, err));
                }
            });

            message.guild.roles.cache.forEach(role => {
                const permissions = role.permissions;
                if (permissions.has('USE_APPLICATION_COMMANDS')) {
                    originalPermissions.set(role.id, permissions.serialize());
                    role.setPermissions(permissions.remove(['USE_APPLICATION_COMMANDS'])).then(() => changesMade++).catch(err => console.error(`Failed to update ${role.name}:`, err));
                }
            });

            // Save permissions to a file or database for persistence
            const fs = require('fs');
            fs.writeFileSync('./originalPermissions.json', JSON.stringify([...originalPermissions]));

            return message.channel.send({
                embeds: [
                    embed
                        .setTitle('<:Danger:1388776040108658730> Anti-Application Mode Activated')
                        .setDescription(`<a:Yes:1385574498488811541> Disabled "Allow external applications" for ${changesMade} channels/roles.\nThis helps prevent unauthorized bot commands.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        if (args[0].toLowerCase() === 'disable') {
            let changesMade = 0;
            
            // Load saved permissions
            const fs = require('fs');
            let savedPermissions = new Map();
            try {
                savedPermissions = new Map(JSON.parse(fs.readFileSync('./originalPermissions.json')));
            } catch (err) {
                console.error('Error reading saved permissions:', err);
            }

            // Restore channel permissions
            message.guild.channels.cache.forEach(channel => {
                if (savedPermissions.has(channel.id)) {
                    channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                        USE_APPLICATION_COMMANDS: savedPermissions.get(channel.id).USE_APPLICATION_COMMANDS
                    }).then(() => changesMade++).catch(err => console.error(`Failed to restore ${channel.name}:`, err));
                }
            });

            // Restore role permissions
            message.guild.roles.cache.forEach(role => {
                if (savedPermissions.has(role.id)) {
                    role.setPermissions(savedPermissions.get(role.id)).then(() => changesMade++).catch(err => console.error(`Failed to restore ${role.name}:`, err));
                }
            });

            return message.channel.send({
                embeds: [
                    embed
                        .setTitle('<:Isssianan:1388776216101785732> Anti-Application Mode Deactivated')
                        .setDescription(`<a:Yes:1385574498488811541> Restored application command permissions for ${changesMade} channels/roles.`)
                        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp()
                ]
            });
        }

        // Invalid argument
        return message.channel.send({
            embeds: [
                embed
                    .setDescription(`<a:No:1385572287763320994> Invalid argument! Use \`${prefix}antiappspam [enable|disable]\` or \`${prefix}antiappspam\` for info.`)
                    .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                    .setTimestamp()
            ]
        });
    }
};