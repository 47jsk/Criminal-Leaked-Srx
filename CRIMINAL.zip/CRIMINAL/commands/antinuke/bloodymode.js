const { MessageEmbed } = require('discord.js');
let enable = `<:No:1387336444447686697><a:Yes:1385574498488811541>`;
let disable = `<a:Yes:1385574498488811541><:No:1387336444447686697>`;
let protect = `<:Danger:1388776040108658730>`;
const wait = require('wait');

module.exports = {
    name: 'bloodymode',
    aliases: ['bm', 'bloody'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {
        if (message.guild.memberCount < 3) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Your Server Doesn't Meet My 3 Member Criteria`)
                ]
            });
        }

        let own = message.author.id == message.guild.ownerId;
        const check = await client.util.isExtraOwner(message.author, message.guild);
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`<:No:1387336444447686697> | Only Server Owner Or Extraowner Can Run This Command.!`)
                ]
            });
        }

        let prefix = '&' || message.guild.prefix;
        const option = args[0];
        const isActivatedAlready = await client.db.get(`${message.guild.id}_threatmode`);
        
        // Check if antinuke is enabled and automatically enable dangermode
        const isAntinukeEnabled = await client.db.get(`${message.guild.id}_antinuke`);
        if (isAntinukeEnabled && !isActivatedAlready) {
            await client.db.set(`${message.guild.id}_threatmode`, true);
            const autoEnabled = new MessageEmbed()
                .setThumbnail(client.user.displayAvatarURL())
                .setAuthor({ name: `${client.user.username} Security`, iconURL: client.user.displayAvatarURL() })
                .setColor(client.color)
                .setDescription(`**Security Settings For ${message.guild.name} ${protect}**\nBloodymode has been automatically enabled because Antinuke is active.\nPunishments: Ban users who mention @everyone, prune members, or mass ban.`);
            message.channel.send({ embeds: [autoEnabled] });
        }

        const threatMode = new MessageEmbed()
            .setThumbnail(client.user.avatarURL({ dynamic: true }))
            .setColor(client.color)
            .setTitle(`__**BloodyMode**__`)
            .setDescription(`Enable Bloodymode to automatically ban users for dangerous actions like @everyone mentions, pruning members, or mass banning!`)
            .addFields([
                {
                    name: `__**BloodyMode Enable**__`,
                    value: `To Enable Bloodymode, Use - \`${prefix}bloodymode enable\``
                },
                {
                    name: `__**Bloodymode Disable**__`,
                    value: `To Disable Bloodymode, Use - \`${prefix}bloodymode disable\``
                }
            ]);

        if (!option) {
            message.channel.send({ embeds: [threatMode] });
        } else if (option === 'enable') {
            if (isActivatedAlready) {
                const alreadyEnabled = new MessageEmbed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(`**Security Settings For ${message.guild.name} ${protect}**\nBloodymode is already enabled!\nCurrent Status: ${enable}\nTo Disable use ${prefix}bloodymode disable`);
                message.channel.send({ embeds: [alreadyEnabled] });
            } else {
                await client.db.set(`${message.guild.id}_threatmode`, true);
                const enabled = new MessageEmbed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setAuthor({ name: `${client.user.username} Security`, iconURL: client.user.displayAvatarURL() })
                    .setColor(client.color)
                    .setDescription(`**Security Settings For ${message.guild.name} ${protect}**\Bloodymode is now enabled.\nPunishments: Ban users who mention @everyone, prune members, or mass ban.`);
                message.channel.send({ embeds: [enabled] });
            }
        } else if (option === 'disable') {
            if (!isActivatedAlready) {
                const alreadyDisabled = new MessageEmbed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(`**Security Settings For ${message.guild.name} ${protect}**\nBloodymode is already disabled.\nCurrent Status: ${disable}\nTo Enable use ${prefix}bloodymode enable`);
                message.channel.send({ embeds: [alreadyDisabled] });
            } else {
                await client.db.set(`${message.guild.id}_threatmode`, null);
                const disabled = new MessageEmbed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(`**Security Settings For ${message.guild.name} ${protect}**\nSuccessfully disabled Bloodymode for this server.\nCurrent Status: ${disable}\nTo Enable use ${prefix}bloodymode enable`);
                message.channel.send({ embeds: [disabled] });
            }
        } else {
            return message.channel.send({ embeds: [threatMode] });
        }
    },

    onMentionEveryone: async (message) => {
        const isEnabled = await client.db.get(`${message.guild.id}_threatmode`);
        if (isEnabled && message.mentions.everyone) {
            await message.member.ban({ reason: 'Mentioned @everyone in BloodyMode.' });
            message.channel.send(`${message.author.tag} has been banned for mentioning @everyone.`);
        }
    },

    onPruneMembers: async (guild, pruned) => {
        const isEnabled = await client.db.get(`${guild.id}_threatmode`);
        if (isEnabled && pruned >= 3) {
            const user = guild.members.cache.get('userID'); 
            if (user) {
                await user.ban({ reason: `Pruned ${pruned} members in Bloodymode.` });
                guild.channels.cache.first().send(`${user.tag} has been banned for pruning ${pruned} members.`);
            }
        }
    },

    onMassBan: async (guild, bans) => {
        const isEnabled = await client.db.get(`${guild.id}_threatmode`);
        if (isEnabled && bans.size >= 3) {
            const user = guild.members.cache.get('userID'); 
            if (user) {
                await user.ban({ reason: `Banned ${bans.size} members in Bloodymode.` });
                guild.channels.cache.first().send(`${user.tag} has been banned for mass banning ${bans.size} members.`);
            }
        }
    }
};